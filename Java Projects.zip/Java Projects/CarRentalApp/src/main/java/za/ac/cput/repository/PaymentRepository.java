package za.ac.cput.repository;

import za.ac.cput.domain.Payment;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.*;

/*
 * Class Name: PaymentRepository
 * Description: Payment Repository class
 * Author: Lucky July Twala (231242840)
 * Date: 22 March 2026
 */



public class PaymentRepository {
    // Simulate data persistence
    private Map<String, Payment> paymentMap = new HashMap<>();

    // Save a new Payment
    public Payment save(Payment payment) {
        paymentMap.put(payment.getPaymentId(), payment);
        return payment;
    }

    // Find a Payment by ID
    public Payment findById(String paymentId) {

        return paymentMap.get(paymentId);
    }

    // Get all Payments
    public List<Payment> getAll() {

        return new ArrayList<>(paymentMap.values());
    }

    // Delete a Payment by ID
    public boolean delete(String paymentId) {

        return paymentMap.remove(paymentId) != null;
    }

}
