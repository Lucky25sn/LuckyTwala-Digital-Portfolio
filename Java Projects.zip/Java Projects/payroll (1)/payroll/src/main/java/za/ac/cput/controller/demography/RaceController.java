package za.ac.cput.controller.demography;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import za.ac.cput.entity.demography.Race;
import za.ac.cput.service.demography.RaceService;

import java.util.List;

@RestController
@RequestMapping("/race")
public class RaceController {
    private RaceService raceService;

    @Autowired
    public RaceController(RaceService raceService){
        this.raceService = raceService;
    }

    @PostMapping("/create")
    public Race createRace(@RequestBody Race race){
        return raceService.create(race);
    }

    @GetMapping("/read/{raceId}")
    public Race readRace(@PathVariable("raceId") String raceId){
        return raceService.read(raceId);
    }

    @PutMapping("/update")
    public Race updateRace(@RequestBody Race race){
        return raceService.update(race);
    }

    @DeleteMapping("/delete/{raceId}")
    public boolean deleteRace(@PathVariable("raceId") String raceId){
        return raceService.delete(raceId);
    }

    @GetMapping("/getall")
    public List<Race> getAllRaces(){
        return raceService.getAllRaces();
    }
}
