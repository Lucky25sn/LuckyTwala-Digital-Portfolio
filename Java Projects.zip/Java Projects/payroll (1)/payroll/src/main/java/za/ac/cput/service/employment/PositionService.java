package za.ac.cput.service.employment;

import za.ac.cput.entity.employment.Position;
import za.ac.cput.service.IService;

import java.util.List;

public interface PositionService extends IService<Position, String> {
    List<Position> getAllPosition();
    List<Position> getAllByPositionStatus(Position.PositionStatus positionStatus);
}
