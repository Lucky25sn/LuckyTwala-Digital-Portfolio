package za.ac.cput.repository.employment.Impl;

import za.ac.cput.entity.employment.Employment;
import za.ac.cput.entity.employment.Position;
import za.ac.cput.repository.employment.PositionRepository;

import java.util.ArrayList;
import java.util.List;

public class PositionRepositoryImpl implements PositionRepository {

 List<Position> positionList;

 public PositionRepositoryImpl() {
     positionList = new ArrayList<>();
 }

 public static PositionRepositoryImpl positionRepository = null;

 public static PositionRepositoryImpl getPositionRepository() {
     if (positionRepository == null) {
        positionRepository = new PositionRepositoryImpl();
     }
     return positionRepository;
 }

    @Override
    public Position create(Position position) {
     boolean success = positionList.add(position);
     if (success) {
         return position;
     }
        return null;
    }

    @Override
    public Position read(String s) {
     for (Position position : positionList) {
         if(position.getPositionID().equalsIgnoreCase(s)){
             return position;
         }
     }
        return null;
    }

    @Override
    public Position update(Position position) {
         Position oldPosition = read(position.getPositionID());
     if(oldPosition == null){
         return null;
     }
     positionList.remove(oldPosition);
     positionList.add(position);
        return position;
    }

    @Override
    public boolean delete(String s) {
     Position position = read(s);
     if(position == null){
         return false;
     }
        return positionList.remove(position);
    }

    @Override
    public List<Position> getAllPosition() {
        return positionList;
    }

    @Override
    public List<Position> getAllByPositionStatus(Position.PositionStatus positionStatus) {
     List<Position> results = new ArrayList<>();
     for (Position position : positionList) {
         if(position.getPositionStatus().equals(positionStatus)){
             results.add(position);
         }
     }
     return results;
    }

}
