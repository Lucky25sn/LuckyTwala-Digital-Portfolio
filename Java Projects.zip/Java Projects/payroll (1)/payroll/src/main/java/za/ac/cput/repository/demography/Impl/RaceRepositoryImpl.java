package za.ac.cput.repository.demography.Impl;

import za.ac.cput.entity.demography.Race;
import za.ac.cput.repository.demography.RaceRepository;

import java.util.ArrayList;
import java.util.List;

public class RaceRepositoryImpl implements RaceRepository {

    List<Race> raceList;
    public RaceRepositoryImpl(){
        raceList = new ArrayList<>();
    }

    //Singeleton pattern
    private static RaceRepositoryImpl raceRepository = null;
    public static RaceRepositoryImpl getInstance(){
        if(raceRepository == null){
            raceRepository = new RaceRepositoryImpl();
        }
        return raceRepository;
    }

    @Override
    public Race create(Race race) {
        boolean success = raceList.add(race);
        if(success){
            return race;
        }
        return null;
    }

    @Override
    public Race read(String s) {
        for(Race race : raceList){
            if(race.getRaceId().equalsIgnoreCase(s)){
                return race;
            }
        }
        return null;
    }

    @Override
    public Race update(Race race) {
        Race oldRace = read(race.getRaceId());
        if(oldRace == null){
            return null;
        }
        raceList.remove(oldRace);
        raceList.add(race);
        return race;
    }

    @Override
    public boolean delete(String s) {
        Race race = read(s);
        if(race == null){
            return false;
        }
        return raceList.remove(race);
    }

    @Override
    public List<Race> getAllRaces() {
     return raceList;
    }

  }
