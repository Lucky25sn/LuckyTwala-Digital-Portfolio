package za.ac.cput.factory.demography;

import za.ac.cput.entity.demography.Gender;
import za.ac.cput.util.Helper;

public class GenderFactory {
    public static Gender createGender( String genderDescription) {
        String genderId = Helper.generatedUUI();
        if(Helper.isEmptyorNull(genderDescription)){
            return null;
        }
        return new Gender.Builder()
                .setGenderId(genderId)
                .setGenderDescription(genderDescription)
                .build();
    }
}
