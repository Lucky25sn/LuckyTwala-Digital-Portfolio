package za.ac.cput.repository.employeedetails.Impl;

import za.ac.cput.entity.employeedetails.Employee;
import za.ac.cput.repository.employeedetails.EmployeeRepository;

import java.util.ArrayList;
import java.util.List;

public class EmployeeRepositoryImpl implements EmployeeRepository {
  // Array List
  List<Employee> employeeList;

  public EmployeeRepositoryImpl (){
      employeeList = new ArrayList<>();
  }


   // Singleton
    private static EmployeeRepositoryImpl  employeeRepository;

    public static EmployeeRepositoryImpl getEmployeeRepository() {
        if (employeeRepository == null) {
            employeeRepository = new EmployeeRepositoryImpl();
        }
        return employeeRepository;
    }

    @Override
    public Employee create(Employee employee) {
        boolean  success = employeeList.add(employee);
        if(success){
            return employee;
        }
         return null;
    }

    @Override
    public Employee read(String s) {
        for(Employee employee : employeeList){
            if(employee.getNationality().equalsIgnoreCase(s)){
                return employee;
            }
        }
        return null;
    }

    @Override
    public Employee update(Employee employee) {

        Employee oldEmployee = read(employee.getEmployeeNumber());
        if(oldEmployee == null){
            return null;
        }
         employeeList.remove(oldEmployee);
        employeeList.add(employee);
        return employee;
    }

    @Override
    public boolean delete(String s) {
        Employee employee = read(s);
        if(employee == null){
            return false;
        }
        return employeeList.remove(employee);
    }

    @Override
    public List<Employee> getAllEmployees() {
        return employeeList;
    }

    @Override
    public List<Employee> getEmployeeByNationality(String nationality) {
        List<Employee> results = new ArrayList<>();
        for(Employee employee : employeeList){
            if(employee.getNationality().equalsIgnoreCase(nationality)){
                results.add(employee);
            }
        }
        return results;
    }
}
