package za.ac.cput;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@SpringBootApplication


public class PayrollAplication {
    public static void main(String[] args) {
        SpringApplication.run(PayrollAplication.class, args);
    }
////
//    @GetMapping("/home")
//    public String home(){
//        return "Hello World";
//    }
//   @GetMapping("/")
//    public String helloword(){
//        return "Hello World!";
//    }
////  @GetMapping("/")
//    public String hello(){
//        return "Hello World!";
//  }
//
//  @GetMapping("/This")
//    public String hello2(){
//        return "Hello This is the first spring programm";
//  }
//
//    @GetMapping("/users")
//    public String hellos(){
//        return "read all users";
//    }
}
