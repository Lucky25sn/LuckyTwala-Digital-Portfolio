package za.ac.cput.controller.demography;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import za.ac.cput.entity.demography.Gender;
import za.ac.cput.service.demography.GenderService;

import java.util.List;

@RestController
@RequestMapping("/gender")
public class GenderController {
    private GenderService genderService;

    @Autowired
    public GenderController(GenderService genderService){
        this.genderService=genderService;
    }

    @PostMapping("/gender")
    public Gender createGender (@RequestBody Gender gender){
        return genderService.create(gender);
    }
    @GetMapping("/read/{genderId}")
    public Gender readGender(@PathVariable("genderId") String genderId){
        return genderService.read(genderId);
    }
    @PutMapping("/update")
    public Gender updateGender(@RequestBody Gender gender){
        return genderService.update(gender);
    }
    @DeleteMapping("/delete/{genderId}")
    public boolean deleteGender(@PathVariable("genderId") String genderId){
        return genderService.delete(genderId);
    }

    @GetMapping("/getall")
    public List<Gender> getAllGenders(){
        return genderService.getAllGenders();
    }
}
