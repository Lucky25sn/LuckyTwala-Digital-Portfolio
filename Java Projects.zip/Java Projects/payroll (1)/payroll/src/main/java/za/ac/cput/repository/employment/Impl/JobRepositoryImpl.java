package za.ac.cput.repository.employment.Impl;

import za.ac.cput.entity.employment.Job;
import za.ac.cput.repository.employment.JobRepository;

import java.util.ArrayList;
import java.util.List;

public class JobRepositoryImpl implements JobRepository {

    List<Job> jobList;

    public JobRepositoryImpl(){
        jobList = new ArrayList<>();
    }

    private static JobRepositoryImpl jobRepository;
    public static JobRepositoryImpl getInstance(){
        if(jobRepository==null){
            jobRepository=new JobRepositoryImpl();
        }
        return jobRepository;
    }

    @Override
    public Job create(Job job) {
        boolean success = jobList.add(job);
        if(success){
            return job;
        }
        return null;
    }

    @Override
    public Job read(String s) {
        for(Job job:jobList){
            if(job.getJobId().equalsIgnoreCase(s)){
                return job;
            }
        }
        return null;
    }

    @Override
    public Job update(Job job) {
        Job oldJob=read(job.getJobId());
        if(oldJob==null){
            return null;
        }
        jobList.remove(oldJob);
        jobList.add(job);
        return job;
    }

    @Override
    public boolean delete(String s) {
        Job job=read(s);
        if(job==null){
            return false;
        }
        return jobList.remove(job);
    }

    @Override
    public List<Job> getAllJob() {
        return jobList;
    }

    @Override
    public List<Job> getAllJobByTitle(String title) {
        List<Job> results=new ArrayList<>();
        for(Job job:jobList){
            if(job.getJobtitle().equalsIgnoreCase(title)){
                results.add(job);
            }
        }
        return results;
    }

}
