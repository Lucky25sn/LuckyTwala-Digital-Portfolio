package za.ac.cput.entity.employeedetails;

public class Identity {
    private String identityId;
    private String identityType;
    private String employeeNumber;
    private String value;

    private  Identity(){

    }

    public Identity(Builder builder){
        this.identityId = builder.identityId;
        this.identityType = builder.identityType;
        this.employeeNumber = builder.employeeNumber;
        this.value = builder.value;
    }

    public String getIdentityId() {
        return identityId;
    }

    public String getIdentityType() {
        return identityType;
    }

    public String getEmployeeNumber() {
        return employeeNumber;
    }

    public String getValue() {
        return value;
    }

    @Override
    public String toString() {
        return "Identity{" +
                "identityId='" + identityId + '\'' +
                ", identityType='" + identityType + '\'' +
                ", employeeNumber='" + employeeNumber + '\'' +
                ", value='" + value + '\'' +
                '}';
    }

    public static class Builder{
        private String identityId;
        private String identityType;
        private String employeeNumber;
        private String value;

        public Builder setIdentityId(String identityId){
            this.identityId = identityId;
            return this;
        }

        public Builder setIdentityType(String identityType){
            this.identityType = identityType;
            return this;
        }

        public Builder setEmployeeNumber(String employeeNumber){
            this.employeeNumber = employeeNumber;
            return this;
        }
        public Builder setValue(String value) {
            this.value = value;
            return this;
        }

        public Builder copy(Identity identity){
            this.identityId = identity.identityId;
            this.identityType = identity.identityType;
            this.employeeNumber = identity.employeeNumber;
            this.value = identity.value;
            return this;
        }

        public Identity build(){
            return new Identity(this);
        }
    }
}
