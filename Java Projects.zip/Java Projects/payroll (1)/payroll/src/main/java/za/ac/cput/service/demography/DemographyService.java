package za.ac.cput.service.demography;

import za.ac.cput.entity.demography.Demography;
import za.ac.cput.service.IService;

import java.util.List;

public interface DemographyService extends IService<Demography, String> {
    List<Demography> getAllDemography();
    List<Demography> getDemographyByRace(String race);
    List<Demography> getDemographyByGender(String gender);
}
