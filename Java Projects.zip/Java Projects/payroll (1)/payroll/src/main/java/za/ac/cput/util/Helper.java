package za.ac.cput.util;

import org.apache.commons.validator.routines.EmailValidator;

import java.util.UUID;

public class Helper {
    public static String generatedUUI(){
        return UUID.randomUUID().toString();
    }
    public static boolean isEmptyorNull(String str){
        if(str==null || str.isEmpty()){
            return true;
        }
        return false;
    }

    public static boolean IsValidEmail(String email){
        EmailValidator  emailValidator = EmailValidator.getInstance();
        if(emailValidator.isValid(email)){
            return true;
        }
        return false;
    }

    public static boolean isValidCode(short postalCode){
        if(postalCode > 1 || postalCode < 99999){
            return true;
        }
        return false;
    }
    public static boolean isValidStreetNumber(short streetNumber) {
        if(streetNumber < 1 || streetNumber > 99999){
            return true;
        }
        return false;
    }
}
