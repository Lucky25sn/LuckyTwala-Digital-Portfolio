package za.ac.cput.entity.demography;

public class Gender {
    private String genderId;
    private String genderDescription;

    private Gender(){

    }

    public Gender(Builder builder){
        this.genderId = builder.genderId;
        this.genderDescription = builder.genderDescription;
    }

    public String getGenderId() {
        return genderId;
    }

    public String getGenderDescription() {
        return genderDescription;
    }

    @Override
    public String toString() {
        return "Gender{" +
                "genderId='" + genderId + '\'' +
                ", genderDescription='" + genderDescription + '\'' +
                '}';
    }

    public static class Builder{
        private String genderId;
        private String genderDescription;

        public Builder setGenderId(String genderId){
            this.genderId = genderId;
            return this;
        }

        public Builder setGenderDescription(String genderDescription){
            this.genderDescription = genderDescription;
            return this;
        }

        public Builder copy(Gender gender){
            this.genderId = gender.genderId;
            this.genderDescription = gender.genderDescription;
            return this;
        }

        public Gender build(){
            return new Gender(this);
        }
    }
}
