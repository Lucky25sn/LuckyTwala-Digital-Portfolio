package za.ac.cput.repository.demography;

import za.ac.cput.entity.demography.Demography;
import za.ac.cput.repository.IRepository;

import java.util.List;

public interface DemographyRepository extends IRepository<Demography, String> {
    List<Demography> getAllDemography();
    List<Demography> getDemographyByRace(String race);
    List<Demography> getDemographyByGender(String gender);

}
