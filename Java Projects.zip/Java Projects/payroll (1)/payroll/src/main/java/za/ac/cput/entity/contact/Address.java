package za.ac.cput.entity.contact;

import java.io.Serializable;

public class Address implements Serializable {
    private String addressId;
    private String streetAddress;
    private String postalAddress;
    private String city;
    private String province;
    private String country;

    private Address(){

    }

    private Address (Builder builder){
        this.addressId = builder.addressId;
        this.streetAddress = builder.streetAddress;
        this.postalAddress = builder.postalAddress;
        this.city = builder.city;
        this.province = builder.province;
        this.country = builder.country;
    }

    public Address(String addressId ,String streetAddress, String postatAddress, String city,
                   String province, String country) {
        this.addressId = addressId;
        this.streetAddress = streetAddress;
        this.postalAddress = postatAddress;
        this.city = city;
        this.province = province;
        this.country = country;
    }

    public String getAddressId() {
        return addressId;
    }

    public String getStreetAddress() {
        return streetAddress;
    }

    public String getPostalAddress() {
        return postalAddress;
    }

    public String getCity() {
        return city;
    }

    public String getProvince() {
        return province;
    }

    public String getCountry() {
        return country;
    }

    @Override
    public String toString() {
        return "Address{" +
                "address Id='" + addressId + '\'' +
                ", streetAddress='" + streetAddress + '\'' +
                ", postalAddress='" + postalAddress + '\'' +
                ", city='" + city + '\'' +
                ", province='" + province + '\'' +
                ", country='" + country + '\'' +
                '}';
    }

    public static class Builder{
        private String addressId;
        private String streetAddress;
        private String postalAddress;
        private String city;
        private String province;
        private String country;

        public Builder setAddressId(String addressId){
            this.addressId = addressId;
            return this;
        }

        public Builder setStreetAddress(String streetAddress){
            this.streetAddress = streetAddress;
            return this;
        }

        public Builder setPostalAddress(String postalAddress){
            this.postalAddress = postalAddress;
            return this;
        }

        public Builder setCity(String city){
            this.city = city;
            return this;
        }

        public Builder setProvince(String province){
            this.province = province;
            return this;
        }

        public Builder setCountry(String country){
            this.country = country;
            return this;
        }

        public Builder copy(Address address){
            this.addressId = address.addressId;
            this.streetAddress = address.streetAddress;
            this.postalAddress = address.postalAddress;
            this.city = address.city;
            this.province = address.province;
            this.country =address.country;
            return this;
        }
        public Address build(){
            return new Address(this);
        }

    }
}
