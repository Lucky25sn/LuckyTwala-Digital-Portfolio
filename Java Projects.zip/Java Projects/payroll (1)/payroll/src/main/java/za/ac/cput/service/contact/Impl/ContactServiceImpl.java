package za.ac.cput.service.contact.Impl;

import org.springframework.stereotype.Service;
import za.ac.cput.entity.contact.Contact;
import za.ac.cput.repository.contact.AddressRepository;
import za.ac.cput.repository.contact.ContactRepository;
import za.ac.cput.repository.contact.Impl.AddressRepositoryImpl;
import za.ac.cput.repository.contact.Impl.ContactRepositoryImpl;
import za.ac.cput.service.contact.AddressService;
import za.ac.cput.service.contact.ContactService;

import java.util.List;

@Service
public class ContactServiceImpl implements ContactService {
    private static ContactService contactService = null;


    private ContactRepository contactRepository ;


    private ContactServiceImpl(){
        this.contactRepository = new ContactRepositoryImpl();
    }

    public static ContactService getContactService(){
        if(contactService==null){
            contactService = new ContactServiceImpl();
        }
        return contactService;
    }


    @Override
    public Contact create(Contact contact) {
        return this.contactRepository.create(contact);
    }

    @Override
    public Contact read(String s) {
        return this.contactRepository.read(s);
    }

    @Override
    public Contact update(Contact contact) {
        return this.contactRepository.update(contact);
    }

    @Override
    public boolean delete(String s) {
        return this.contactRepository.delete(s);
    }
    @Override
    public List<Contact> getAllContacts() {
        return this.contactRepository.getAllContacts();
    }

}
