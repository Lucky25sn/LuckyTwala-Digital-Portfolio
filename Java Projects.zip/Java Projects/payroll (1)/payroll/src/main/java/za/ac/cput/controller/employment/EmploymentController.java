package za.ac.cput.controller.employment;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import za.ac.cput.entity.employment.Employment;
import za.ac.cput.service.employment.EmploymentService;

import java.util.List;

@RestController
@RequestMapping("/employment")
public class EmploymentController {

    private EmploymentService employmentService;

    @Autowired
    public EmploymentController(EmploymentService employmentService) {
        this.employmentService = employmentService;
    }

    @PostMapping("/create")
    public Employment create(@RequestBody Employment employment) {
        return employmentService.create(employment);
    }

    @GetMapping("/read/{employmentId}")
    public Employment readEmployment(@PathVariable("employmentId") String employmentId) {
        return employmentService.read(employmentId);
    }

    @PutMapping("/update")
    public Employment updateEmployment(@RequestBody Employment employment) {
        return employmentService.update(employment);
    }

    @DeleteMapping("/delete/{employmentID}")
    public boolean deleteEmployment(@PathVariable("employmentID") String employmentID) {
        return employmentService.delete(employmentID);
    }

    @GetMapping("/getall")
    public List<Employment> getAllEmployment() {
        return employmentService.getAllEmployment();
    }

    @GetMapping("/getall/{type}")
    public List<Employment> getEmploymentByType(@PathVariable("type") Employment.EmploymentType type) {
        return employmentService.getEmploymentByType(type);
    }

}
