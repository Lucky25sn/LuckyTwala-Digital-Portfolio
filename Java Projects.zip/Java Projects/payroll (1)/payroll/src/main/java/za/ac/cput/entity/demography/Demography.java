package za.ac.cput.entity.demography;

import org.springframework.stereotype.Service;

import java.util.Objects;


public class Demography {
    private String employeeNumer;
    private String raceId;
    private String genderId;

    private Demography(){

    }

    public Demography(Builder builder){
        this.employeeNumer = builder.employeeNumer;
        this.raceId = builder.raceId;
        this.genderId = builder.genderId;
    }

    public String getEmployeeNumer() {
        return employeeNumer;
    }

    public String getRaceId() {
        return raceId;
    }

    public String getGenderId() {
        return genderId;
    }

    @Override
    public boolean equals(Object o) {
        if (o == null || getClass() != o.getClass()) return false;
        Demography that = (Demography) o;
        return Objects.equals(employeeNumer, that.employeeNumer) && Objects.equals(raceId, that.raceId) && Objects.equals(genderId, that.genderId);
    }

    @Override
    public int hashCode() {
        return Objects.hash(employeeNumer, raceId, genderId);
    }

    @Override
    public String toString() {
        return "Demography{" +
                "employeeNumer='" + employeeNumer + '\'' +
                ", raceId='" + raceId + '\'' +
                ", genderId='" + genderId + '\'' +
                '}';
    }


    public static class Builder{
        private String employeeNumer;
        private String raceId;
        private String genderId;

       public Builder setEmployeeNumer(String employeeNumer){
           this.employeeNumer = employeeNumer;
           return this;
       }

       public Builder setRaceId(String raceId){
           this.raceId = raceId;
           return this;
       }

       public Builder setGenderId(String genderId){
           this.genderId = genderId;
           return this;
       }

       public Builder copy(Demography demography){
           this.employeeNumer = demography.employeeNumer;
           this.raceId = demography.raceId;
           this.genderId = demography.genderId;
           return this;
       }

       public Demography build(){
           return new Demography(this);
       }
    }
}
