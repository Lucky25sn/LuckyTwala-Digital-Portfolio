package za.ac.cput.service.employeedetails.Impl;

import org.springframework.stereotype.Service;
import za.ac.cput.entity.employeedetails.Identity;
import za.ac.cput.repository.employeedetails.IdentityRepository;
import za.ac.cput.repository.employeedetails.Impl.IdentityRepositoryImpl;
import za.ac.cput.service.employeedetails.IdentityService;

import java.util.List;

@Service
public class IdentityServiceImpl implements IdentityService {

private static  IdentityServiceImpl identityService;
private static IdentityRepository identityRepository;

public IdentityServiceImpl() {
    identityRepository = new IdentityRepositoryImpl();
}
public static IdentityServiceImpl getIdentityService(){
    if(identityService==null){
        identityService=new IdentityServiceImpl();
    }
    return identityService;
}

    @Override
    public Identity create(Identity identity) {
        return this.identityRepository.create(identity);
    }

    @Override
    public Identity read(String s) {
        return this.identityRepository.read(s);
    }

    @Override
    public Identity update(Identity identity) {
        return this.identityRepository.update(identity);
    }

    @Override
    public boolean delete(String s) {
        return this.identityRepository.delete(s);
    }
    @Override
    public List<Identity> getAllIdentities() {
        return this.identityRepository.getAllIdentities();
    }
}
