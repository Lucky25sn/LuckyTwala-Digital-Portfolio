package za.ac.cput.repository.employment;

import za.ac.cput.entity.employment.Job;
import za.ac.cput.repository.IRepository;

import java.util.List;

public interface JobRepository extends IRepository<Job, String> {
    List<Job> getAllJob();
    List<Job>getAllJobByTitle(String title);
}
