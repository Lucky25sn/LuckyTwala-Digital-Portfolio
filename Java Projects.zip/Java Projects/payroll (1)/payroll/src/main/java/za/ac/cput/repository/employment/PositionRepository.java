package za.ac.cput.repository.employment;


import za.ac.cput.repository.IRepository;
import za.ac.cput.entity.employment.Position;

import java.util.List;


public interface PositionRepository extends IRepository<Position, String> {
    List<Position> getAllPosition();
    List<Position> getAllByPositionStatus(Position.PositionStatus positionStatus);
}
