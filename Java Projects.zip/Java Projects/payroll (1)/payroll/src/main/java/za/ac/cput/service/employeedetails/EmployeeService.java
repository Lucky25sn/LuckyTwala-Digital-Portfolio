package za.ac.cput.service.employeedetails;

import za.ac.cput.entity.employeedetails.Employee;
import za.ac.cput.service.IService;

import java.util.List;

public interface EmployeeService extends IService<Employee,String> {
    List<Employee> getAllEmployees();
    List<Employee> getEmployeeByNationality(String nationality);
}
