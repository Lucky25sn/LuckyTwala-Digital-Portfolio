package za.ac.cput.repository.demography.Impl;

import za.ac.cput.entity.demography.Demography;
import za.ac.cput.repository.demography.DemographyRepository;

import java.util.ArrayList;
import java.util.List;

public class DemographyRepositoryImpl implements DemographyRepository {
   // create arrayList
    List<Demography> demographyList;

    public DemographyRepositoryImpl() {
        demographyList = new ArrayList<>();
    }

   //Singleton
    private static DemographyRepositoryImpl demographyRepository;

    public static DemographyRepositoryImpl getInstance() {
        if (demographyRepository == null) {
            demographyRepository = new DemographyRepositoryImpl();
        }
        return demographyRepository;
    }

    @Override
    public Demography create(Demography demography) {
        boolean success = demographyList.add(demography);
        if(success) {
            return demography;
        }
        return null;
    }

    @Override
    public Demography read(String s) {
        for (Demography demography : demographyList) {
            if (demography.getEmployeeNumer().equalsIgnoreCase(s)) {
                return demography;
            }
        }
        return null;
    }

    @Override
    public Demography update(Demography demography) {
        Demography oldDemography = read(demography.getEmployeeNumer());
        if (oldDemography == null) {
            return  null;
        }
        demographyList.remove(oldDemography);
        demographyList.add(demography);
        return demography;
    }

    @Override
    public boolean delete(String s) {
        Demography demography = read(s);
        if (demography == null){
            return false;
        }
        return demographyList.remove(demography);
    }

    @Override
    public List<Demography> getAllDemography() {
        return demographyList;
    }

    @Override
    public List<Demography> getDemographyByRace(String race) {
        List<Demography> results = new ArrayList<>();
        for (Demography demography : demographyList) {
            if (demography.getRaceId().equalsIgnoreCase(race)) {
                results.add(demography);
            }
        }
        return results;
    }

    @Override
    public List<Demography> getDemographyByGender(String gender) {
        List<Demography> results = new ArrayList<>();
        for (Demography demography : demographyList) {
            if (demography.getGenderId().equalsIgnoreCase(gender)) {
                results.add(demography);
            }
        }
        return results;
    }
}
