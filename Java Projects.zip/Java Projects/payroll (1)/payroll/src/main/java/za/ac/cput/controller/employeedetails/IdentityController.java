package za.ac.cput.controller.employeedetails;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import za.ac.cput.entity.employeedetails.Identity;
import za.ac.cput.service.contact.AddressService;
import za.ac.cput.service.employeedetails.IdentityService;

import java.util.List;


@RestController
@RequestMapping("/identity")
public class IdentityController {
    private IdentityService identityService ;

    @Autowired
    private IdentityController (IdentityService identityService) {
        this.identityService = identityService;
    };

    @PostMapping("/create")
    public Identity create(@RequestBody Identity identity) {
        return identityService.create(identity);
    }

    @GetMapping("/read/{idenityId}")
   public Identity read(@PathVariable("idenityId") String idenityId){
        return identityService.read(idenityId);
    }

    @PutMapping("/update")
    public Identity update(@RequestBody Identity identity) {
        return identityService.update(identity);
    }

    @DeleteMapping("/delete/{idenityId}")
    public boolean delete(@PathVariable("idenityId") String idenityId){
         return  identityService.delete(idenityId);
    }

    @GetMapping("/getall")
    public List<Identity> getAll(){
        return identityService.getAllIdentities();
    }

}
