package za.ac.cput.controller.contact;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpMethod;
import org.springframework.web.bind.annotation.*;
import za.ac.cput.entity.contact.Address;
import za.ac.cput.service.contact.AddressService;

import java.util.List;

@RestController
@RequestMapping("/address")
public class AddressController {

    private AddressService addressService;

    @Autowired
    public AddressController(AddressService addressService) {
       this.addressService = addressService;
    }

    @PostMapping("/create")
    public Address createAddress(@RequestBody Address address){
        return addressService.create(address);
    }

    @GetMapping("/read/{addressId}")
    public Address readAddress(@PathVariable("addressId") String addressId){
        return addressService.read(addressId);
    }

    @PutMapping("/update")
    public Address updateAddress(@RequestBody Address address){
        return addressService.update(address);
    }

    //@RequestMapping("/delete/{addressId}", HttpMethod = RequestMethod.DELETE)
    @DeleteMapping ("/delete/{addressId}")
    public boolean deleteAddress(@PathVariable("addressId") String addressId){
        return addressService.delete(addressId);
    }

    @GetMapping("/getall")
    public List<Address> getAllAddress(){
        return addressService.getAllAddresses();
    }
}
