package za.ac.cput.entity.demography;

public class Race {
    private String raceId;
    private RaceDescription raceDescription;

    private Race(){

    }

    public Race (Builder builder){
        this.raceId = builder.raceId;
        this.raceDescription = builder.raceDescription;
    }

    public String getRaceId() {
        return raceId;
    }

   public enum RaceDescription{
        BLACK, WHITE, RED, YELLOW;
   }

    @Override
    public String toString() {
        return "Race{" +
                "raceId='" + raceId + '\'' +
                ", raceDescription=" + raceDescription +
                '}';
    }

    public static class Builder{
        private String raceId;
        private RaceDescription raceDescription;

        public Builder setRaceId(String raceId) {
            this.raceId = raceId;
            return this;
        }

        public Builder setRaceDescription(RaceDescription raceDescription) {
            this.raceDescription = raceDescription;
            return this;
        }

        public Builder copy(Race race){
            this.raceId = race.raceId;
            this.raceDescription = race.raceDescription;
            return this;
        }

        public Race build(){
            return new Race(this);
        }
    }
}
