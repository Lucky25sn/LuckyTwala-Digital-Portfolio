package za.ac.cput.service.demography;

import za.ac.cput.entity.demography.Gender;
import za.ac.cput.service.IService;

import java.util.List;

public interface GenderService  extends IService<Gender, String> {
    List<Gender> getAllGenders();
}
