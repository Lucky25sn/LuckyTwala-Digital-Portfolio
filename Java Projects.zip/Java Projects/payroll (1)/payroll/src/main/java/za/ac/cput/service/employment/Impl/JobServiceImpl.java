package za.ac.cput.service.employment.Impl;

import org.springframework.stereotype.Service;
import za.ac.cput.entity.employment.Job;
import za.ac.cput.repository.employment.Impl.JobRepositoryImpl;
import za.ac.cput.repository.employment.JobRepository;
import za.ac.cput.service.employment.JobService;

import java.util.List;

@Service
public class JobServiceImpl implements JobService {

    private static JobService jobService = null;

    private JobRepository jobRepository;

    private JobServiceImpl() {
        this.jobRepository = new JobRepositoryImpl();
    }

    public static JobService getJobService() {
        if (jobService == null) {
            jobService = new JobServiceImpl();
        }
        return jobService;
    }
    @Override
    public Job create(Job job) {
        return this.jobRepository.create(job);
    }

    @Override
    public Job read(String s) {
        return this.jobRepository.read(s);
    }

    @Override
    public Job update(Job job) {
        return this.jobRepository.update(job);
    }

    @Override
    public boolean delete(String s) {
        return this.jobRepository.delete(s);
    }
    @Override
    public List<Job> getAllJob() {
        return this.jobRepository.getAllJob();
    }

    @Override
    public List<Job> getAllJobByTitle(String title) {
        return this.jobRepository.getAllJobByTitle(title);
    }

}
