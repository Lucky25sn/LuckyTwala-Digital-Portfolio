package za.ac.cput.factory.contact;

import za.ac.cput.entity.contact.Address;
import za.ac.cput.util.Helper;

public class AddressFactory {
    public static Address createAddress(String streetAddress, String postalAddress,
                                        String city, String province, String country  ){

        String addressId = Helper.generatedUUI();

       if( Helper.isEmptyorNull(streetAddress)
          || Helper.isEmptyorNull(city)
          || Helper.isEmptyorNull(province)
          || Helper.isEmptyorNull(country)){
           return null;
         }

        return new Address.Builder()
                .setAddressId(addressId)
                .setStreetAddress(streetAddress)
                .setPostalAddress(postalAddress)
                .setCity(city)
                .setProvince(province)
                .setCountry(country)
                .build();

    }
}
