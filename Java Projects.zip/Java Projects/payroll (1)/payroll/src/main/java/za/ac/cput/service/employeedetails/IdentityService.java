package za.ac.cput.service.employeedetails;

import za.ac.cput.entity.employeedetails.Identity;
import za.ac.cput.service.IService;

import java.util.List;

public interface IdentityService extends IService<Identity,String> {
    List<Identity> getAllIdentities();
}
