package za.ac.cput.service.employment.Impl;

import za.ac.cput.entity.employment.Position;
import za.ac.cput.repository.employment.Impl.PositionRepositoryImpl;
import za.ac.cput.repository.employment.PositionRepository;
import za.ac.cput.service.employment.PositionService;

import java.util.List;

public class PositionServiceImpl implements PositionService {

    private static PositionService positionService;

    private  PositionRepository positionRepository = null;

    private PositionServiceImpl() {
            positionRepository = new PositionRepositoryImpl();
    }

    public static PositionService getPositionService() {
        if (positionService == null) {
            positionService = new PositionServiceImpl();
        }
        return positionService;
    }

    @Override
    public Position create(Position position) {
        return this.positionRepository.create(position);
    }

    @Override
    public Position read(String s) {
        return this.positionRepository.read(s);
    }

    @Override
    public Position update(Position position) {
        return this.positionRepository.update(position);
    }

    @Override
    public boolean delete(String s) {
        return this.positionRepository.delete(s);
    }
    @Override
    public List<Position> getAllPosition() {
        return this.positionRepository.getAllPosition();
    }

    @Override
    public List<Position> getAllByPositionStatus(Position.PositionStatus positionStatus) {
        return this.positionRepository.getAllByPositionStatus(positionStatus) ;
    }

}
