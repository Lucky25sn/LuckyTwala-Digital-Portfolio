package za.ac.cput.service.demography;

import za.ac.cput.entity.demography.Race;
import za.ac.cput.repository.IRepository;

import java.util.List;

public interface RaceService extends IRepository<Race, String> {
    List<Race> getAllRaces();
}
