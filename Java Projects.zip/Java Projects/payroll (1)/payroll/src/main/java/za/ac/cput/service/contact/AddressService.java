package za.ac.cput.service.contact;

import za.ac.cput.entity.contact.Address;
import za.ac.cput.service.IService;

import java.util.List;

public interface AddressService extends IService<Address,String> {
    List<Address> getAllAddresses();
    List<Address> getAllAddressByProvinces(String province);
    List<Address> getAllAddressByCities(String city);
}
