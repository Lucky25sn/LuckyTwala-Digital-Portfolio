package za.ac.cput.factory.demography;

import za.ac.cput.entity.demography.Race;
import za.ac.cput.util.Helper;

public class RaceFactory {
    public static Race createRace( Race.RaceDescription raceDescription) {
       String  raceId = Helper.generatedUUI();

       if(Helper.isEmptyorNull(raceId)){
           return null;
       }
        return  new Race.Builder()
                .setRaceId(raceId)
                .setRaceDescription(raceDescription)
                .build();
    }
}
