package za.ac.cput.repository.employeedetails.Impl;

import za.ac.cput.entity.employeedetails.Identity;
import za.ac.cput.repository.employeedetails.IdentityRepository;

import java.util.ArrayList;
import java.util.List;

public class IdentityRepositoryImpl implements IdentityRepository {

    List<Identity> identitiesList;
    public IdentityRepositoryImpl(){
        identitiesList = new ArrayList<>();
    }

    private static IdentityRepositoryImpl identityRepository;

    public static IdentityRepositoryImpl getIdentityRepository() {
        if (identityRepository == null) {
            identityRepository = new IdentityRepositoryImpl();
        }
        return identityRepository;
    }

    @Override
    public Identity create(Identity identity) {
        boolean success = identitiesList.add(identity);
        if (success) {
            return identity;
        }
        return null;
    }

    @Override
    public Identity read(String s) {
        for (Identity identity : identitiesList) {
            if(identity.getIdentityId().equalsIgnoreCase(s)){
                return identity;
            }
        }
        return null;
    }

    @Override
    public Identity update(Identity identity) {
        Identity oldidentity = read(identity.getIdentityId());
        if(oldidentity==null){
            return null;
        }
        identitiesList.remove(oldidentity);
        identitiesList.add(identity);
        return identity;
    }

    @Override
    public boolean delete(String s) {
        Identity identity = read(s);
        if(identity==null){
            return false;
        }
        return identitiesList.remove(identity);
    }

    @Override
    public List<Identity> getAllIdentities() {
        return identitiesList;
    }

}
