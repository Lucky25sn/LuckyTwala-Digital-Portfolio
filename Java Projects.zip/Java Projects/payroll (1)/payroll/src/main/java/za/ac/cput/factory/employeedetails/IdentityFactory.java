package za.ac.cput.factory.employeedetails;

import za.ac.cput.entity.employeedetails.Identity;
import za.ac.cput.util.Helper;

public class IdentityFactory {
    public static Identity createIdentity( String identityType, String employeenumber, String value){

      String  identityId = Helper.generatedUUI();
        return  new Identity.Builder()
                .setIdentityId(identityId)
                .setIdentityType(identityType)
                .setEmployeeNumber(employeenumber)
                .setValue(value).build();
    }
}
