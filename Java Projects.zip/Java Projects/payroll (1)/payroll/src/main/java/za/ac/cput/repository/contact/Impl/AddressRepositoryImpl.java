package za.ac.cput.repository.contact.Impl;

import za.ac.cput.entity.contact.Address;
import za.ac.cput.repository.IRepository;
import za.ac.cput.repository.contact.AddressRepository;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class AddressRepositoryImpl implements AddressRepository {

    List<Address> addressList;// contain unique value;

    public AddressRepositoryImpl(){
        addressList = new ArrayList<>();
    }

    ///Singleton pattern
    private static AddressRepositoryImpl addressRepository;

    public static AddressRepositoryImpl getAddressRepository() {
        if (addressRepository == null) {
            addressRepository = new AddressRepositoryImpl();
        }
        return addressRepository;
    }

    @Override
    public Address create(Address address) {
       boolean success = addressList.add(address);
       if (success) {
           return address;
       }
        return null;
    }

    @Override
    public Address read(String s) {
        for (Address address : addressList) {
            if(address.getAddressId().equalsIgnoreCase(s)){
                return address;
            }
        }
        return null;
    }

    @Override
    public Address update(Address address) {
        Address oldAddress = read(address.getAddressId());
        if (oldAddress == null) {
            return null;
        }
        addressList.remove(oldAddress);
        addressList.add(address);
         return address;
    }

    @Override
    public boolean delete(String s) {
        Address address = read(s);
        if (address == null) {
            return false;
        }
        return addressList.remove(address);
    }

    @Override
    public List<Address> getAllAddresses() {
        return addressList;
    }

    @Override
    public List<Address> getAllAddressByProvinces(String province) {
        List<Address> results = new ArrayList<>();
        for (Address address : addressList) {
            if(address.getProvince().equalsIgnoreCase(province)){
                results.add(address);
            }
        }
        return results;
    }

    @Override
    public List<Address> getAllAddressByCities(String city) {
        List<Address> results = new ArrayList<>();
        for (Address address : addressList) {
            if(address.getCity().equalsIgnoreCase(city)){
                results.add(address);
            }
        }
        return results;
    }
}
