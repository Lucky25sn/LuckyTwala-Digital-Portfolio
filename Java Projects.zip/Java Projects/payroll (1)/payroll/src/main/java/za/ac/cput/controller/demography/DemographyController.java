package za.ac.cput.controller.demography;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import za.ac.cput.entity.demography.Demography;
import za.ac.cput.service.demography.DemographyService;

import java.util.List;

@RestController
@RequestMapping("demograpgy")
public class DemographyController {

    private DemographyService demographyService;

    @Autowired
    public DemographyController(DemographyService demographyService) {
        this.demographyService = demographyService;
    }

    @PostMapping("/create")
    public Demography createDemography(@RequestBody Demography demography) {
        return this.demographyService.create(demography);
    }

    @GetMapping("/read/{demographyid}")
    public Demography readDemography(@PathVariable String demographyId) {
        return this.demographyService.read(demographyId);
    }

    @PutMapping("/update")
    public Demography updateDemography(@RequestBody Demography demography) {
        return this.demographyService.update(demography);
    }

    @DeleteMapping("/delete/{demographyId}")
    public boolean deleteDemography(@PathVariable String demographyId) {
        return this.demographyService.delete(demographyId);
    }

    @GetMapping("/getall")
    public List<Demography> getAllDemography() {
        return this.demographyService.getAllDemography();

    }
}
