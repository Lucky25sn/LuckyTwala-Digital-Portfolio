package za.ac.cput.service.demography.Impl;

import org.springframework.stereotype.Service;
import za.ac.cput.entity.demography.Gender;
import za.ac.cput.repository.demography.GenderRepository;
import za.ac.cput.repository.demography.Impl.GenderRepositoryImpl;
import za.ac.cput.service.demography.GenderService;

import java.util.List;

@Service
public class GenderServiceImpl implements GenderService {

    private static GenderService genderService;

    private  GenderRepository genderRepository;

    private GenderServiceImpl(){
        this.genderRepository = new GenderRepositoryImpl();
    }

    public static GenderService getGenderService(){
        if(genderService==null){
            genderService=new GenderServiceImpl();
        }
        return genderService;
    }
    @Override
    public Gender create(Gender gender) {
        return this.genderRepository.create(gender);
    }

    @Override
    public Gender read(String s) {
        return this.genderRepository.read(s);
    }

    @Override
    public Gender update(Gender gender) {
        return this.genderRepository.update(gender);
    }

    @Override
    public boolean delete(String s) {
        return this.genderRepository.delete(s);
    }

    @Override
    public List<Gender> getAllGenders() {
        return this.genderRepository.getAllGenders();
    }

}
