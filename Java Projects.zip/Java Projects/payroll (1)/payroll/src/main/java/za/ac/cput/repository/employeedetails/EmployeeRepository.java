package za.ac.cput.repository.employeedetails;

import za.ac.cput.entity.employeedetails.Employee;
import za.ac.cput.repository.IRepository;

import java.util.List;

public interface EmployeeRepository  extends IRepository<Employee,String> {
    List<Employee>getAllEmployees();
    List<Employee> getEmployeeByNationality(String nationality);
}
