package za.ac.cput.service.contact;

import za.ac.cput.entity.contact.Contact;
import za.ac.cput.service.IService;

import java.util.List;

public interface ContactService extends IService<Contact,String> {
    List<Contact> getAllContacts();
}
