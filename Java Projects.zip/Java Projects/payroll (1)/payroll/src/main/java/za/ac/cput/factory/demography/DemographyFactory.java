package za.ac.cput.factory.demography;

import za.ac.cput.entity.contact.Contact;
import za.ac.cput.entity.demography.Demography;
import za.ac.cput.util.Helper;

public class DemographyFactory {
    public static Demography createDemography(String raceId, String genderId){

        String employeeNumer = Helper.generatedUUI();
        if(Helper.isEmptyorNull(raceId)
                || Helper.isEmptyorNull(genderId)){
            return null;
        }
        return new Demography.Builder()
                .setEmployeeNumer(employeeNumer)
                .setGenderId(genderId)
                .setRaceId(raceId)
                .build();
    }

    public static Demography createDemography(String genderID){
       if(!Helper.isEmptyorNull(genderID)){
           return  null;
       }
        String employeeNumer = Helper.generatedUUI();
       return new Demography.Builder()
               .setEmployeeNumer(employeeNumer)
               .setGenderId(genderID)
               .build();
    }
}
