package za.ac.cput.repository.employment;

import za.ac.cput.entity.employment.Employment;
import za.ac.cput.repository.IRepository;

import java.util.List;

public interface EmploymentRepository extends IRepository<Employment, String> {
    List<Employment> getAllEmployment();
    List<Employment>getEmploymentByType(Employment.EmploymentType type);
}
