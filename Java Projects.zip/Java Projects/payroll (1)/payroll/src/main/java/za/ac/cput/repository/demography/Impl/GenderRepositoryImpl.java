package za.ac.cput.repository.demography.Impl;

import za.ac.cput.entity.demography.Gender;
import za.ac.cput.repository.demography.GenderRepository;

import java.util.ArrayList;
import java.util.List;

public class GenderRepositoryImpl implements GenderRepository {
  List<Gender> genderList;
   public GenderRepositoryImpl() {
       genderList = new ArrayList<>();
   }

   private static GenderRepositoryImpl genderRepository;

   public static  GenderRepositoryImpl getGenderRepository() {
       if (genderRepository == null) {
           genderRepository = new GenderRepositoryImpl();
       }
       return genderRepository;
   }

    @Override
    public Gender create(Gender gender) {
       boolean success = genderList.add(gender);
       if (success) {
           return gender;
       }
        return null;
    }

    @Override
    public Gender read(String s) {
       for (Gender gender : genderList) {
           if(gender.getGenderId().equals(s)){
               return gender;
           }
       }
        return null;
    }

    @Override
    public Gender update(Gender gender) {
      Gender oldGender = read(gender.getGenderId());
      if(oldGender == null){
          return null;
      }
      genderList.remove(oldGender);
      genderList.add(gender);

        return gender;
    }

    @Override
    public boolean delete(String s) {
       Gender gender = read(s);
       if(gender == null){
           return false;
       }
        return genderList.remove(gender);
    }

    @Override
    public List<Gender> getAllGenders() {
        return genderList;
    }

}
