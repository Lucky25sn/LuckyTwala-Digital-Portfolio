package za.ac.cput.factory.employment;

import za.ac.cput.entity.employment.Employment;
import za.ac.cput.util.Helper;

public class EmploymentFactory {
    public static Employment createEmployment( Employment.EmploymentType employmentType, String employmentDescription){
        String employmentId = Helper.generatedUUI();
        if(Helper.isEmptyorNull(employmentId)){
            return null;
        }
        return  new Employment.Builder()
                .setEmploymentId(employmentId)
                .setEmploymentType(employmentType)
                .setEmploymentDescription(employmentDescription)
                .build();
    }
}
