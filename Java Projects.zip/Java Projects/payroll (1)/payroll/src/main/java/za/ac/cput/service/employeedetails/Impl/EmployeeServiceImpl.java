package za.ac.cput.service.employeedetails.Impl;

import org.springframework.stereotype.Service;
import za.ac.cput.entity.employeedetails.Employee;
import za.ac.cput.repository.employeedetails.EmployeeRepository;
import za.ac.cput.repository.employeedetails.Impl.EmployeeRepositoryImpl;
import za.ac.cput.service.employeedetails.EmployeeService;

import java.util.List;

@Service
public class EmployeeServiceImpl implements EmployeeService {

    private static EmployeeServiceImpl employeeService;

    private static EmployeeRepository  employeeRepository;

    public  EmployeeServiceImpl(){
        employeeRepository = new EmployeeRepositoryImpl();
    }

    public static EmployeeServiceImpl getEmployeeService(){
        if(employeeService==null){
            employeeService = new EmployeeServiceImpl();
        }
        return employeeService;
    }

    @Override
    public Employee create(Employee employee) {
        return this.employeeRepository.create(employee);
    }

    @Override
    public Employee read(String s) {
        return this.employeeRepository.read(s);
    }

    @Override
    public Employee update(Employee employee) {
        return this.employeeRepository.update(employee);
    }

    @Override
    public boolean delete(String s) {
        return this.employeeRepository.delete(s);
    }

    @Override
    public List<Employee> getAllEmployees() {
        return this.employeeRepository.getAllEmployees();
    }

    @Override
    public List<Employee> getEmployeeByNationality(String nationality) {
        return this.employeeRepository.getEmployeeByNationality(nationality);
    }
}
