package za.ac.cput.entity.employment;

public class Position {
    private String positionID;
    private short positionCode;
    private PositionStatus positionStatus;


    private Position(){

    }

    public Position (Builder builder){
      this.positionID = builder.positionID;
      this.positionCode = builder.positionCode;
      this.positionStatus = builder.positionStatus;
    }

    public String getPositionID() {
        return positionID;
    }
    public short getPositionCode() {
        return positionCode;
    }

       public PositionStatus getPositionStatus() {
        return positionStatus;
    }

    public enum PositionStatus {OPEN, CLOSED};

    @Override
    public String toString() {
        return "Position{" +
                "positionID='" + positionID + '\'' +
                ", positionCode=" + positionCode +
                ", positionStatus=" + positionStatus +
                '}';
    }

    public static class Builder{
        private String positionID;
        private short positionCode;
        private PositionStatus positionStatus =  PositionStatus.OPEN;

        public Builder positionID(String positionID){
            this.positionID = positionID;
            return this;
        }
        public Builder setPositionCode(short positionCode){
            this.positionCode = positionCode;
            return this;
        }

        public Builder setPositionStatus(PositionStatus positionStatus){
            this.positionStatus = positionStatus;
            return this;
        }

        public Builder copy(Position builder){
            this.positionID = builder.positionID;
            this.positionCode = builder.positionCode;
            this.positionStatus = builder.positionStatus;
            return this;
        }

        public Position build(){
            return new Position(this);
        }
    }
}
