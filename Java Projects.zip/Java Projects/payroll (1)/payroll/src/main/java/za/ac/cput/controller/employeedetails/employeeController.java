package za.ac.cput.controller.employeedetails;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import za.ac.cput.entity.employeedetails.Employee;
import za.ac.cput.service.employeedetails.EmployeeService;

import java.util.List;

@RestController
@RequestMapping("/employee")
public class employeeController {

    private EmployeeService employeeService;

    @Autowired
    public employeeController(EmployeeService employeeService) {
        this.employeeService = employeeService;
    }

    @PostMapping("/create")
    public Employee createEmployee(@RequestBody Employee employee) {
        return employeeService.create(employee);
    }

    @GetMapping("/read/{employnumber}")
    public Employee readEmployee(@PathVariable("employnumber") String employnumber) {
        return employeeService.read(employnumber);
    }

    @PutMapping("/update")
    public Employee updateEmployee(@RequestBody Employee employee) {
        return employeeService.update(employee);
    }

    @DeleteMapping("/delete/{employnumber}")
    public boolean deleteEmployee(@PathVariable("employnumber") String employee){
        return employeeService.delete(employee);
    }

    @GetMapping("/getall")
    public List<Employee> getAllEmployees() {
        return employeeService.getAllEmployees();
    }

    @GetMapping("/getall/{nationality}")
    public List<Employee> getAllEmployees(@PathVariable ("nationality") String nationality) {
        return employeeService.getEmployeeByNationality(nationality);
    }

}
