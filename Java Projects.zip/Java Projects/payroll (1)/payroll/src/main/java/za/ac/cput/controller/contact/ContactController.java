package za.ac.cput.controller.contact;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import za.ac.cput.entity.contact.Contact;
import za.ac.cput.service.contact.ContactService;

import java.util.List;

@RestController()
@RequestMapping("/contact")
public class ContactController {
    private ContactService contactService;

    @Autowired
    public ContactController(ContactService contactService) {
        this.contactService = contactService;
    }

    @PostMapping("/create")
    public Contact createContact(@RequestBody Contact contact){
        return contactService.create(contact);
    }

    @GetMapping("/read/{contactid}")
    public Contact readContact(@PathVariable("contactid") String contactid){
        return contactService.read(contactid);
    }

    @PutMapping("/update")
    public Contact updateContact(@RequestBody Contact contact){
        return contactService.update(contact);
    }

    @DeleteMapping("/delete/{id}")
    public boolean deleteContact(@PathVariable("id") String id){
        return contactService.delete(id);
    }

    @GetMapping("/getall")
    public List<Contact> getAllContacts(){
        return contactService.getAllContacts();
    }
}
