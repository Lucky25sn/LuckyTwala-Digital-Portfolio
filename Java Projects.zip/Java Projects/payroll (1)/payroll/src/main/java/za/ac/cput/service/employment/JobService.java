package za.ac.cput.service.employment;

import za.ac.cput.entity.employment.Job;
import za.ac.cput.service.IService;

import java.util.List;

public interface JobService extends IService<Job, String> {
    List<Job> getAllJob();
    List<Job> getAllJobByTitle(String title);
}
