package za.ac.cput.service.demography.Impl;

import org.springframework.stereotype.Service;
import za.ac.cput.entity.demography.Race;
import za.ac.cput.repository.demography.Impl.RaceRepositoryImpl;
import za.ac.cput.repository.demography.RaceRepository;
import za.ac.cput.service.demography.RaceService;

import java.util.List;

@Service
public class RaceServiceImpl implements RaceService {
private static RaceService raceService = null;

private static RaceRepository raceRepository;;

private RaceServiceImpl(){
    this.raceRepository=new RaceRepositoryImpl();
}

public static RaceService getRaceService(){
    if(raceService==null){
        raceService=new RaceServiceImpl();
    }
    return raceService;
}
    @Override
    public Race create(Race race) {
        return this.raceRepository.create(race);
    }

    @Override
    public Race read(String s) {
        return this.raceRepository.read(s);
    }

    @Override
    public Race update(Race race) {
        return this.raceRepository.update(race);
    }

    @Override
    public boolean delete(String s) {
        return this.raceRepository.delete(s);
    }

    @Override
    public List<Race> getAllRaces() {
        return this.raceRepository.getAllRaces();
    }

}
