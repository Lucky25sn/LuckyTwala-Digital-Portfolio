package za.ac.cput.factory.employeedetails;

import za.ac.cput.entity.employeedetails.Employee;
import za.ac.cput.util.Helper;

public class EmployeeFactory {
    public static Employee createEmployee(String employeeNumber,String firstName,String lastName,String nationality){

        if(Helper.isEmptyorNull(employeeNumber)
        || Helper.isEmptyorNull(firstName)
        || Helper.isEmptyorNull(lastName)
        || Helper.isEmptyorNull(nationality)){
            return null;
        }

        return new Employee.Builder()
                .setEmployeeNumber(employeeNumber)
                .setFirstName(firstName)
                .setLastName(lastName)
                .setNationality(nationality)
                .build();
    }
}
