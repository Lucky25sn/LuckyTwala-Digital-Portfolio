package za.ac.cput.factory.contact;

import za.ac.cput.entity.contact.Contact;
import za.ac.cput.util.Helper;

public class ContactFactory {
    public static Contact createContact(String cellNumber, String homeNumber, String email){

        if(Helper.isEmptyorNull(cellNumber) && Helper.isEmptyorNull(homeNumber)){
            return null;
        }
       if(!Helper.IsValidEmail(email)){
           return null;
       }
        return  new Contact.Builder()
                .setCellNumber(cellNumber)
                .setHomeNumber(homeNumber)
                .setEmail(email)
                .build();

    }
}
