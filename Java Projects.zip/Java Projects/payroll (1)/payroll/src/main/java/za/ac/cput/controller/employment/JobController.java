package za.ac.cput.controller.employment;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import za.ac.cput.entity.employment.Job;
import za.ac.cput.service.employment.JobService;

import java.util.List;

@RestController
@RequestMapping("/job")
public class JobController {
    private JobService jobService;

    @Autowired
    public JobController(JobService jobService) {
        this.jobService = jobService;
    }

    @PostMapping("/read")
    public Job read(@RequestBody Job job) {
        return jobService.create(job);
    }

    @GetMapping("/read/{jobId}")
    public Job read(@PathVariable("jobId") String jobId) {
        return jobService.read(jobId);
    }

    @PutMapping("/update")
    public Job update(@RequestBody Job job) {
        return jobService.update(job);
    }

    @DeleteMapping("/delete/{jobId}")
    public boolean delete(@PathVariable("jobId") String jobId) {
        return jobService.delete(jobId);
    }

    @GetMapping("/getall")
    public List<Job> getAll() {
        return jobService.getAllJob();
    }

}
