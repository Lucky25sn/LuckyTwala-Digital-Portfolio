package za.ac.cput.repository.contact.Impl;

import za.ac.cput.entity.contact.Contact;
import za.ac.cput.repository.contact.ContactRepository;

import java.util.ArrayList;
import java.util.List;

public class ContactRepositoryImpl implements ContactRepository {

    List<Contact> contactList;
    public ContactRepositoryImpl(){
        contactList = new ArrayList<>();
    }

    //Singleton
    private static ContactRepositoryImpl contactRepository;

    public static ContactRepositoryImpl getInstance(){
        if(contactRepository == null){
            contactRepository = new ContactRepositoryImpl();
        }
        return contactRepository;
    }

    @Override
    public Contact create(Contact contact) {
        boolean success = contactList.add(contact);
        if(success){
            return contact;
        }
        return null;
    }

    @Override
    public Contact read(String s) {
        for(Contact contact : contactList){
            if(contact.getCellNumber().equalsIgnoreCase(s)){
                return contact;
            }
        }
        return null;
    }

    @Override
    public Contact update(Contact contact) {
        Contact oldcontact = read(contact.getCellNumber());
        if(oldcontact == null){
            return null;
        }
        contactList.remove(oldcontact);
        contactList.add(contact);
        return contact;
    }

    @Override
    public boolean delete(String s) {
       Contact contact = read(s);
       if(contact == null){
           return false;
       }
        return contactList.remove(contact);
    }

    @Override
    public List<Contact> getAllContacts() {
        return contactList;
    }
}
