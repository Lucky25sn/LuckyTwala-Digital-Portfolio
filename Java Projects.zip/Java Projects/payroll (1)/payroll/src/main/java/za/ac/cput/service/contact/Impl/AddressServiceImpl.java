package za.ac.cput.service.contact.Impl;

import org.springframework.stereotype.Service;
import za.ac.cput.entity.contact.Address;
import za.ac.cput.repository.contact.AddressRepository;
import za.ac.cput.repository.contact.Impl.AddressRepositoryImpl;
import za.ac.cput.service.contact.AddressService;

import java.util.ArrayList;
import java.util.List;

@Service
public class AddressServiceImpl implements AddressService {

    private static AddressService addressService = null;

    private AddressRepository addressRepository;


   private AddressServiceImpl(){
       this.addressRepository = new AddressRepositoryImpl();
   }

   public static AddressService getAddressService(){
       if(addressService==null){
           addressService = new AddressServiceImpl();
       }
       return addressService;
   }


    @Override
    public Address create(Address address) {
        return this.addressRepository.create(address);
    }

    @Override
    public Address read(String s) {
        return this.addressRepository.read(s);
    }

    @Override
    public Address update(Address address) {
        return this.addressRepository.update(address);
    }

    @Override
    public boolean delete(String s) {
        return this.addressRepository.delete(s);
    }

    @Override
    public List<Address> getAllAddresses() {
        return this.addressRepository.getAllAddresses();
    }

    @Override
    public List<Address> getAllAddressByProvinces(String province) {
        return this.addressRepository.getAllAddressByProvinces(province);
    }

    @Override
    public List<Address> getAllAddressByCities(String city) {
        return this.addressRepository.getAllAddressByCities(city);
    }
}
