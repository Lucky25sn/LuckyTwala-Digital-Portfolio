package za.ac.cput.entity.employment;

public class Job {
    private String jobId;
    private String jobtitle;
    private String jobDescription;


    private Job(){

    }

    public Job(Builder builder){
      this.jobId = builder.jobId;
      this.jobtitle = builder.jobtitle;
      this.jobDescription = builder.jobDescription;
    }

    public String getJobId() {
        return jobId;
    }

    public String getJobDescription() {
        return jobDescription;
    }

    public String getJobtitle() {
        return jobtitle;
    }

    @Override
    public String toString() {
        return "Job{" +
                "jobId='" + jobId + '\'' +
                ", jobtitle='" + jobtitle + '\'' +
                ", jobDescription='" + jobDescription + '\'' +
                '}';
    }

    public static class Builder{
        private String jobId;
        private String jobtitle;
        private String jobDescription;

        public Builder setJobId(String jobId) {
            this.jobId = jobId;
            return this;
        }

        public Builder setJobDescription(String jobDescription) {
            this.jobDescription = jobDescription;
            return this;
        }

        public Builder setJobtitle(String jobtitle) {
            this.jobtitle = jobtitle;
            return this;
        }

        public Builder copy(Job job){
            this.jobId = job.jobId;
            this.jobtitle = job.jobtitle;
            this.jobDescription = job.jobDescription;
            return this;
        }

        public Job build(){
            return new Job(this);
        }
    }
}
