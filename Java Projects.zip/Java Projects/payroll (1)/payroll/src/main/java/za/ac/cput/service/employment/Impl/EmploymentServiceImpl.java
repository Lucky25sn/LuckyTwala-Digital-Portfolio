package za.ac.cput.service.employment.Impl;

import org.springframework.stereotype.Service;
import za.ac.cput.entity.employment.Employment;
import za.ac.cput.repository.employment.EmploymentRepository;
import za.ac.cput.repository.employment.Impl.EmploymentRepositoryImpl;
import za.ac.cput.service.employment.EmploymentService;

import java.util.List;

@Service
public class EmploymentServiceImpl implements EmploymentService {
    private  static EmploymentService employmentService;
    private static EmploymentRepository employmentRepository;

    private EmploymentServiceImpl() {
        employmentRepository = new EmploymentRepositoryImpl();
    }

    public static EmploymentService getEmploymentService() {
        if (employmentService == null) {
            employmentService = new EmploymentServiceImpl();
        }
        return employmentService;
    }

    @Override
    public Employment create(Employment employment) {
        return this.employmentRepository.create(employment);
    }

    @Override
    public Employment read(String s) {
        return this.employmentRepository.read(s);
    }

    @Override
    public Employment update(Employment employment) {
        return this.employmentRepository.update(employment);
    }

    @Override
    public boolean delete(String s) {
        return this.employmentRepository.delete(s);
    }

    @Override
    public List<Employment> getAllEmployment() {
        return this.employmentRepository.getAllEmployment();
    }

    @Override
    public List<Employment> getEmploymentByType(Employment.EmploymentType type) {
        return this.employmentRepository.getEmploymentByType(type);
    }

}
