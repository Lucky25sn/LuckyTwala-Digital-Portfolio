package za.ac.cput.entity.employment;

public class Employment {
    private String employmentId;
    private EmploymentType employmentType;
    private String employmentDescription;

    private Employment(Builder builder){
        this.employmentId = builder.employmentId;
        this.employmentType = builder.employmentType;
        this.employmentDescription = builder.employmentDescription;

    }

    public String getEmploymentId() {
        return employmentId;
    }

    public String getEmploymentDescription() {
        return employmentDescription;
    }

    public enum EmploymentType{CONTRACT,PERMANENT}

    public EmploymentType getEmploymentType() {
        return employmentType;
    }

    @Override
    public String toString() {
        return "Employment{" +
                "employmentId='" + employmentId + '\'' +
                ", employmentType=" + employmentType +
                ", employmentDescription='" + employmentDescription + '\'' +
                '}';
    }

    public static class Builder{
        private String employmentId;
        private EmploymentType  employmentType;
        private String employmentDescription;

       public Builder setEmploymentId(String employmentId){
           this.employmentId = employmentId;
           return this;
       }

       public Builder setEmploymentType(EmploymentType employmentType){
           this.employmentType = employmentType;
           return this;
       }

       public Builder setEmploymentDescription(String employmentDescription){
           this.employmentDescription = employmentDescription;
           return this;
       }

       public Builder copy(Employment employment){
           this.employmentId = employment.employmentId;
           this.employmentType = employment.employmentType;
           this.employmentDescription = employment.employmentDescription;
           return this;
       }

        public Employment build(){
            return new Employment(this);
        }
    }
}
