package za.ac.cput.service.demography.Impl;

import org.springframework.stereotype.Service;
import za.ac.cput.entity.demography.Demography;
import za.ac.cput.repository.demography.DemographyRepository;
import za.ac.cput.repository.demography.Impl.DemographyRepositoryImpl;
import za.ac.cput.service.demography.DemographyService;

import java.util.List;

@Service
public class DemographyServiceImpl implements DemographyService {

    private static DemographyServiceImpl demographyService;

    private DemographyRepository demographyRepository;

    private DemographyServiceImpl(){
        this.demographyRepository = new DemographyRepositoryImpl();
    }
    public static  DemographyServiceImpl getDemographyService(){
        if(demographyService == null){
            demographyService = new DemographyServiceImpl();
        }
        return demographyService;
    }

    @Override
    public Demography create(Demography demography) {
        return this.demographyRepository.create(demography);
    }

    @Override
    public Demography read(String s) {
        return this.demographyRepository.read(s);
    }

    @Override
    public Demography update(Demography demography) {
        return this.demographyRepository.update(demography);
    }

    @Override
    public boolean delete(String s) {
        return false;
    }
    @Override
    public List<Demography> getAllDemography() {
        return this.demographyRepository.getAllDemography();
    }

    @Override
    public List<Demography> getDemographyByRace(String race) {
        return this.demographyRepository.getDemographyByRace(race);
    }

    @Override
    public List<Demography> getDemographyByGender(String gender) {
        return this.demographyRepository.getDemographyByGender(gender);
    }

}
