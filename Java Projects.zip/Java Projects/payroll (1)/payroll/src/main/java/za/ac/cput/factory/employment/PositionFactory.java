package za.ac.cput.factory.employment;

import za.ac.cput.entity.employment.Position;
import za.ac.cput.util.Helper;

public class PositionFactory {
    public static Position createPosition(short positionCode, Position.PositionStatus positionStatus) {
       String positionID = Helper.generatedUUI();
        if(!Helper.isValidCode(positionCode)){
            return null;
        }
        return new Position.Builder()
                .positionID(positionID)
                .setPositionCode(positionCode)
                .setPositionStatus(positionStatus)
                .build();
    }
}
