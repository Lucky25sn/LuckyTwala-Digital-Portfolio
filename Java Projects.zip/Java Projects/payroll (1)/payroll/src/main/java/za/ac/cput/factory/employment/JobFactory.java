package za.ac.cput.factory.employment;

import za.ac.cput.entity.employment.Job;
import za.ac.cput.util.Helper;

public class JobFactory {
    public static Job createJob(String title, String jobDescription){
        String jobId = Helper.generatedUUI();
        if(Helper.isEmptyorNull(jobDescription)){
            return null;
        }

        return new Job.Builder()
                .setJobId(jobId)
                .setJobtitle(title)
                .setJobDescription(jobDescription)
                .build();
    }
}
