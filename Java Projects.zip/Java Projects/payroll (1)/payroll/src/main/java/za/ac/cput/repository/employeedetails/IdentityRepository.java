package za.ac.cput.repository.employeedetails;

import za.ac.cput.entity.employeedetails.Identity;
import za.ac.cput.repository.IRepository;

import java.util.List;

public interface IdentityRepository extends IRepository<Identity, String> {
    List<Identity> getAllIdentities();
}
