package za.ac.cput.repository.employment.Impl;

import za.ac.cput.entity.employment.Employment;
import za.ac.cput.repository.employment.EmploymentRepository;

import java.util.ArrayList;
import java.util.List;

public class EmploymentRepositoryImpl implements EmploymentRepository {

    //List of employments
    List<Employment> employmentList;
    public EmploymentRepositoryImpl() {
     employmentList = new ArrayList<>();
 }
   //Singleton
    private static EmploymentRepositoryImpl employmentRepository = null;

    public static EmploymentRepositoryImpl getRepository() {
        if (employmentRepository == null) {
            employmentRepository = new EmploymentRepositoryImpl();
        }
        return employmentRepository;
    }
           ;
    @Override
    public Employment create(Employment employment) {
        boolean success = employmentList.add(employment);
        if (success) {
            return employment;
        }
        return null;
    }

    @Override
    public Employment read(String s) {
      for (Employment employment : employmentList) {
            if(employment.getEmploymentId().equalsIgnoreCase(s)){
                  return employment;
              }
      }
        return null;
    }

    @Override
    public Employment update(Employment employment) {
            Employment oldEmployment = read(employment.getEmploymentId());
        if (oldEmployment == null) {
            return null;
        }
        employmentList.remove(oldEmployment);
        employmentList.add(employment);
        return employment;
    }

    @Override
    public boolean delete(String s) {
        Employment employment = read(s);
        if (employment == null) {
            return  false;
        }
        return employmentList.remove(read(s));
    }

    @Override
    public List<Employment> getAllEmployment() {
        return employmentList;
    }

    @Override
    public List<Employment> getEmploymentByType(Employment.EmploymentType type) {
        List<Employment> result = new ArrayList<>();
        for (Employment employment : employmentList) {
            if (employment.getEmploymentType().equals(type)) {
                result.add(employment);
            }
        }
        return result;
    }
}
