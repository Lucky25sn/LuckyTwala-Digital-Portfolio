package za.ac.cput.service.employment;

import za.ac.cput.entity.employment.Employment;
import za.ac.cput.service.IService;

import java.util.List;

public interface EmploymentService extends IService<Employment, String> {
    List<Employment> getAllEmployment();
    List<Employment>getEmploymentByType(Employment.EmploymentType type);
}
