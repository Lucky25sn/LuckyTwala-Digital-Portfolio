package za.ac.cput.service.employment.Impl;

import org.junit.jupiter.api.MethodOrderer;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;
import za.ac.cput.entity.employment.Position;
import za.ac.cput.factory.employment.PositionFactory;
import za.ac.cput.repository.employment.Impl.PositionRepositoryImpl;
import za.ac.cput.service.employment.PositionService;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static za.ac.cput.entity.employment.Position.PositionStatus.CLOSED;
import static za.ac.cput.entity.employment.Position.PositionStatus.OPEN;

@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
class PositionServiceImplTest {

    private static PositionService positionService  = PositionServiceImpl.getPositionService();

    private static Position position1 = PositionFactory.createPosition((short) 10, OPEN);
    private static Position position2 = PositionFactory.createPosition((short) 15, OPEN);
    private static  Position position3 = PositionFactory.createPosition((short) 16, OPEN);
    private static Position position4 = PositionFactory.createPosition((short) 17, CLOSED);
    private static Position position5 = PositionFactory.createPosition((short) 18, CLOSED);



    @Test
    @Order(1)
    void create() {
        positionService.create(position1);
        positionService.create(position2);
        positionService.create(position3);
        positionService.create(position4);
        positionService.create(position5);
    }

    @Test
    @Order(2)
    void read()
    {
        positionService.read(position1.getPositionID());
        System.out.println(position1.toString());
    }

    @Test
    @Order(3)
    void update() {
        Position updatedPosition = new Position.Builder().copy(position3)
                .setPositionStatus(CLOSED)
                .build();
        positionService.update(updatedPosition);
        System.out.println(updatedPosition.toString());
    }

    @Test
    @Order(6)
    void delete() {
        boolean deleted = positionService.delete(position5.getPositionID());
        assertTrue(deleted);
        System.out.println(position5.toString());
    }

    @Test
    @Order(4)
    void getAllPosition() {
        System.out.println("get all positions");
        List<Position> positionList = positionService.getAllPosition();
        System.out.println(positionList.toString());
    }

    @Test
    @Order(5)
    void getAllByPositionStatus() {
        System.out.println("get all positions by positionStatus");
        List<Position> positionList = positionService.getAllByPositionStatus(OPEN);
        System.out.println(positionList.toString());
    }
}