package za.ac.cput.repository.demography.Impl;

import org.junit.jupiter.api.MethodOrderer;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;
import za.ac.cput.entity.demography.Gender;
import za.ac.cput.factory.demography.GenderFactory;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
class GenderRepositoryImplTest {

    private static GenderRepositoryImpl  genderRepository = GenderRepositoryImpl.getGenderRepository();
    private static Gender gender1 = GenderFactory.createGender("male");
    private static Gender gender2 = GenderFactory.createGender("Female");

    @Test
    @Order(1)
    void create() {
        genderRepository.create(gender1);
        genderRepository.create(gender2);
        assertNotNull(gender1);
        assertNotNull(gender2);
    }

    @Test
    @Order(2)
    void read() {
        genderRepository.read(gender1.getGenderId());
        assertNotNull(gender1);
    }

    @Test
    @Order(3)
    void update() {
        Gender updateGender = new Gender.Builder().copy(gender1)
                .setGenderDescription("Male").build();
        genderRepository.update(updateGender);
        System.out.println(updateGender.toString());
    }

    @Test
    @Order(5)
    void delete() {
        System.out.println("delete gender" );
        Gender gender = genderRepository.read(gender1.getGenderId());
        boolean deleted = genderRepository.delete(gender.getGenderId());
    }

    @Test
    @Order(4)
    void getAllGenders() {
        System.out.println("List all genders");
        List<Gender> genderList = genderRepository.getAllGenders();
        System.out.println(genderList);
    }
}