package za.ac.cput.controller.contact;

import org.junit.jupiter.api.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;
import za.ac.cput.entity.contact.Address;
import za.ac.cput.factory.contact.AddressFactory;
import static org.junit.jupiter.api.Assertions.*;


@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)


@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
public class AddressControllerTest {
    private static  Address address = AddressFactory.createAddress("152 Monte Amiata","BP7400","Cape town",
            "Western Cape","South Africa");

    @Autowired
    private TestRestTemplate restTemplate;

    private static final String BASE_URL = "http://localhost:8080/payroll/address";

    @BeforeEach
    @Order(1)
    void setUp() {

    }

    @Test
    @Order(2)
    void createAddress() {
        String url = BASE_URL+"/create";
        System.out.println("Post data");
        ResponseEntity<Address>  postResponse = this.restTemplate.postForEntity(url, address, Address.class);
        assertNotNull(postResponse);
        Address AddresseSave = postResponse.getBody();
        assertEquals(address.getAddressId(), AddresseSave.getAddressId());
        System.out.println("Created: " + AddresseSave);
    }

    @Test
    @Order(3)
    void readAddress() {
       String url = BASE_URL+"/read/" + address.getAddressId();
      ResponseEntity<Address> response = restTemplate.getForEntity(url, Address.class);
        // Verify status code
    // assertEquals(response.getStatusCode(), HttpStatus.OK);
    //assertEquals(HttpStatus.OK, response.getStatusCode());
        // Ensure body is not null
        assertNotNull(response.getBody());

    // Verify returned data
        assertEquals(address.getAddressId(), response.getBody().getAddressId());
        System.out.println("Read: " + response.getBody());
    }

    @Test
    @Order(4)
    void updateAddress() {
        Address updatedAddress = new Address.Builder().copy(address)
                .setStreetAddress("202 Cemor flat")
                .build();
        String url = BASE_URL+"/update";
         this.restTemplate.put(url, updatedAddress);
       // verify the update by reading the updated employee
        ResponseEntity<Address> response = restTemplate.getForEntity(BASE_URL +"/read/"+updatedAddress.getAddressId(), Address.class);
        assertEquals(response.getStatusCode(), HttpStatus.OK);
       System.out.println("Updated: " + response.getBody());
    }

    @Test
    @Order(6)
    void deleteAddress() {
       String url = BASE_URL+"/delete/" + address.getAddressId();
       this.restTemplate.delete(url);
       // verify that the employee was deleted
       ResponseEntity<Address> response = this.restTemplate.getForEntity(BASE_URL +"/read/"+address.getAddressId(), Address.class);
       //assertEquals(HttpStatus.NOT_FOUND, response.getStatusCode());
        assertNull(response.getBody());
        System.out.println("Deleted: " + response.getBody());
    }

    @Test
    @Order(5)
    void getAllAddress() {
        String url = BASE_URL+"/getall";
        ResponseEntity<Address[]> response = this.restTemplate.getForEntity(url, Address[].class);
        assertNotNull(response.getBody());
        assertTrue(response.getBody().length > 0);
        System.out.println(" get All Addresses: ");
        for (Address address : response.getBody()) {
            System.out.println(address);
        }
    }
}