package za.ac.cput.repository.demography.Impl;

import org.junit.jupiter.api.*;
import za.ac.cput.entity.contact.Address;
import za.ac.cput.entity.demography.Demography;
import za.ac.cput.factory.demography.DemographyFactory;
import za.ac.cput.repository.contact.ContactRepository;
import za.ac.cput.repository.demography.DemographyRepository;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
class DemographyRepositoryImplTest {

    private static DemographyRepository demographyRepository = DemographyRepositoryImpl.getInstance();
   // private static ContactRepository contactRepository = ConctactRepositoryImpl.getInstance();
    private static Demography demography1= DemographyFactory.createDemography("01","01");
    private static Demography demography2= DemographyFactory.createDemography("01","02");
    private static Demography demography3= DemographyFactory.createDemography("02","01");
    private static Demography demography4= DemographyFactory.createDemography("02","03");
    private static Demography demography5= DemographyFactory.createDemography("01","03");
    private static Demography demography6= DemographyFactory.createDemography("03","03");



    @Test
    @Order(1)
    void create() {
        demographyRepository.create(demography1);
        demographyRepository.create(demography2);
        demographyRepository.create(demography3);
        demographyRepository.create(demography4);
        demographyRepository.create(demography5);
        demographyRepository.create(demography6);
        assertNotNull(demography1);

    }

    @Test
    @Order(2)
    void read() {
        Demography demography= demographyRepository.read(demography1.getEmployeeNumer());
        System.out.println(demography.toString());
    }

    @Test
    @Order(3)
    void update() {
        Demography updateDemography = new Demography.Builder().copy(demography1)
                .setGenderId("03")
                .build();
        demographyRepository.update(updateDemography);
        System.out.println(updateDemography.toString());
    }

    @Test
    @Disabled
    void delete() {
        System.out.println("delete");
        Demography demographydeleted= demographyRepository.read(demography2.getEmployeeNumer());
        boolean deleted = demographyRepository.delete(demographydeleted.getEmployeeNumer());
        assertTrue(deleted);
    }

    @Test
    @Order(4)
    void getAllDemography() {
        System.out.println("List all demography ID");
        List<Demography> demographyList= demographyRepository.getAllDemography();
        System.out.println(demographyList.toString());
    }

    @Test
    @Order(5)
    void getDemographyByRace() {
        System.out.println("List demography by race ID");
        List<Demography> demographyList = demographyRepository.getDemographyByRace("02");
        System.out.println(demographyList.toString());
//        System.out.println("Listing all addresses by cities");
//        List<Address> addresses = addressRepository.getAllAddressByCities("Cape town");
//        System.out.println(addresses.toString());
    }

    @Test
    @Order(6)
    void getDemographyByGender() {
        System.out.println("List demography by gender");
        List<Demography> demographyList = demographyRepository.getDemographyByGender("01");
        System.out.println(demographyList.toString());
    }
}