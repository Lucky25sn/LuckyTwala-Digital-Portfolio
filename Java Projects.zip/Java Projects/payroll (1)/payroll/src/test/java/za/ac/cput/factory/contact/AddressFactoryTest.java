package za.ac.cput.factory.contact;

import org.junit.jupiter.api.Test;
import za.ac.cput.entity.contact.Address;

import static org.junit.jupiter.api.Assertions.*;

class AddressFactoryTest {
    @Test
    void createAddress() {
        Address address = AddressFactory.createAddress("Cemor Flat/Spencer street","PBox 7460","Cape town","Province","South Africa");
        assertNotNull(address);
        System.out.println(address);
    }

}