package za.ac.cput.service.demography.Impl;

import org.junit.jupiter.api.MethodOrderer;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;
import za.ac.cput.entity.demography.Gender;
import za.ac.cput.factory.demography.GenderFactory;
import za.ac.cput.repository.demography.Impl.GenderRepositoryImpl;
import za.ac.cput.service.demography.GenderService;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
class GenderServiceImplTest {

    private static GenderService genderService = GenderServiceImpl.getGenderService();
    private static Gender gender1 = GenderFactory.createGender("male");
    private static Gender gender2 = GenderFactory.createGender("Female");

    @Test
    @Order(1)
    void create() {
        genderService.create(gender1);
        genderService.create(gender2);
        assertNotNull(gender1);
        assertNotNull(gender2);
    }

    @Test
    @Order(2)
    void read() {
        genderService.read(gender1.getGenderId());
        assertNotNull(gender1);
    }

    @Test
    @Order(3)
    void update() {
        Gender updateGender = new Gender.Builder().copy(gender1)
                .setGenderDescription("Male").build();
        genderService.update(updateGender);
        System.out.println(updateGender.toString());
    }

    @Test
    @Order(5)
    void delete() {
        System.out.println("delete gender" );
        Gender gender = genderService.read(gender1.getGenderId());
        boolean deleted = genderService.delete(gender.getGenderId());
    }

    @Test
    @Order(4)
    void getAllGenders() {
        System.out.println("List all genders");
        List<Gender> genderList = genderService.getAllGenders();
        System.out.println(genderList);
    }
}