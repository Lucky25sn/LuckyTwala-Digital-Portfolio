package za.ac.cput.factory.demography;

import org.junit.jupiter.api.Test;
import za.ac.cput.entity.demography.Demography;

import static org.junit.jupiter.api.Assertions.*;

class DemographyFactoryTest {
    @Test
    void createDemography(){
     Demography demography= DemographyFactory.createDemography("12","13");
     assertNotNull(demography);
     System.out.println(demography);
    }

}