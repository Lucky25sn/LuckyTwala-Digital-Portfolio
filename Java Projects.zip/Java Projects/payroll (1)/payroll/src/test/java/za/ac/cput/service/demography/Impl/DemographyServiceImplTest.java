package za.ac.cput.service.demography.Impl;

import org.junit.jupiter.api.MethodOrderer;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;
import za.ac.cput.entity.demography.Demography;
import za.ac.cput.factory.demography.DemographyFactory;
import za.ac.cput.repository.demography.DemographyRepository;
import za.ac.cput.repository.demography.Impl.DemographyRepositoryImpl;
import za.ac.cput.service.demography.DemographyService;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
class DemographyServiceImplTest {

    private static DemographyService demographyService = DemographyServiceImpl.getDemographyService();
    private static Demography demography1= DemographyFactory.createDemography("01","01");
    private static Demography demography2= DemographyFactory.createDemography("01","02");
    private static Demography demography3= DemographyFactory.createDemography("02","01");
    private static Demography demography4= DemographyFactory.createDemography("02","03");
    private static Demography demography5= DemographyFactory.createDemography("01","03");
    private static Demography demography6= DemographyFactory.createDemography("03","03");

    @Test
    @Order(1)
    void create() {
        demographyService.create(demography1);
        demographyService.create(demography2);
        demographyService.create(demography3);
        demographyService.create(demography4);
        demographyService.create(demography5);
        demographyService.create(demography6);
        assertNotNull(demography1);
    }

    @Test
    @Order(2)
    void read() {
        Demography demography= demographyService.read(demography1.getEmployeeNumer());
        System.out.println(demography.toString());
    }

    @Test
    @Order(3)
    void update() {
        Demography updateDemography = new Demography.Builder().copy(demography1)
                .setGenderId("03")
                .build();
        demographyService.update(updateDemography);
        System.out.println(updateDemography.toString());
    }

    @Test
    @Order(7)
    void delete() {
        System.out.println("delete");
        Demography demographydeleted= demographyService.read(demography2.getEmployeeNumer());
        boolean deleted = demographyService.delete(demographydeleted.getEmployeeNumer());
      //  assertTrue(deleted);
    }

    @Test
    @Order(4)
    void getAllDemography() {
        System.out.println("List all demography ID");
        List<Demography> demographyList= demographyService.getAllDemography();
        System.out.println(demographyList.toString());
    }

    @Test
    @Order(5)
    void getDemographyByRace() {
        System.out.println("List demography by race ID");
        List<Demography> demographyList = demographyService.getDemographyByRace("02");
        System.out.println(demographyList.toString());
    }

    @Test
    @Order(6)
    void getDemographyByGender() {
        System.out.println("List demography by gender");
        List<Demography> demographyList = demographyService.getDemographyByGender("01");
        System.out.println(demographyList.toString());
    }
}