package za.ac.cput.factory.demography;

import org.junit.jupiter.api.Test;
import za.ac.cput.entity.demography.Gender;

import static org.junit.jupiter.api.Assertions.*;

class GenderFactoryTest {
    @Test
    void createGender() {
        Gender gender = GenderFactory.createGender("Male");
        assertNotNull(gender);
        System.out.println(gender);
    }

}