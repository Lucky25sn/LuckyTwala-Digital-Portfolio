package za.ac.cput.repository.employeedetails.Impl;

import org.junit.jupiter.api.MethodOrderer;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;
import za.ac.cput.entity.employeedetails.Identity;
import za.ac.cput.factory.employeedetails.IdentityFactory;
import za.ac.cput.repository.employeedetails.IdentityRepository;

import static org.junit.jupiter.api.Assertions.*;
@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
class IdentityRepositoryImplTest {
    private static IdentityRepositoryImpl identityRepository= IdentityRepositoryImpl.getIdentityRepository();

    private static Identity identity = IdentityFactory.createIdentity("Passport","30100742",
            "ZG1234");
    private static  Identity identity1 = IdentityFactory.createIdentity("Passport",
            "20000742", "MG4001");
    private static  Identity identity2 = IdentityFactory.createIdentity("Identity",
            "20012340", "19990215");
    @Test
    @Order(1)
    void create() {
        identityRepository.create(identity);
        identityRepository.create(identity1);
        identityRepository.create(identity2);

    }

    @Test
    @Order(2)
    void read() {
        identityRepository.read(identity1.getIdentityId());
        System.out.println("Details information:\n"+identity1.toString());
    }

    @Test
    @Order(3)
    void update() {
        Identity identity = new Identity.Builder().copy(identity1)
                .setIdentityType("Passport").build();
        System.out.println("Details information:\n"+identity.toString());
    }

    @Test
    @Order(5)
    void delete() {
        boolean result = identityRepository.delete(identity2.getIdentityId());
        assertTrue(result);
    }

    @Test
    @Order(4)
    void getAllIdentities() {
        System.out.println("Details information:\n"+identityRepository.getAllIdentities());
    }
}