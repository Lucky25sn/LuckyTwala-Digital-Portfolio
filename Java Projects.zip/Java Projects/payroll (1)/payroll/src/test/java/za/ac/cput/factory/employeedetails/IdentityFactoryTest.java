package za.ac.cput.factory.employeedetails;

import org.junit.jupiter.api.Test;
import za.ac.cput.entity.employeedetails.Identity;

import static org.junit.jupiter.api.Assertions.*;

class IdentityFactoryTest {
    @Test
    void createIdentity(){
        Identity identity = IdentityFactory.createIdentity("Passport","30100742", "ZG1234");
        assertNotNull(identity);
        System.out.println(identity);
    }

}