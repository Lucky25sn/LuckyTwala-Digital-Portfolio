package za.ac.cput.service.employeedetails.Impl;

import org.junit.jupiter.api.MethodOrderer;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;
import za.ac.cput.entity.employeedetails.Employee;
import za.ac.cput.factory.employeedetails.EmployeeFactory;
import za.ac.cput.repository.employeedetails.EmployeeRepository;
import za.ac.cput.repository.employeedetails.Impl.EmployeeRepositoryImpl;
import za.ac.cput.service.employeedetails.EmployeeService;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
class EmployeeServiceImplTest {

    private static EmployeeService employeeServive = EmployeeServiceImpl.getEmployeeService();
    private static Employee employee = EmployeeFactory.createEmployee("30100742",
            "Tchouya'a ngoko","Israel Christian","Cameroon");
    private static Employee employee1 = EmployeeFactory.createEmployee("20100742",
            "Brandon","Tony","South Africa");
    private static Employee employee2 = EmployeeFactory.createEmployee("10100745",
            "Jesica","Amanda","South Africa");

    @Test
    @Order(1)
    void create() {
        employeeServive.create(employee);
        employeeServive.create(employee1);
        employeeServive.create(employee2);
        assertNotNull(employee);
        System.out.println("Employees created successfully\n"+employee.toString());
        System.out.println("\n"+employee1.toString());
        System.out.println("\n"+employee2.toString());
    }

    @Test
    @Order(2)
    void read() {
        employeeServive.read(employee1.toString());
        assertNotNull(employee1);
        System.out.println("Employee read successfully\n"+employee1.toString());
    }

    @Test
    @Order(3)
    void update() {
        Employee updatedemployee = new Employee.Builder().copy(employee)
                .setNationality("Namibia")
                .build();
        employeeServive.update(updatedemployee);
        System.out.println("Employee updated successfully\n"+updatedemployee.toString());
    }

    @Test
    @Order(6)
    void delete() {
        boolean employedeleted = employeeServive.delete(employee.getEmployeeNumber());
    }

    @Test
    @Order(4)
    void getAllEmployees() {
        System.out.println("List of all employees");
        System.out.println(employeeServive.getAllEmployees());
    }

    @Test
    @Order(5)
    void getEmployeeByNationality() {
        System.out.println("Employee by Nationality");
        List<Employee> employeeList = employeeServive.getEmployeeByNationality("South Africa");
        System.out.println(employeeList);
    }
}