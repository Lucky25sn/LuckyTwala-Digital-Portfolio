package za.ac.cput.factory.employment;

import org.junit.jupiter.api.Test;
import za.ac.cput.entity.employment.Employment;

import static org.junit.jupiter.api.Assertions.*;

class EmploymentFactoryTest {

    @Test
    void createEmployment() {
        Employment employment = EmploymentFactory.createEmployment(Employment.EmploymentType.CONTRACT,
                "The contract is for 6 months");
        assertNotNull(employment);
        System.out.println(employment);
    }
}