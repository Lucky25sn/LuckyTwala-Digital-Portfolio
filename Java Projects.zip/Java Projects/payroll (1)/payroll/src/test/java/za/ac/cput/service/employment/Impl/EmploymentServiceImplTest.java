package za.ac.cput.service.employment.Impl;

import org.junit.jupiter.api.MethodOrderer;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;
import za.ac.cput.entity.employment.Employment;
import za.ac.cput.factory.employment.EmploymentFactory;
import za.ac.cput.repository.employment.EmploymentRepository;
import za.ac.cput.repository.employment.Impl.EmploymentRepositoryImpl;
import za.ac.cput.service.employment.EmploymentService;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
class EmploymentServiceImplTest {

    private static EmploymentService employmentService = EmploymentServiceImpl.getEmploymentService();
    private static Employment employment1 = EmploymentFactory.createEmployment(Employment.EmploymentType.CONTRACT,
            "The contract is for 1 months");
    Employment employment2 = EmploymentFactory.createEmployment(Employment.EmploymentType.CONTRACT,
            "The contract is for 6 months");
    Employment employment3 = EmploymentFactory.createEmployment(Employment.EmploymentType.PERMANENT,
            "The contract is for 2 years");
    @Test
    @Order(1)
    void create() {
        employmentService.create(employment1);
        employmentService.create(employment2);
        employmentService.create(employment3);

    }

    @Test
    @Order(2)
    void read() {
        employmentService.read(employment1.getEmploymentId());
        employmentService.read(employment2.getEmploymentId());
        employmentService.read(employment3.getEmploymentId());
        System.out.println(employment1.toString());
        System.out.println(employment2.toString());
        System.out.println(employment3.toString());

    }

    @Test
    @Order(3)
    void update() {
        Employment updatedEmployment = new Employment.Builder().copy(employment1)
                .setEmploymentDescription("The contract is for 3 months").build();
        employmentService.update(updatedEmployment);
        System.out.println(updatedEmployment.toString());
    }

    @Test
    @Order(6)
    void delete() {
        boolean deleted = employmentService.delete(employment1.getEmploymentId());
        assertTrue(deleted);
        System.out.println(employment1.toString());
    }

    @Test
    @Order(4)
    void getAllEmployment() {
        System.out.println("List all employments");
        List<Employment> allemployments = employmentService.getAllEmployment();
        System.out.println(allemployments.toString());
    }

    @Test
    @Order(5)
    void getEmploymentByType() {
        System.out.println("List all employment by type");
        List<Employment> allEmployments = employmentService.getEmploymentByType(Employment.EmploymentType.CONTRACT);
        System.out.println(allEmployments.toString());
    }
}