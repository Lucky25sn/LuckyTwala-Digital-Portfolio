package za.ac.cput.repository.employment.Impl;

import org.junit.jupiter.api.MethodOrderer;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;
import za.ac.cput.entity.employment.Employment;
import za.ac.cput.factory.employment.EmploymentFactory;
import za.ac.cput.repository.employment.EmploymentRepository;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
class EmploymentRepositoryImplTest {

    private static EmploymentRepository employmentRepository = EmploymentRepositoryImpl.getRepository();
    private static Employment employment1 = EmploymentFactory.createEmployment(Employment.EmploymentType.CONTRACT,
            "The contract is for 1 months");
    Employment employment2 = EmploymentFactory.createEmployment(Employment.EmploymentType.CONTRACT,
            "The contract is for 6 months");
    Employment employment3 = EmploymentFactory.createEmployment(Employment.EmploymentType.PERMANENT,
            "The contract is for 2 years");
    @Test
    @Order(1)
    void create() {
        employmentRepository.create(employment1);
        employmentRepository.create(employment2);
        employmentRepository.create(employment3);

    }

    @Test
    @Order(2)
    void read() {
        employmentRepository.read(employment1.getEmploymentId());
        employmentRepository.read(employment2.getEmploymentId());
        employmentRepository.read(employment3.getEmploymentId());
        System.out.println(employment1.toString());
        System.out.println(employment2.toString());
        System.out.println(employment3.toString());

    }

    @Test
    @Order(3)
    void update() {
        Employment updatedEmployment = new Employment.Builder().copy(employment1)
                .setEmploymentDescription("The contract is for 3 months").build();
        employmentRepository.update(updatedEmployment);
        System.out.println(updatedEmployment.toString());
    }

    @Test
    @Order(6)
    void delete() {
        boolean deleted = employmentRepository.delete(employment1.getEmploymentId());
        assertTrue(deleted);
        System.out.println(employment1.toString());
    }

    @Test
    @Order(4)
    void getAllEmployment() {
        System.out.println("List all employments");
        List<Employment> allemployments = employmentRepository.getAllEmployment();
        System.out.println(allemployments.toString());
    }

    @Test
    @Order(5)
    void getEmploymentByType() {
        System.out.println("List all employment by type");
        List<Employment> allEmployments = employmentRepository.getEmploymentByType(Employment.EmploymentType.CONTRACT);
        System.out.println(allEmployments.toString());
    }
}