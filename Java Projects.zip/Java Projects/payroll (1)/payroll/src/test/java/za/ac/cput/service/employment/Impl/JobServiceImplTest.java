package za.ac.cput.service.employment.Impl;

import org.junit.jupiter.api.MethodOrderer;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;
import za.ac.cput.entity.employment.Job;
import za.ac.cput.factory.employment.JobFactory;
import za.ac.cput.service.employment.JobService;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
class JobServiceImplTest {

    private static JobService jobService = JobServiceImpl.getJobService();
    private static Job job1 = JobFactory.createJob("IT Engineer", "Master in IT");
    private static Job job2 = JobFactory.createJob("IT Developer", "Master in IT");
    private static Job job3 = JobFactory.createJob("IT Full stack", "Master in IT");
    private static Job job4 = JobFactory.createJob("IT Engineer", "Master in IT");


    @Test
    @Order(1)
    void create() {
        jobService.create(job1);
        jobService.create(job2);
        jobService.create(job3);
        jobService.create(job4);
    }

    @Test
    @Order(2)
    void read() {
        jobService.read(job1.getJobId());
        System.out.println(job1.toString());
    }

    @Test
    @Order(3)
    void update() {
        Job updateJob = new Job.Builder().copy(job3)
                .setJobDescription("Master in IT/ Master in BCOM").build();
        jobService.update(updateJob);
        System.out.println(updateJob.toString());
    }

    @Test
    @Order(6)
    void delete() {
        boolean deleted = jobService.delete(job1.getJobId());
        assertTrue(deleted);
        System.out.println(job1.toString());
    }

    @Test
    @Order(4)
    void getAllJob() {
        System.out.println("List of jobs");
        List<Job> jobs = jobService.getAllJob();
        System.out.println(jobs.toString());
    }

    @Test
    @Order(5)
    void getAllJobByTitle() {
        System.out.println("List of jobs by title");
        List<Job> jobs = jobService.getAllJobByTitle("IT Engineer");
        System.out.println(jobs.toString());
    }
}