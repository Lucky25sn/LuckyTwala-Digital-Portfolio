package za.ac.cput.repository.employeedetails.Impl;

import org.junit.jupiter.api.MethodOrderer;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;
import za.ac.cput.entity.employeedetails.Employee;
import za.ac.cput.factory.employeedetails.EmployeeFactory;
import za.ac.cput.repository.employeedetails.EmployeeRepository;
import za.ac.cput.repository.employment.EmploymentRepository;

import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
class EmployeeRepositoryImplTest {

    private static EmployeeRepositoryImpl employeeRepository = EmployeeRepositoryImpl.getEmployeeRepository();
    private static Employee employee = EmployeeFactory.createEmployee("30100742",
            "Tchouya'a ngoko","Israel Christian","Cameroon");
    private static Employee employee1 = EmployeeFactory.createEmployee("20100742",
            "Brandon","Tony","South Africa");
    private static Employee employee2 = EmployeeFactory.createEmployee("10100745",
            "Jesica","Amanda","South Africa");


    @Test
    @Order(1)
    void create() {
        employeeRepository.create(employee);
        employeeRepository.create(employee1);
        employeeRepository.create(employee2);
        assertNotNull(employee);
        System.out.println("Employees created successfully\n"+employee.toString());
        System.out.println("\n"+employee1.toString());
        System.out.println("\n"+employee2.toString());
    }

    @Test
    @Order(2)
    void read() {
        employeeRepository.read(employee1.toString());
        assertNotNull(employee1);
        System.out.println("Employee read successfully\n"+employee1.toString());
    }

    @Test
    @Order(3)
    void update() {

        Employee updatedemployee = new Employee.Builder().copy(employee)
                .setNationality("Namibia")
                .build();
        employeeRepository.update(updatedemployee);
        System.out.println("Employee updated successfully\n"+updatedemployee.toString());
    }

    @Test
    @Order(5)
    void delete() {
        System.out.println("Employee delete successfully");
        boolean deleted = employeeRepository.delete(employee2.getEmployeeNumber());
    }

    @Test
    @Order(4)
    void getAllEmployees() {
        Employee updatedemployee = new Employee.Builder().copy(employee)
                .setNationality("Namibia")
                .build();
        employeeRepository.update(updatedemployee);
        System.out.println("Employee updated successfully\n"+updatedemployee.toString());
    }

    @Test
    @Order(5)
    void getEmployeeByNationality() {
        List<Employee> employeeList = employeeRepository.getEmployeeByNationality("South Africa");
        System.out.println(employeeList);
    }
}