package za.ac.cput.factory.employeedetails;

import org.junit.jupiter.api.Test;
import za.ac.cput.entity.employeedetails.Employee;

import static org.junit.jupiter.api.Assertions.*;

class EmployeeFactoryTest {
    @Test
    void createEmployee() {
        Employee employee = EmployeeFactory.createEmployee("30100742","Tchouya'a ngoko","Israel Christian","Cameroon");
        assertNotNull(employee);
        System.out.println(employee);
    }

}