package za.ac.cput.factory.employment;

import org.junit.jupiter.api.Test;
import za.ac.cput.entity.demography.Race;
import za.ac.cput.entity.employment.Position;

import static org.junit.jupiter.api.Assertions.*;
import static za.ac.cput.entity.employment.Position.PositionStatus.OPEN;

class PositionFactoryTest {

    @Test
    void createPosition() {
        Position position = PositionFactory.createPosition((short) 156, OPEN);
        assertNotNull(position);
        System.out.println(position);
    }
}