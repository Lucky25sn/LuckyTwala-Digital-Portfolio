package za.ac.cput.factory.employment;

import org.junit.jupiter.api.Test;
import za.ac.cput.entity.employment.Job;

import static org.junit.jupiter.api.Assertions.*;

class JobFactoryTest {

    @Test
    void createJob() {
        Job job = JobFactory.createJob("IT Engineer", "Master in IT");
        assertNotNull(job);
        System.out.println(job);
    }
}