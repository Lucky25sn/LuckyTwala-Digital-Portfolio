package za.ac.cput.service.employeedetails.Impl;

import org.junit.jupiter.api.MethodOrderer;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;
import za.ac.cput.entity.employeedetails.Identity;
import za.ac.cput.factory.employeedetails.IdentityFactory;
import za.ac.cput.repository.employeedetails.Impl.IdentityRepositoryImpl;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
class IdentityServiceImplTest {

    private static IdentityServiceImpl identityService= IdentityServiceImpl.getIdentityService();

    private static Identity identity = IdentityFactory.createIdentity("Passport","30100742",
            "ZG1234");
    private static  Identity identity1 = IdentityFactory.createIdentity("Passport",
            "20000742", "MG4001");
    private static  Identity identity2 = IdentityFactory.createIdentity("Identity",
            "20012340", "19990215");

    @Test
    @Order(1)
    void create() {
        identity = identityService.create(identity);
        identity = identityService.create(identity1);
        identity = identityService.create(identity2);
        assertNotNull(identity);
        assertNotNull(identity1);
        assertNotNull(identity2);
        System.out.println("Identity created successfully"+identity.toString());
        System.out.println(identity.toString());
        System.out.println(identity2.toString());
    }

    @Test
    @Order(2)
    void read() {
        identityService.read(identity1.toString());
        assertNotNull(identity1);
        System.out.println("Identity read successfully"+identity1.toString());

    }

    @Test
    @Order(3)
    void update() {
        Identity identity3 = new Identity.Builder().copy(identity2)
                .setEmployeeNumber("2000000")
                .build();
        identityService.update(identity3);
        System.out.println("Identity updated successfully"+identity3.toString());
    }

    @Test
    @Order(4)
    void delete() {
       boolean deleted = identityService.delete(identity2.getIdentityId());
        assertTrue(deleted);
    }

    @Test
    @Order(5)
    void getAllIdentities() {
        System.out.println("getAllIdentities successfully");
        List<Identity> identities = identityService.getAllIdentities();
        System.out.println(identities);
    }
}