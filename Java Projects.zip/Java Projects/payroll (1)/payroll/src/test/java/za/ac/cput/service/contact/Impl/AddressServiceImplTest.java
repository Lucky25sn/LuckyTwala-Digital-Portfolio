package za.ac.cput.service.contact.Impl;

import org.junit.jupiter.api.MethodOrderer;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;
import za.ac.cput.entity.contact.Address;
import za.ac.cput.factory.contact.AddressFactory;
import za.ac.cput.service.contact.AddressService;

import java.util.List;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
class AddressServiceImplTest {

  //  private static AddressRepository addressRepository = AddressRepositoryImpl.getAddressRepository();
   private AddressService addressService = AddressServiceImpl.getAddressService();
    private static Address address1 = AddressFactory.createAddress("Cemor Flat/Spencer street","PBox 7460","Cape town","Western cape","South Africa");
    private static Address address2 = AddressFactory.createAddress("William street","PBox 9000","Yolo","Eastern Cape","South Africa");
    private static Address address3 = AddressFactory.createAddress("Hugo Street","PBox 7460","Cape town","Western cape","South Africa");


    @Test
    @Order(1)
    void create() {
        addressService.create(address1);
        addressService.create(address2);
        addressService.create(address3);


        System.out.println(address1.toString());
    }

    @Test
    @Order(2)
    void read() {
        Address addresses = addressService.read(address1.getAddressId());
        System.out.println(addresses.toString());
    }

    @Test
    @Order(3)
    void update() {
        Address founddAddress = new Address.Builder().copy(address2)
                .setPostalAddress("PBox 8500")
                .build();
        Address updatedAddress =addressService.update(founddAddress);
        assertNotNull(updatedAddress);
        System.out.println(updatedAddress.toString());

    }

    @Test
    @Order(7)
    void delete() {
      //  Address address1 = addressService.read(address3.getAddressId());
        boolean deleted = addressService.delete(address3.getAddressId());
        assertTrue(deleted);
        System.out.println("deleted "+deleted);
    }

    @Test
    @Order(4)
    void getAllAddresses() {
        System.out.println("Listing all address");
        List<Address> addresses = addressService.getAllAddresses();
        System.out.println(addresses.toString());
    }

    @Test
    @Order(5)
    void getAllAddressByProvinces() {
        System.out.println("Listing all addresses by province" );
        List<Address> addresses = addressService.getAllAddressByProvinces("Western Cape");
        System.out.println(addresses.toString());
    }

    @Test
    @Order(6)
    void getAllAddressByCities() {
        System.out.println("Listing all addresses by cities");
        List<Address> addresses = addressService.getAllAddressByCities("Cape town");
        System.out.println(addresses.toString());
    }
}