package za.ac.cput.repository.employment.Impl;

import org.junit.jupiter.api.MethodOrderer;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;
import za.ac.cput.entity.employment.Job;
import za.ac.cput.factory.employment.JobFactory;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
class JobRepositoryImplTest {

    private static JobRepositoryImpl jobRepository = JobRepositoryImpl.getInstance();
    private static Job job1 = JobFactory.createJob("IT Engineer", "Master in IT");
    private static Job job2 = JobFactory.createJob("IT Developer", "Master in IT");
    private static Job job3 = JobFactory.createJob("IT Full stack", "Master in IT");
    private static Job job4 = JobFactory.createJob("IT Engineer", "Master in IT");

    @Test
    @Order(1)
    void create() {
        jobRepository.create(job1);
        jobRepository.create(job2);
        jobRepository.create(job3);
        jobRepository.create(job4);
    }

    @Test
    @Order(2)
    void read() {
        jobRepository.read(job1.getJobId());
        System.out.println(job1.toString());
    }

    @Test
    @Order(3)
    void update() {
        Job updateJob = new Job.Builder().copy(job3)
                .setJobDescription("Master in IT/ Master in BCOM").build();
    jobRepository.update(updateJob);
        System.out.println(updateJob.toString());
    }

    @Test
    @Order(6)
    void delete() {
        boolean deleted = jobRepository.delete(job1.getJobId());
        assertTrue(deleted);
        System.out.println(job1.toString());
    }

    @Test
    @Order(4)
    void getAllJob() {
        System.out.println("List of jobs");
        List<Job> jobs = jobRepository.getAllJob();
        System.out.println(jobs.toString());
    }

    @Test
    @Order(5)
    void getAllJobByTitle() {
        System.out.println("List of jobs by title");
        List<Job> jobs = jobRepository.getAllJobByTitle("IT Engineer");
        System.out.println(jobs.toString());
    }
}