package za.ac.cput.repository.contact.Impl;

import org.junit.jupiter.api.MethodOrderer;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;
import za.ac.cput.entity.contact.Contact;
import za.ac.cput.factory.contact.ContactFactory;
import za.ac.cput.repository.contact.ContactRepository;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
class ContactRepositoryImplTest {

    private static ContactRepositoryImpl contactRepository = ContactRepositoryImpl.getInstance();
    private Contact contact1 = ContactFactory.createContact("073-383-8486","021-460-1452","tchouya'angokoi@cput.ac.za");
    private Contact contact2 = ContactFactory.createContact("073-383-8487","021-460-5645","tchouyaangoko@gmail.com");
    private Contact contact3 = ContactFactory.createContact("038-065-8456","021-460-5645","tchouyaangoko@gmail.com");

    @Test
    @Order(1)
    void create() {
        contactRepository.create(contact1);
        contactRepository.create(contact3) ;
        assertNotNull(contact1);
        assertEquals(contact1.getCellNumber(),"073-383-8486");
        System.out.println(contact1.toString());
    }

    @Test
    @Order(2)
    void read() {
         Contact contact = contactRepository.read(contact1.getCellNumber());
        assertNotNull(contact);
        assertEquals(contact1.getCellNumber(),"073-383-8486");
        System.out.println(contact.toString());

    }

    @Test
    @Order(3)
    void update() {
        contactRepository.create(contact2) ;
        Contact updateContact = new Contact.Builder().copy(contact2)
                .setEmail("mikiahidjo@gmail.com")
                .build();
        contactRepository.update(updateContact);
        System.out.println(updateContact.toString());
    }

    @Test
    @Order(5)
    void delete() {
        contactRepository.read(contact3.getCellNumber()) ;
        boolean deleted = contactRepository.delete(contact3.getCellNumber());
        assertTrue(deleted);
    }

    @Test
    @Order(4)
    void getAllContacts() {
        System.out.println("List all contacts");
        List<Contact> contactList = contactRepository.getAllContacts();
        System.out.println(contactList.toString());
    }
}