package za.ac.cput.factory.demography;

import org.junit.jupiter.api.Test;
import za.ac.cput.entity.demography.Race;

import static org.junit.jupiter.api.Assertions.*;

class RaceFactoryTest {

    @Test
    void createRace() {
        Race race = RaceFactory.createRace(Race.RaceDescription.BLACK);
        assertNotNull(race);
        System.out.println(race);
    }



}