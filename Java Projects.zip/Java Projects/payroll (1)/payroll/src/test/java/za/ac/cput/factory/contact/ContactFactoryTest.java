package za.ac.cput.factory.contact;

import org.junit.jupiter.api.Test;
import za.ac.cput.entity.contact.Contact;

import static org.junit.jupiter.api.Assertions.*;

class ContactFactoryTest {
    @Test
    void createContact(){
        Contact contact = ContactFactory.createContact("073-383-8487","021-460-1452","tchouya'angkoi@cput.ac.za");
        assertNotNull(contact);
        System.out.println(contact);
    }

}