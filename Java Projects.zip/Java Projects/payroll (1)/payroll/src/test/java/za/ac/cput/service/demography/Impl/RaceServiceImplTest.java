package za.ac.cput.service.demography.Impl;

import org.junit.jupiter.api.MethodOrderer;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;
import za.ac.cput.entity.demography.Race;
import za.ac.cput.factory.demography.RaceFactory;
import za.ac.cput.repository.demography.Impl.RaceRepositoryImpl;
import za.ac.cput.service.demography.RaceService;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
class RaceServiceImplTest {

    private static RaceService raceService = RaceServiceImpl.getRaceService();

    private static Race race1 = RaceFactory.createRace(Race.RaceDescription.BLACK);
    private static Race race2 = RaceFactory.createRace(Race.RaceDescription.YELLOW);
    private static Race race3 = RaceFactory.createRace(Race.RaceDescription.RED);
    private static Race race4 = RaceFactory.createRace(Race.RaceDescription.YELLOW);

    @Test
    @Order(1)
    void create() {
        raceService.create(race1);
        raceService.create(race2);
        raceService.create(race3);
        raceService.create(race4);
    }

    @Test
    @Order(2)
    void read() {
        raceService.read(race1.getRaceId());
        assertNotNull(race1.getRaceId());
        System.out.println(race1.toString());
    }

    @Test
    @Order(3)
    void update() {
        Race updatedRace = new Race.Builder()
                .copy(race2)
                .setRaceDescription(Race.RaceDescription.WHITE)
                .build();
        raceService.update(updatedRace);
        System.out.println(updatedRace.toString());
    }

    @Test
    @Order(5)
    void delete() {
        Race race = raceService.read(race1.getRaceId());
        boolean deleted = raceService.delete(race.getRaceId());
        assertTrue(deleted);

    }

    @Test
    @Order(4)
    void getAllRaces() {
        System.out.println("List all Races");
        List<Race> races = raceService.getAllRaces();
        System.out.println(races.toString());
    }
}