package za.ac.cput.repository.contact.Impl;

import org.junit.jupiter.api.MethodOrderer;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;
import za.ac.cput.entity.contact.Address;
import za.ac.cput.factory.contact.AddressFactory;
import za.ac.cput.repository.contact.AddressRepository;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
class AddressRepositoryImplTest {

    private static AddressRepository addressRepository = AddressRepositoryImpl.getAddressRepository();
    private static Address address1 = AddressFactory.createAddress("Cemor Flat/Spencer street","PBox 7460","Cape town","Western cape","South Africa");
    private static Address address2 = AddressFactory.createAddress("William street","PBox 9000","Yolo","Eastern Cape","South Africa");
    private static Address address3 = AddressFactory.createAddress("Hugo Street","PBox 7460","Cape town","Western cape","South Africa");



    @Test
    @Order(1)
    void create() {
        addressRepository.create(address1);
        addressRepository.create(address2);
        addressRepository.create(address3);
        assertNotNull(address1);
        assertNotNull(address2);
        assertNotNull(address3);

      System.out.println(address1);
      System.out.println(address2);
      System.out.println(address3);

    }

    @Test
    @Order(2)
    void read() {
        Address foundAddress = addressRepository.read(address1.getAddressId());
        assertNotNull(foundAddress);
        assertEquals(address1.getAddressId(), foundAddress.getAddressId());
        System.out.println(foundAddress);
    }

    @Test
    @Order(3)
    void update() {
        Address founddAddress = new Address.Builder().copy(address2)
                .setPostalAddress("PBox 8500")
                .build();
        Address updatedAddress =addressRepository.update(founddAddress);
       assertNotNull(updatedAddress);
        System.out.println(updatedAddress.toString());

    }

    @Test
    @Order(7)
    void delete() {
       boolean deleted = addressRepository.delete(address3.getAddressId());
        assertTrue(deleted);
        System.out.println("deleted "+deleted);
    }

    @Test
    @Order(4)
    void getAllAddresses() {
        System.out.println("Listing all address");
        List<Address> addresses = addressRepository.getAllAddresses();
        System.out.println(addresses.toString());
    }

    @Test
    @Order(5)
    void getAllAddressByProvinces() {
        System.out.println("Listing all addresses by province" );
        List<Address> addresses = addressRepository.getAllAddressByProvinces("Western Cape");
        System.out.println(addresses.toString());

    }


    @Test
    @Order(6)
    void getAllAddressByCities() {
        System.out.println("Listing all addresses by cities");
        List<Address> addresses = addressRepository.getAllAddressByCities("Cape town");
        System.out.println(addresses.toString());
    }
}