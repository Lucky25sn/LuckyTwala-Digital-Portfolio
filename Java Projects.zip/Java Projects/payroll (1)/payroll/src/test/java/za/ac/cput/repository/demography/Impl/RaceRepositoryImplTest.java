package za.ac.cput.repository.demography.Impl;

import org.junit.jupiter.api.MethodOrderer;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;
import za.ac.cput.entity.demography.Race;
import za.ac.cput.factory.demography.RaceFactory;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
class RaceRepositoryImplTest {

    private static RaceRepositoryImpl raceRepository = RaceRepositoryImpl.getInstance();

    private static Race race1 = RaceFactory.createRace(Race.RaceDescription.BLACK);
    private static Race race2 = RaceFactory.createRace(Race.RaceDescription.YELLOW);
    private static Race race3 = RaceFactory.createRace(Race.RaceDescription.RED);
    private static Race race4 = RaceFactory.createRace(Race.RaceDescription.YELLOW);

    @Test
    @Order(1)
    void create() {
        raceRepository.create(race1);
        raceRepository.create(race2);
        raceRepository.create(race3);
        raceRepository.create(race4);
    }

    @Test
    @Order(2)
    void read() {
     raceRepository.read(race1.getRaceId());
        assertNotNull(race1.getRaceId());
        System.out.println(race1.toString());
    }

    @Test
    @Order(3)
    void update() {
        Race updatedRace = new Race.Builder()
                .copy(race2)
                .setRaceDescription(Race.RaceDescription.WHITE)
                .build();
        raceRepository.update(updatedRace);
        System.out.println(updatedRace.toString());
    }

    @Test
    @Order(5)
    void delete() {
        Race race = raceRepository.read(race1.getRaceId());
        boolean deleted = raceRepository.delete(race.getRaceId());
        assertTrue(deleted);

    }

    @Test
    @Order(4)
    void getAllRaces() {
        System.out.println("List all Races");
        List<Race> races = raceRepository.getAllRaces();
        System.out.println(races.toString());
    }
}