package za.ac.cput.adp_term4_project; 

import java.awt.*; // Imports AWT classes for GUI layout.
import java.awt.event.*; // Imports event handling classes.
import java.io.*; // Imports I/O classes for streams.
import java.net.*; // Imports networking classes for Sockets and ServerSocket.
import java.sql.*; // Imports SQL classes for database.
import javax.swing.*; // Imports Swing classes for GUI components.

/**
 *
 * @author Phumlani
 */
public class ServerGUI extends JFrame implements ActionListener {

    private ServerSocket listener; // Socket that listens for client connections.
    private static Socket client; // Socket for the connection to the connected client.
    // Output and input streams for sending/receiving (Strings) to the server.
    public static ObjectOutputStream out; 
    public static ObjectInputStream in; 

    private JButton btnExit = new JButton("EXIT"); 
    protected static JTextArea taServer = new JTextArea(10, 40); // Text area for server logging and status.
    private JPanel pnlTop = new JPanel(); // Panel for the top section 
    private JPanel pnlCenter = new JPanel(); // Panel for the center section 

    //Constructor for ServerGUI. Sets up the GUI and starts listening for connections.
    public ServerGUI() {
        super("Server GUI"); // Sets the title.
        setLayout(new BorderLayout()); // Use BorderLayout for the main frame.

        pnlTop.add(btnExit); // Add the Exit button to the top panel.
        pnlCenter.add(new JScrollPane(taServer)); // Put the text area in a scroll pane and add to center panel.

        add(pnlTop, BorderLayout.NORTH); 
        add(pnlCenter, BorderLayout.CENTER); 

        btnExit.addActionListener(this); // Register the ActionListener for the Exit button.

        try {
            // Create a ServerSocket on port 6666
            listener = new ServerSocket(6666, 1);
            taServer.append("Server started on port 6666\n"); // Let's user know server started successfully.
        } catch (IOException ioe) {
            taServer.append("Server error: " + ioe.getMessage()); // let's user know there was an error while creating server 
        }
    }

 
    // Handles action events 
    // parameter e: The ActionEvent generated.
    @Override
    public void actionPerformed(ActionEvent e) {
        System.exit(0); // Exit the application when the button is clicked.
    }

    
    // Initializes the ObjectInputStream and ObjectOutputStream from the client socket.
    // throws IOException: If an I/O error happens while stream is being created.
    private void getStreams() throws IOException {
        // Must create ObjectOutputStream first and flush it before ObjectInputStream 
        out = new ObjectOutputStream(client.getOutputStream());
        out.flush();
        in = new ObjectInputStream(client.getInputStream());
    }

    // Closes the input/output streams and the client socket.
    // throws IOException: If an I/O error happens wgile closing.
    private void closeStreams() throws IOException {
        out.close();
        in.close();
        client.close();
    }

    // Sends a String response to the connected client.
    // parameter response: The message to send.
    // throws IOException: If an I/O error happens while writing.
    private void sendData(String response) throws IOException {
        out.writeObject(response);
        out.flush(); // Ensure data is sent immediately.
    }

    // Accepts client connection, then initializes streams and processing.
    // throws IOException: If an I/O error happens while listening or accepting.
    private void listenForClients() throws IOException {
        taServer.append("Listening for clients...\n");
        client = listener.accept(); // waits until a client connects.
        taServer.append("Client connected: " + client.getInetAddress() + "\n"); // Let's user know client is connectedd.
        getStreams(); // Initialize the streams for communication.
        processClient(); // Start the loop to handle client commands.
    }

   
    // The main loop for processing commands from the connected client.
    public void processClient() {
        // Use try-catch to close the database connection.
        try (Connection conn = DBConnection.getConnection()) { 
            String msg;
            do {
                msg = (String) in.readObject(); // Read the command from the client.
                taServer.append("CLIENT >>> " + msg + "\n"); // Print the received message.
                String response = handleCommand(msg, conn); // Process the command and get a response.
                sendData(response); // Send the response back to the client.
            } while (!msg.equalsIgnoreCase("EXIT")); // Continue until the client sends "EXIT".
            closeStreams(); // Close network resources after the client exits.
        } catch (Exception e) {
            taServer.append("Error: " + e.getMessage() + "\n"); // Prints any connection or processing errors.
        }
    }

    // parameter msg: The command string from the client.
    // parameter conn: The active database connection.
    // returns a response string (e.g., "SUCCESS:student" or "ERROR:message").
    private String handleCommand(String msg, Connection conn) {
        try {
            String[] parts = msg.split(":", 2); // Split command ("LOGIN") from data (,"123,password").
            String command = parts[0].toUpperCase(); // Convert command part to uppercase.
            String data = parts.length > 1 ? parts[1] : ""; // Get the data part, or empty string if none.

            switch (command) {
                case "LOGIN":
                    return handleLogin(data, conn);
                case "ADD_STUDENT":
                    return handleAddStudent(data, conn);
                case "ADD_COURSE":
                    return handleAddCourse(data, conn);
                case "LIST_COURSES":
                    return handleListCourses(conn);
                case "ENROL":
                    return handleEnrol(data, conn);
                default:
                    return "ERROR:Unknown command"; // Response for unknown commands.
            }
        } catch (Exception e) {
            return "ERROR:" + e.getMessage(); // Return an error if anything fails.
        }
    }

    // Handles the LOGIN command by querying the database.
    private String handleLogin(String data, Connection conn) throws SQLException {
        String[] info = data.split(","); // Split the data into ID and password.
        int id = Integer.parseInt(info[0]);
        String pass = info[1];
        // Prepared statement to prevent SQL injection.
        PreparedStatement ps = conn.prepareStatement("SELECT role FROM students WHERE student_id=? AND password=?");
        ps.setInt(1, id);
        ps.setString(2, pass);
        ResultSet rs = ps.executeQuery(); // Execute the query.
        if (rs.next()) return "SUCCESS:" + rs.getString("role"); // Return success and the user's role.
        return "ERROR:Invalid login"; // Return error if no matching record is found.
    }

    // Handles the ADD_STUDENT command by inserting a new student record.
    private String handleAddStudent(String data, Connection conn) throws SQLException {
        String[] info = data.split(","); // Split data into ID, name, and password.
        int sid = Integer.parseInt(info[0]);
        String name = info[1];
        String pass = info[2];
        // Prepared statement to insert the new student.
        PreparedStatement ps = conn.prepareStatement("INSERT INTO students VALUES (?,?,?,?)");
        ps.setInt(1, sid);
        ps.setString(2, name);
        ps.setString(3, pass);
        ps.setString(4, "student"); // Default role is "student".
        ps.executeUpdate(); // Execute the insert statement.
        return "SUCCESS:Student added"; // Return success.
    }

    // Handles the ADD_COURSE command by inserting a new course record.
    private String handleAddCourse(String data, Connection conn) throws SQLException {
        String[] info = data.split(","); // Split data into Course ID and title.
        int cid = Integer.parseInt(info[0]);
        String title = info[1];
        // Prepared statement to insert the new course.
        PreparedStatement ps = conn.prepareStatement("INSERT INTO courses VALUES (?,?)");
        ps.setInt(1, cid);
        ps.setString(2, title);
        ps.executeUpdate(); // Execute the insert statement.
        return "SUCCESS:Course added"; // Return success confirmation.
    }

    // Handles the LIST_COURSES command by getting all courses from the database.
    private String handleListCourses(Connection conn) throws SQLException {
        Statement st = conn.createStatement();
        ResultSet rs = st.executeQuery("SELECT * FROM courses"); // Execute query to get all courses.
        StringBuilder sb = new StringBuilder("COURSES:"); // Start response with a list indicator.
        // Loop through the results and append to the StringBuilder.
        while (rs.next()) sb.append(rs.getInt(1)).append("-").append(rs.getString(2)).append(";");
        return sb.toString(); // Return the formatted string of courses.
    }

    // Handles the ENROL command by inserting a new enrolment record.
    private String handleEnrol(String data, Connection conn) throws SQLException {
        String[] info = data.split(","); // Split data into Student ID and Course ID.
        int sid = Integer.parseInt(info[0]);
        int cid = Integer.parseInt(info[1]);
        // Prepared statement to insert the new enrolment.
        PreparedStatement ps = conn.prepareStatement("INSERT INTO enrolments VALUES (?,?)");
        ps.setInt(1, sid);
        ps.setInt(2, cid);
        ps.executeUpdate(); // Execute the insert statement.
        return "SUCCESS:Enrolled successfully"; // Return success.
    }

    public static void main(String[] args) {
        ServerGUI sga = new ServerGUI();
        sga.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); 
        sga.setBounds(200, 300, 500, 400); 
        sga.setVisible(true); 
        try {
            sga.listenForClients(); 
        } catch (IOException ioe) {
            taServer.append("Error: " + ioe.getMessage()); // Print I/O error if listening fails.
        }
    }
}