package za.ac.cput.adp_term4_project_client;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;

/**
 * A dedicated GUI for handling user login and the initial connection setup.
 * It passes control to the main ClientGUI upon successful authentication.
 */
public class LoginRegisterGUI extends JFrame implements ActionListener {

    private final ClientGUI clientGUI; // Reference to the connected ClientGUI instance
    
    private JLabel lblStudentID = new JLabel("Student/Admin ID:");
    private JLabel lblPassword = new JLabel("Password:");
    private JTextField txtStudentID = new JTextField(15);
    private JPasswordField txtPassword = new JPasswordField(15);
    private JButton btnLogin = new JButton("Login");
    private JButton btnRegisterInfo = new JButton("Register (Admin Only)"); // Placeholder/Info button

    /**
     * Constructor. Requires an already instantiated and connected ClientGUI object.
     * @param clientGUI The ClientGUI instance that has successfully connected to the server.
     */
    public LoginRegisterGUI(ClientGUI clientGUI) {
        super("Student Enrolment System - Login");
        this.clientGUI = clientGUI;
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout(10, 10));

        // Center Panel for fields
        JPanel pnlCenter = new JPanel(new GridLayout(2, 2, 10, 10));
        pnlCenter.setBorder(BorderFactory.createEmptyBorder(20, 20, 10, 20));
        pnlCenter.add(lblStudentID);
        pnlCenter.add(txtStudentID);
        pnlCenter.add(lblPassword);
        pnlCenter.add(txtPassword);

        // South Panel for buttons
        JPanel pnlSouth = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 10));
        pnlSouth.add(btnLogin);
        pnlSouth.add(btnRegisterInfo);

        add(pnlCenter, BorderLayout.CENTER);
        add(pnlSouth, BorderLayout.SOUTH);

        btnLogin.addActionListener(this);
        btnRegisterInfo.addActionListener(this);

        // Finalize frame settings
        pack(); 
        setLocationRelativeTo(null); // Center the window
        setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == btnLogin) {
            handleLogin();
        } else if (e.getSource() == btnRegisterInfo) {
            // According to the project, adding students is an Admin function.
            JOptionPane.showMessageDialog(this, 
                "New Student/User registration is an Admin function.\nPlease log in as Admin to add a new user.", 
                "Registration Information", JOptionPane.INFORMATION_MESSAGE);
        }
    }

    private void handleLogin() {
        String id = txtStudentID.getText().trim();
        String password = new String(txtPassword.getPassword());

        if (id.isEmpty() || password.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please enter both ID and Password.", "Login Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        try {
            // 1. Format and send the LOGIN command
            String command = "LOGIN:" + id + "," + password;
            clientGUI.sendData(command); // Use the method from ClientGUI

            // 2. Wait for the server's response
            String res = clientGUI.receiveResponse(); 
            
            if (res.startsWith("SUCCESS:")) {
                String role = res.substring(8).trim();
                JOptionPane.showMessageDialog(this, "Login Successful! Role: " + role.toUpperCase());
                
                // 3. Hand over control to the main GUI
                this.dispose(); // Close the login window
                clientGUI.setRole(role); // Set role, which enables/disables buttons and makes the main frame visible
                
            } else if (res.startsWith("ERROR:")) {
                 // Login failure (e.g., incorrect credentials)
                String errorMsg = res.substring(6).trim();
                JOptionPane.showMessageDialog(this, "Login Failed: " + errorMsg, "Login Error", JOptionPane.ERROR_MESSAGE);
            } else {
                // Unexpected response
                 JOptionPane.showMessageDialog(this, "Unexpected server response: " + res, "Communication Error", JOptionPane.ERROR_MESSAGE);
            }
            
        } catch (IOException ex) {
            JOptionPane.showMessageDialog(this, "Network Error: Cannot communicate with server. " + ex.getMessage(), "Connection Failed", JOptionPane.ERROR_MESSAGE);
            clientGUI.taClient.append("Error during login: " + ex.getMessage() + "\n");
        } catch (ClassNotFoundException ex) {
             JOptionPane.showMessageDialog(this, "Internal Error: Received unknown object type.", "Internal Error", JOptionPane.ERROR_MESSAGE);
        }
        
        // Clear password field after attempt
        txtPassword.setText("");
    }
    
    // The main entry point for the Client application
    public static void main(String[] args) {
        // 1. Instantiate the main client application object
        ClientGUI clientApp = new ClientGUI();

        // 2. Attempt to connect to the server first
        if (clientApp.connectToServer()) {
            // 3. If connection succeeds, launch the Login screen
            new LoginRegisterGUI(clientApp); 
        } else {
            // 4. If connection fails, display error and exit
            JOptionPane.showMessageDialog(null, 
                "Failed to connect to the server (127.0.0.1:6666).\nPlease ensure the ServerGUI is running.", 
                "Fatal Connection Error", JOptionPane.ERROR_MESSAGE);
            System.exit(1);
        }
    }
}