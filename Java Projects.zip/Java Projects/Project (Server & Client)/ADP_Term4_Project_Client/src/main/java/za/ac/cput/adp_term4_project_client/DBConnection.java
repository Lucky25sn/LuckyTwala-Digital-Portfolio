/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package za.ac.cput.adp_term4_project_client;
import java.sql.*;
/**
 *
 * @author Phumlani
 */
public class DBConnection {
    private static final String URL = "jdbc:derby://localhost:1527/ADP_Students";
    private static final String USERNAME = "administrator";
    private static final String PASSWORD = "password";

    public static Connection getConnection() throws SQLException {
        return DriverManager.getConnection(URL, USERNAME, PASSWORD);
    }
}