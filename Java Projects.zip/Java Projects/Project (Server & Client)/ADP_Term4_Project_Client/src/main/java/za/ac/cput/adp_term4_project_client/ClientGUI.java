package za.ac.cput.adp_term4_project_client;

import java.awt.*; 
import java.awt.event.*; 
import java.io.*; 
import java.net.*; 
import javax.swing.*; 

/**
 *
 * @author Phumlani
 * Rewritten ClientGUI to be launched *after* successful login from LoginRegisterGUI.
 */
public class ClientGUI extends JFrame implements ActionListener {

    // Network components
    private Socket server; // Socket for the connection to the server.
    // Static streams for simple access across the application (LoginRegisterGUI)
    public static ObjectOutputStream out;
    public static ObjectInputStream in;

    // Panels for layout
    private JPanel pnlTop = new JPanel();
    private JPanel pnlCenter = new JPanel();
    private JPanel pnlButtons = new JPanel();

    // Labels and Text Area
    private JLabel lblStatus = new JLabel("Disconnected (Pending Connect)"); 
    protected static JTextArea taClient = new JTextArea(10, 40); 

    // Buttons (Login button removed)
    private JButton btnAddStudent = new JButton("Add Student (Admin)");
    private JButton btnAddCourse = new JButton("Add Course (Admin)");
    private JButton btnListCourses = new JButton("List Courses");
    private JButton btnEnrol = new JButton("Enrol");
    private JButton btnExit = new JButton("Exit");
    
    // --- New Field for Role Management ---
    private String userRole = ""; 

    // Constructor: Sets up the GUI components only. Network connection is external.
    public ClientGUI() {
        super("Client GUI - Not Logged In"); 

        setLayout(new BorderLayout());

        // Setup Top Panel
        pnlTop.add(lblStatus);
        add(pnlTop, BorderLayout.NORTH);

        // Setup Center Panel 
        pnlCenter.add(new JScrollPane(taClient)); 
        taClient.setEditable(false); 
        add(pnlCenter, BorderLayout.CENTER);

        // Setup Buttons Panel 
        pnlButtons.setLayout(new GridLayout(3, 2, 5, 5)); 
        pnlButtons.add(btnAddStudent);
        pnlButtons.add(btnAddCourse);
        pnlButtons.add(btnListCourses);
        pnlButtons.add(btnEnrol);
        pnlButtons.add(btnExit);
        add(pnlButtons, BorderLayout.SOUTH);

        // Register ActionListener for all buttons.
        btnAddStudent.addActionListener(this);
        btnAddCourse.addActionListener(this);
        btnListCourses.addActionListener(this);
        btnEnrol.addActionListener(this);
        btnExit.addActionListener(this);
        
        // Initial setup: main frame hidden and buttons disabled until login
        this.setVisible(false);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); 
        this.setBounds(200, 300, 500, 400); 
        setFunctionalButtonsEnabled(false);
    }
    
    /**
     * Attempts to connect to the server and initialize streams.
     * Must be called successfully before the LoginRegisterGUI is shown.
     * @return true if connection is successful, false otherwise.
     */
    public boolean connectToServer() {
        try {
            server = new Socket("127.0.0.1", 6666);
            getStreams(); // Initialize the input and output streams.
            lblStatus.setText("Connected to server (Awaiting Login)"); 
            taClient.append("Connected to the server. Please log in.\n"); 
            return true;
        } catch (IOException ioe) {
            lblStatus.setText("Connection failed");
            taClient.append("Connection failed: " + ioe.getMessage() + "\n");
            return false;
        }
    }

    /**
     * Initializes the ObjectInputStream and ObjectOutputStream from the server socket.
     */
    private void getStreams() throws IOException {
        // Must establish ObjectOutputStream first and flush before OIS
        out = new ObjectOutputStream(server.getOutputStream());
        out.flush();
        in = new ObjectInputStream(server.getInputStream());
    }

    /**
     * Enables or disables buttons based on the user's role and makes the GUI visible.
     * @param role The role of the logged-in user ("admin" or "student").
     */
    public void setRole(String role) {
        this.userRole = role;
        setTitle("Client GUI - Logged in as: " + role.toUpperCase());
        lblStatus.setText("Connected - Logged in as: " + role.toUpperCase());

        boolean isAdmin = role.equalsIgnoreCase("admin");
        
        // Admin Functionality
        btnAddStudent.setEnabled(isAdmin);
        btnAddCourse.setEnabled(isAdmin);
        
        // Student/General Functionality
        btnListCourses.setEnabled(true);
        btnEnrol.setEnabled(true);
        btnExit.setEnabled(true);
        
        // Show the main GUI frame
        this.setVisible(true);
    }
    
    /** Helper method to enable/disable all functional buttons (used before login) */
    private void setFunctionalButtonsEnabled(boolean enabled) {
        btnAddStudent.setEnabled(enabled);
        btnAddCourse.setEnabled(enabled);
        btnListCourses.setEnabled(enabled);
        btnEnrol.setEnabled(enabled);
        btnExit.setEnabled(enabled);
    }

    /**
     * Sends a message to the server via the ObjectOutputStream.
     * This method is public so LoginRegisterGUI can use it for the LOGIN command.
     */
    public void sendData(String msg) throws IOException {
        out.writeObject(msg);
        out.flush(); 
    }

    /**
     * Reads a String response from the server using the ObjectInputStream.
     * This method is public so LoginRegisterGUI can use it for the LOGIN command.
     */
    public String receiveResponse() throws IOException, ClassNotFoundException {
        return (String) in.readObject(); 
    }

    
    /** Handles action events from the buttons. */
    @Override
    public void actionPerformed(ActionEvent e) {
        // Simple check to prevent access if somehow a user bypassed login/role setting
        if (userRole.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Authentication required.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        
        try {
            // Check the source of the event and call the appropriate method.
            if (e.getSource() == btnAddStudent) addStudent();
            else if (e.getSource() == btnAddCourse) addCourse();
            else if (e.getSource() == btnListCourses) listCourses();
            else if (e.getSource() == btnEnrol) enrolStudent();
            else if (e.getSource() == btnExit) exitClient();
        } catch (Exception ex) {
            taClient.append("Communication Error: " + ex.getMessage() + "\n");
        }
    }

    // Admin function: Asks user for new Student details and sends an ADD_STUDENT command.
    private void addStudent() throws IOException, ClassNotFoundException {
        // Role check is enforced by button being disabled, but good to check server-side too
        String stud_ID = JOptionPane.showInputDialog(this, "Enter new student ID:");
        String name = JOptionPane.showInputDialog(this, "Enter student name:");
        String password = JOptionPane.showInputDialog(this, "Enter student password:");
        
        if (stud_ID == null || name == null || password == null) return; // User cancelled
        
        sendData("ADD_STUDENT:" + stud_ID + "," + name + "," + password);
        taClient.append("Server >>> " + receiveResponse() + "\n");
    }

    // Admin function: Asks user for new Course details and sends an ADD_COURSE command.
    private void addCourse() throws IOException, ClassNotFoundException {
        // Role check is enforced by button being disabled
        String course_ID = JOptionPane.showInputDialog(this, "Enter course ID:");
        String title = JOptionPane.showInputDialog(this, "Enter course title:");
        
        if (course_ID == null || title == null) return; // User cancelled
        
        sendData("ADD_COURSE:" + course_ID + "," + title);
        taClient.append("Server >>> " + receiveResponse() + "\n");
    }

    // Sends a LIST_COURSES command and processes the server's response.
    private void listCourses() throws IOException, ClassNotFoundException {
        sendData("LIST_COURSES");
        String res = receiveResponse();
        
        if (res.startsWith("COURSES:")) {
            taClient.append("Available Courses:\n");
            String[] courses = res.substring(8).split(";"); 
            for (String c : courses) if (!c.isEmpty()) taClient.append(c + "\n");
        } else {
            taClient.append(res + "\n");
        }
    }

    // Asks user for Student ID and Course ID and sends an ENROL command.
    private void enrolStudent() throws IOException, ClassNotFoundException {
        // NOTE: A better implementation would auto-fill the SID after login
        String sid = JOptionPane.showInputDialog(this, "Enter your student ID:"); 
        String cid = JOptionPane.showInputDialog(this, "Enter course ID:");
        
        if (sid == null || cid == null) return; // User cancelled
        
        sendData("ENROL:" + sid + "," + cid);
        taClient.append("Server >>> " + receiveResponse() + "\n");
    }

    
    // Sends an EXIT command to the server and close all resources
    private void exitClient() throws IOException {
        sendData("EXIT"); 
        taClient.append("Disconnected.\n");
        // Close streams and socket.
        out.close();
        in.close();
        server.close();
        System.exit(0); 
    }

    public static void main(String[] args) {
        // This is the new entry point for the client application.
        // It delegates startup and connection to the LoginRegisterGUI's main method.
        LoginRegisterGUI.main(args);
    }
}