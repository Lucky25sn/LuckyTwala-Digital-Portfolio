package za.ac.cput.project;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;


//Registration page for new users.
//Form to enter student details and register new student.

public class RegisterPage extends JFrame {

    //Input fields
    private JTextField txtStudNum;      // Student number input
    private JTextField txtName;         // Full name input
    private JTextField txtEmail;        // Email address input
    private JTextField txtPhoneNum;     // Phone number input
    private JPasswordField pswdPassword;        // Password input
    private JPasswordField pswdComfirmPass;     // Confirm password input

    //Buttons 
    private JButton btnRegister;        // Register button
    private JButton btnClear;           // Clear all fields button
    private JButton btnBackToLogin;     // Back to login screen button

    //Colors for styling
    private final Color BLUE = new Color(70, 130, 180);
    private final Color LIGHT_BLUE = new Color(173, 216, 230);
    private final Color LIGHT_GRAY = new Color(245, 245, 245);
    private final Color GREEN = new Color(60, 179, 113);

    //Constructor
    public RegisterPage() {
        setupWindow();      // Set up window design
        createComponents(); // Create all text fields and buttons
        arrangeComponents(); // Layout the components on the frame
        addEventHandlers(); // Add button click behavior
    }

    //Set up window design like as size and background colour.
    private void setupWindow() {
        setTitle("Campus Cafeteria - Register");
        setSize(650, 800);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setResizable(false);
        getContentPane().setBackground(LIGHT_GRAY);
    }

    //Create UI components (text fields, password fields, buttons).
    private void createComponents() {
        // Create input fields
        txtStudNum = createTextField();
        txtName = createTextField();
        txtEmail = createTextField();
        txtPhoneNum = createTextField();
        pswdPassword = createPasswordField();
        pswdComfirmPass = createPasswordField();

        // Create buttons with colors
        btnRegister = createButton("REGISTER", GREEN);
        btnClear = createButton("CLEAR", Color.GRAY);
        btnBackToLogin = createButton("BACK TO LOGIN", BLUE);
    }


    //Helper method to make a styled text field 
    private JTextField createTextField() {
        JTextField field = new JTextField(20);
        field.setPreferredSize(new Dimension(300, 40));
        field.setMaximumSize(new Dimension(300, 40));
        field.setFont(new Font("Arial", Font.PLAIN, 14));
        field.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(Color.LIGHT_GRAY, 1),
                BorderFactory.createEmptyBorder(5, 10, 5, 10)
        ));
        // Add focus listener to change border colour on focus
        field.addFocusListener(new FocusAdapter() {
            public void focusGained(FocusEvent e) {
                field.setBorder(BorderFactory.createCompoundBorder(
                        BorderFactory.createLineBorder(BLUE, 2),
                        BorderFactory.createEmptyBorder(4, 9, 4, 9)
                ));
            }

            public void focusLost(FocusEvent e) {
                field.setBorder(BorderFactory.createCompoundBorder(
                        BorderFactory.createLineBorder(Color.LIGHT_GRAY, 1),
                        BorderFactory.createEmptyBorder(5, 10, 5, 10)
                ));
            }
        });
        return field;
    }

    /**
     * Helper method to make a styled password field.
     */
    private JPasswordField createPasswordField() {
        JPasswordField field = new JPasswordField(20);
        field.setPreferredSize(new Dimension(300, 40));
        field.setMaximumSize(new Dimension(300, 40));
        field.setFont(new Font("Arial", Font.PLAIN, 14));
        field.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(Color.LIGHT_GRAY, 1),
                BorderFactory.createEmptyBorder(5, 10, 5, 10)
        ));
        // Add focus listener to change border colour on focus
        field.addFocusListener(new FocusAdapter() {
            public void focusGained(FocusEvent e) {
                field.setBorder(BorderFactory.createCompoundBorder(
                        BorderFactory.createLineBorder(BLUE, 2),
                        BorderFactory.createEmptyBorder(4, 9, 4, 9)
                ));
            }

            public void focusLost(FocusEvent e) {
                field.setBorder(BorderFactory.createCompoundBorder(
                        BorderFactory.createLineBorder(Color.LIGHT_GRAY, 1),
                        BorderFactory.createEmptyBorder(5, 10, 5, 10)
                ));
            }
        });
        return field;
    }


    //Helper to create a styled button with hover effect.
    private JButton createButton(String text, Color color) {
        JButton button = new JButton(text);
        button.setPreferredSize(new Dimension(180, 45));
        button.setBackground(color);
        button.setForeground(Color.WHITE);
        button.setFont(new Font("Arial", Font.BOLD, 16));
        button.setFocusPainted(false);
        button.setBorderPainted(false);
        button.setOpaque(true);
        button.setCursor(new Cursor(Cursor.HAND_CURSOR));

        // Hover effect that brightens the colour on mouse over
        button.addMouseListener(new MouseAdapter() {
            public void mouseEntered(MouseEvent evt) {
                button.setBackground(color.brighter());
            }

            public void mouseExited(MouseEvent evt) {
                button.setBackground(color);
            }
        });
        return button;
    }

    //Arrange the header, form, buttons, and back-to-login button vertically.
    private void arrangeComponents() {
        setLayout(new BorderLayout());
        JPanel pnlMain = new JPanel();
        pnlMain.setLayout(new BoxLayout(pnlMain, BoxLayout.Y_AXIS));
        pnlMain.setBorder(BorderFactory.createEmptyBorder(30, 50, 30, 50));
        pnlMain.setBackground(LIGHT_GRAY);

        pnlMain.add(createHeader());               // Top title
        pnlMain.add(Box.createVerticalStrut(25));
        pnlMain.add(createForm());                 // Main form inputs
        pnlMain.add(Box.createVerticalStrut(25));
        pnlMain.add(createButtonPanel());          // Buttons stacked vertically
        pnlMain.add(Box.createVerticalStrut(20));
        pnlMain.add(createBackToLoginSection());   // "Already have account?" link

        add(pnlMain, BorderLayout.CENTER);
    }

    //Header section with title and subtitle.
    private JPanel createHeader() {
        JPanel pnlHeader = new JPanel();
        pnlHeader.setLayout(new BoxLayout(pnlHeader, BoxLayout.Y_AXIS));
        pnlHeader.setBackground(LIGHT_GRAY);

        JLabel lblTitle = new JLabel("Campus Cafeteria");
        lblTitle.setFont(new Font("Arial", Font.BOLD, 32));
        lblTitle.setForeground(BLUE);
        lblTitle.setAlignmentX(Component.CENTER_ALIGNMENT);

        JLabel lblSubtitle = new JLabel("Create New Account");
        lblSubtitle.setFont(new Font("Arial", Font.PLAIN, 16));
        lblSubtitle.setForeground(Color.GRAY);
        lblSubtitle.setAlignmentX(Component.CENTER_ALIGNMENT);

        pnlHeader.add(lblTitle);
        pnlHeader.add(Box.createVerticalStrut(5));
        pnlHeader.add(lblSubtitle);

        return pnlHeader;
    }

    //Make the form with labels and input fields arranged vertically.
    private JPanel createForm() {
        JPanel pnlForm = new JPanel();
        pnlForm.setLayout(new BoxLayout(pnlForm, BoxLayout.Y_AXIS));
        pnlForm.setBackground(LIGHT_GRAY);

        JLabel welcomeLabel = new JLabel("Please fill in all details to register");
        welcomeLabel.setFont(new Font("Arial", Font.PLAIN, 14));
        welcomeLabel.setForeground(Color.DARK_GRAY);
        welcomeLabel.setAlignmentX(Component.CENTER_ALIGNMENT);

        pnlForm.add(welcomeLabel);
        pnlForm.add(Box.createVerticalStrut(20));
        pnlForm.add(createLabelFieldPair("Student Number:", txtStudNum));
        pnlForm.add(Box.createVerticalStrut(12));
        pnlForm.add(createLabelFieldPair("Full Name:", txtName));
        pnlForm.add(Box.createVerticalStrut(12));
        pnlForm.add(createLabelFieldPair("Email Address:", txtEmail));
        pnlForm.add(Box.createVerticalStrut(12));
        pnlForm.add(createLabelFieldPair("Phone Number:", txtPhoneNum));
        pnlForm.add(Box.createVerticalStrut(12));
        pnlForm.add(createLabelFieldPair("Password:", pswdPassword));
        pnlForm.add(Box.createVerticalStrut(12));
        pnlForm.add(createLabelFieldPair("Confirm Password:", pswdComfirmPass));

        return pnlForm;
    }
    
    //Helper method to make a label above its field
    private JPanel createLabelFieldPair(String labelText, JComponent field) {
        JPanel panel = new JPanel();
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
        panel.setBackground(LIGHT_GRAY);

        JLabel label = new JLabel(labelText);
        label.setFont(new Font("Arial", Font.BOLD, 14));
        label.setAlignmentX(Component.CENTER_ALIGNMENT);

        field.setAlignmentX(Component.CENTER_ALIGNMENT);

        panel.add(label);
        panel.add(Box.createVerticalStrut(5));
        panel.add(field);

        return panel;
    }

    //Button panel arranged vertically for Register and Clear buttons.
    private JPanel createButtonPanel() {
        JPanel pnlButton = new JPanel();
        pnlButton.setLayout(new BoxLayout(pnlButton, BoxLayout.Y_AXIS));
        pnlButton.setBackground(LIGHT_GRAY);

        btnRegister.setAlignmentX(Component.CENTER_ALIGNMENT);
        btnClear.setAlignmentX(Component.CENTER_ALIGNMENT);

        pnlButton.add(btnRegister);
        pnlButton.add(Box.createVerticalStrut(15));
        pnlButton.add(btnClear);

        return pnlButton;
    }

    //"Already have an account? Back to login" section.
    private JPanel createBackToLoginSection() {
        JPanel pnlLogin = new JPanel();
        pnlLogin.setLayout(new BoxLayout(pnlLogin, BoxLayout.Y_AXIS));
        pnlLogin.setBackground(LIGHT_GRAY);

        JSeparator separator = new JSeparator();
        separator.setMaximumSize(new Dimension(300, 1));
        separator.setAlignmentX(Component.CENTER_ALIGNMENT);

        JLabel lblLogin = new JLabel("Already have an account?");
        lblLogin.setFont(new Font("Arial", Font.PLAIN, 14));
        lblLogin.setForeground(Color.DARK_GRAY);
        lblLogin.setAlignmentX(Component.CENTER_ALIGNMENT);

        btnBackToLogin.setAlignmentX(Component.CENTER_ALIGNMENT);

        pnlLogin.add(separator);
        pnlLogin.add(Box.createVerticalStrut(15));
        pnlLogin.add(lblLogin);
        pnlLogin.add(Box.createVerticalStrut(10));
        pnlLogin.add(btnBackToLogin);

        return pnlLogin;
    }

    //Event hamdling: register, clear, and back to login.
    private void addEventHandlers() {
        btnRegister.addActionListener(e -> {
            if (validateAllFields()) {
                performRegistration(); // Only register if validation passes
            }
        });

        btnClear.addActionListener(e -> clearAllFields());
        btnBackToLogin.addActionListener(e -> backToLogin());
    }


    //Validate all fields: check empty fields, password length, and password match.
    private boolean validateAllFields() {
        if (txtStudNum.getText().trim().isEmpty()) {
            showError("Please enter your student number");
            return false;
        }
        if (pswdPassword.getPassword().length < 4) {
            showError("Password must be at least 4 characters");
            return false;
        }
        if (!new String(pswdPassword.getPassword())
                .equals(new String(pswdComfirmPass.getPassword()))) {
            showError("Passwords do not match");
            return false;
        }
        return true;
    }

    //Collect form data, create a StudentInfo object, and register the student.
    private void performRegistration() {
        //Validation to make sure all fields are filled
        if (txtStudNum.getText().trim().isEmpty()
                || txtName.getText().trim().isEmpty()
                || txtEmail.getText().trim().isEmpty()
                || txtPhoneNum.getText().trim().isEmpty()
                || pswdPassword.getPassword().length < 4) {
            JOptionPane.showMessageDialog(this, "Please fill in all fields and use a password of at least 4 characters.");
            return;
        }

        // Collect data from text fields
        String studentNumber = txtStudNum.getText().trim();
        String name = txtName.getText().trim();
        String email = txtEmail.getText().trim();
        String phone = txtPhoneNum.getText().trim();
        String password = new String(pswdPassword.getPassword());

        // Create and register student
        StudentInfo newStudent = new StudentInfo(studentNumber, name, email, phone, password);
       // StudentInfo.registerStudent(newStudent);

        JOptionPane.showMessageDialog(this, "Registration successful!");

        // Close registration window and open login page
        this.dispose();
       // SwingUtilities.invokeLater(() -> new LoginPage().setVisible(true));
    }

    //Clear all input fields and put focus on student number.
    private void clearAllFields() {
        txtStudNum.setText("");
        txtName.setText("");
        txtEmail.setText("");
        txtPhoneNum.setText("");
        pswdPassword.setText("");
        pswdComfirmPass.setText("");
        txtStudNum.requestFocus();
    }

    //Go back to login page when user clicks "Back to Login".
    private void backToLogin() {
        this.setVisible(false);
       // SwingUtilities.invokeLater(() -> new LoginPage().setVisible(true));
        this.dispose();
    }

    //Show an error message.
    private void showError(String message) {
        JOptionPane.showMessageDialog(this, message, "Error", JOptionPane.ERROR_MESSAGE);
    }


    //Main method for RegidterPage.
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new RegisterPage().setVisible(true));
    }
}
