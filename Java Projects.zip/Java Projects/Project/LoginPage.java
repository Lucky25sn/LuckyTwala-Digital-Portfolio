package za.ac.cput.project;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;


//Login page 
public class LoginPage extends JFrame {

    //Input fields
    private JTextField txtStudNum;       // Student number
    private JPasswordField pswdPassword; // Password 

    //Buttons 
    private JButton btnLogin;    // Login button
    private JButton btnClear;    // Clear input fields button
    private JButton btnRegister; // Opens registration page

    //Color scheme
    private final Color BLUE = new Color(70, 130, 180);
    private final Color LIGHT_GRAY = new Color(245, 245, 245);
    private final Color GREEN = new Color(60, 179, 113);

    //Constructor
    public LoginPage() {
        setupWindow();      // Set up window size and design
        createComponents(); // Create UI components
        arrangeComponents();// Design for components on the frame
        addEventHandlers(); // Event handling for buttons
    }

    //Set up window design like title, size, and background.
    private void setupWindow() {
        setTitle("Campus Cafeteria - Login");
        setSize(550, 700);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setResizable(false);
        getContentPane().setBackground(LIGHT_GRAY);
    }


    //Create text fields, password field, and buttons.
    private void createComponents() {
        txtStudNum = createTextField();          // Student number input
        pswdPassword = createPasswordField();    // Password input

        // Create buttons
        btnLogin = createButton("LOGIN", BLUE);
        btnClear = createButton("CLEAR", Color.GRAY);
        btnRegister = createButton("REGISTER", GREEN);
    }

    //Helper method to create a styled text field
    private JTextField createTextField() {
        JTextField field = new JTextField(20);
        field.setPreferredSize(new Dimension(300, 40));
        field.setMaximumSize(new Dimension(300, 40));
        field.setFont(new Font("Arial", Font.PLAIN, 14));
        field.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(Color.LIGHT_GRAY, 1),
                BorderFactory.createEmptyBorder(5, 10, 5, 10)
        ));

        // Change border when focus gained/lost
        field.addFocusListener(new FocusAdapter() {
            public void focusGained(FocusEvent e) {
                field.setBorder(BorderFactory.createCompoundBorder(
                        BorderFactory.createLineBorder(BLUE, 2),
                        BorderFactory.createEmptyBorder(4, 9, 4, 9)
                ));
            }

            public void focusLost(FocusEvent e) {
                field.setBorder(BorderFactory.createCompoundBorder(
                        BorderFactory.createLineBorder(Color.LIGHT_GRAY, 1),
                        BorderFactory.createEmptyBorder(5, 10, 5, 10)
                ));
            }
        });

        return field;
    }


    //Helper method to create a styled password field
    private JPasswordField createPasswordField() {
        JPasswordField field = new JPasswordField(20);
        field.setPreferredSize(new Dimension(300, 40));
        field.setMaximumSize(new Dimension(300, 40));
        field.setFont(new Font("Arial", Font.PLAIN, 14));
        field.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(Color.LIGHT_GRAY, 1),
                BorderFactory.createEmptyBorder(5, 10, 5, 10)
        ));

        // Change border when focus gained/lost
        field.addFocusListener(new FocusAdapter() {
            public void focusGained(FocusEvent e) {
                field.setBorder(BorderFactory.createCompoundBorder(
                        BorderFactory.createLineBorder(BLUE, 2),
                        BorderFactory.createEmptyBorder(4, 9, 4, 9)
                ));
            }

            public void focusLost(FocusEvent e) {
                field.setBorder(BorderFactory.createCompoundBorder(
                        BorderFactory.createLineBorder(Color.LIGHT_GRAY, 1),
                        BorderFactory.createEmptyBorder(5, 10, 5, 10)
                ));
            }
        });

        return field;
    }

    //Helper method to create a modern styled button
    private JButton createButton(String text, Color color) {
        JButton button = new JButton(text);
        button.setPreferredSize(new Dimension(180, 45));
        button.setBackground(color);
        button.setForeground(Color.WHITE);
        button.setFont(new Font("Arial", Font.BOLD, 16));
        button.setFocusPainted(false);
        button.setBorderPainted(false);
        button.setOpaque(true);
        button.setCursor(new Cursor(Cursor.HAND_CURSOR));

        // Hover effect to brighten color
        button.addMouseListener(new MouseAdapter() {
            public void mouseEntered(MouseEvent evt) {
                button.setBackground(color.brighter());
            }

            public void mouseExited(MouseEvent evt) {
                button.setBackground(color);
            }
        });

        return button;
    }

    //set up header, form, buttons, and register section vertically.
    private void arrangeComponents() {
        setLayout(new BorderLayout());

        JPanel pnlMain = new JPanel();
        pnlMain.setLayout(new BoxLayout(pnlMain, BoxLayout.Y_AXIS));
        pnlMain.setBorder(BorderFactory.createEmptyBorder(40, 50, 40, 50));
        pnlMain.setBackground(LIGHT_GRAY);

        pnlMain.add(createHeader());            // Top title
        pnlMain.add(Box.createVerticalStrut(30));
        pnlMain.add(createForm());              // Student number + password fields
        pnlMain.add(Box.createVerticalStrut(30));
        pnlMain.add(createButtonPanel());       // Login and clear buttons
        pnlMain.add(Box.createVerticalStrut(20));
        pnlMain.add(createRegisterSection());   // "Don't have an account?"

        add(pnlMain, BorderLayout.CENTER);
    }

    //Header section with title and subtitle.
    private JPanel createHeader() {
        JPanel pnlHeader = new JPanel();
        pnlHeader.setLayout(new BoxLayout(pnlHeader, BoxLayout.Y_AXIS));
        pnlHeader.setBackground(LIGHT_GRAY);

        JLabel lblTitle = new JLabel("Campus Cafeteria");
        lblTitle.setFont(new Font("Arial", Font.BOLD, 32));
        lblTitle.setForeground(BLUE);
        lblTitle.setAlignmentX(Component.CENTER_ALIGNMENT);

        JLabel lblSubtitle = new JLabel("Welcome Back!");
        lblSubtitle.setFont(new Font("Arial", Font.PLAIN, 16));
        lblSubtitle.setForeground(Color.GRAY);
        lblSubtitle.setAlignmentX(Component.CENTER_ALIGNMENT);

        pnlHeader.add(lblTitle);
        pnlHeader.add(Box.createVerticalStrut(5));
        pnlHeader.add(lblSubtitle);

        return pnlHeader;
    }

    //Form section with student number and password fields.
    private JPanel createForm() {
        JPanel pnlForm = new JPanel();
        pnlForm.setLayout(new BoxLayout(pnlForm, BoxLayout.Y_AXIS));
        pnlForm.setBackground(LIGHT_GRAY);

        JLabel welcomeLabel = new JLabel("Please login to continue");
        welcomeLabel.setFont(new Font("Arial", Font.PLAIN, 14));
        welcomeLabel.setForeground(Color.DARK_GRAY);
        welcomeLabel.setAlignmentX(Component.CENTER_ALIGNMENT);

        pnlForm.add(welcomeLabel);
        pnlForm.add(Box.createVerticalStrut(25));
        pnlForm.add(createLabelFieldPair("Student Number:", txtStudNum));
        pnlForm.add(Box.createVerticalStrut(15));
        pnlForm.add(createLabelFieldPair("Password:", pswdPassword));

        return pnlForm;
    }

    //Helper method to create a label above its field
    private JPanel createLabelFieldPair(String labelText, JComponent field) {
        JPanel panel = new JPanel();
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
        panel.setBackground(LIGHT_GRAY);

        JLabel label = new JLabel(labelText);
        label.setFont(new Font("Arial", Font.BOLD, 14));
        label.setAlignmentX(Component.CENTER_ALIGNMENT);

        field.setAlignmentX(Component.CENTER_ALIGNMENT);

        panel.add(label);
        panel.add(Box.createVerticalStrut(5));
        panel.add(field);

        return panel;
    }

    //Panel for login and clear buttons side by side.
    private JPanel createButtonPanel() {
        JPanel pnlButton = new JPanel();
        pnlButton.setLayout(new FlowLayout(FlowLayout.CENTER, 20, 10));
        pnlButton.setBackground(LIGHT_GRAY);
        pnlButton.add(btnLogin);
        pnlButton.add(btnClear);
        return pnlButton;
    }

    //"Don't have an account?" and Register button.
    private JPanel createRegisterSection() {
        JPanel pnlRegister = new JPanel();
        pnlRegister.setLayout(new BoxLayout(pnlRegister, BoxLayout.Y_AXIS));
        pnlRegister.setBackground(LIGHT_GRAY);

        JSeparator separator = new JSeparator();
        separator.setMaximumSize(new Dimension(300, 1));
        separator.setAlignmentX(Component.CENTER_ALIGNMENT);

        JLabel lblRegister = new JLabel("Don't have an account?");
        lblRegister.setFont(new Font("Arial", Font.PLAIN, 14));
        lblRegister.setForeground(Color.DARK_GRAY);
        lblRegister.setAlignmentX(Component.CENTER_ALIGNMENT);

        btnRegister.setAlignmentX(Component.CENTER_ALIGNMENT);

        pnlRegister.add(separator);
        pnlRegister.add(Box.createVerticalStrut(15));
        pnlRegister.add(lblRegister);
        pnlRegister.add(Box.createVerticalStrut(10));
        pnlRegister.add(btnRegister);

        return pnlRegister;
    }


    //Event handling: login, clear, and open register page.
    private void addEventHandlers() {
        btnLogin.addActionListener(e -> performLogin());
        btnClear.addActionListener(e -> clearAllFields());
        btnRegister.addActionListener(e -> openRegisterPage());
    }

 
    //Login by validating inputs 
    private void performLogin() {
        String studentNumber = txtStudNum.getText().trim();
        String password = new String(pswdPassword.getPassword());

        //Validation for inputs
        if (studentNumber.isEmpty()) {
            showError("Please enter your student number");
            return;
        }
        if (password.length() < 4) {
            showError("Please enter your password (at least 4 characters)");
            return;
        }
        Object loggedInStudent = null;

        // Check details using StudentInfo login method
        //StudentInfo loggedInStudent = StudentInfo.loginStudent(studentNumber, password);

        if (loggedInStudent == null) {
            showError("Invalid student number or password");
            return;
        }

        JOptionPane.showMessageDialog(this, "Login successful!");

        // Close login page and open Project page
        this.dispose();
        new Project((StudentInfo) loggedInStudent).setVisible(true);
    }

    //Show an error message.
    private void showError(String message) {
        JOptionPane.showMessageDialog(this, message, "Error", JOptionPane.ERROR_MESSAGE);
    }

    //Clear all input fields and focus on student number.
    private void clearAllFields() {
        txtStudNum.setText("");
        pswdPassword.setText("");
        txtStudNum.requestFocus();
    }

    //Open the RegisterPage when user clicks "REGISTER".
    private void openRegisterPage() {
        this.setVisible(false);
//        SwingUtilities.invokeLater(() -> new RegisterPage().setVisible(true));
        this.dispose();
    }


    //Main method for the LoginPage
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new LoginPage().setVisible(true));
    }
}
