package za.ac.cput.project;

import javax.swing.*;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import javax.imageio.ImageIO;

// Main application class extending JFrame
public class Project extends JFrame {

    // Store logged in student info
    private StudentInfo studentInfo;
    // Menu items and items added to cart
    private final List<MenuItem> menuItems = new ArrayList<>();
    private final List<MenuItem> cart = new ArrayList<>();
    // Item-list panels (these are the ones we clear/rebuild)
    private JPanel pnlMenu;   // list of menu item cards (inside a container with header + scroll)
    private JPanel pnlCart;   // list of cart item cards (inside a container with header + scroll)
    // Labels for total, welcome message, and item count
    private JLabel lblTotal;
    private JLabel lblWelcome;
    private JLabel lblItemCount;
    // Tracks total price of items
    private double total = 0.0;

    // Scheduled order time and order history
    private String scheduledTime = "";
    private final List<String> orderHistory = new ArrayList<>();

    // Make theme colors
    private static final Color PRIMARY_COLOR = new Color(41, 128, 185);
    private static final Color SECONDARY_COLOR = new Color(52, 73, 94);
    private static final Color SUCCESS_COLOR = new Color(39, 174, 96);
    private static final Color DANGER_COLOR = new Color(231, 76, 60);
    private static final Color WARNING_COLOR = new Color(241, 196, 15);
    private static final Color LIGHT_GRAY = new Color(248, 249, 250);
    private static final Color CARD_BACKGROUND = Color.WHITE;

    // Default constructor using guest info
    public Project() {
        String password = null;
       // this(new StudentInfo("Unknown", "Guest User", "guest@example.com", "0000000000", password));
    }

    // Constructor
    public Project(StudentInfo studentInfo) {
        this.studentInfo = studentInfo;
        setupApplication();    // Set up window properties
        initializeMenu();      // Load menu items
        createUserInterface(); // Create GUI (initializes pnlMenu/pnlCart)
        setLocationRelativeTo(null); // Center window
    }

    // Set up basic window settings
    private void setupApplication() {
        setTitle("Campus Cafeteria");
        setSize(1000, 750);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());
    }

    // Create the UI
    private void createUserInterface() {
        JPanel pnlMain = new JPanel(new BorderLayout());
        pnlMain.setBackground(LIGHT_GRAY);

        // Add header and main content
        pnlMain.add(createHeaderPanel(), BorderLayout.NORTH);
        pnlMain.add(createContentPanel(), BorderLayout.CENTER);
        pnlMain.add(createStatusBar(), BorderLayout.SOUTH);

        add(pnlMain);
        pack();
    }

    // Create header with title and welcome message
    private JPanel createHeaderPanel() {
        JPanel pnlHeader = new JPanel(new BorderLayout());
        pnlHeader.setBackground(PRIMARY_COLOR);
        pnlHeader.setBorder(BorderFactory.createEmptyBorder(15, 20, 15, 20));

        // Title on the left
        JPanel pnlTitle = new JPanel(new FlowLayout(FlowLayout.LEFT, 0, 0));
        pnlTitle.setOpaque(false);
        JLabel lblTitle = new JLabel("Campus Cafeteria");
        lblTitle.setFont(new Font("Segoe UI", Font.BOLD, 28));
        lblTitle.setForeground(Color.WHITE);
        pnlTitle.add(lblTitle);

        // Welcome info on the right
        JPanel pnlWelcome = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 0));
        pnlWelcome.setOpaque(false);
        lblWelcome = new JLabel("Welcome, " + studentInfo.getName());
        lblWelcome.setFont(new Font("Segoe UI", Font.PLAIN, 16));
        lblWelcome.setForeground(Color.WHITE);

        JLabel lblStudNum = new JLabel("Student ID: " + studentInfo.getStudentNumber());
        lblStudNum.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        lblStudNum.setForeground(new Color(189, 195, 199));

        pnlWelcome.add(lblWelcome);
        pnlWelcome.add(lblStudNum);

        pnlHeader.add(pnlTitle, BorderLayout.WEST);
        pnlHeader.add(pnlWelcome, BorderLayout.EAST);

        return pnlHeader;
    }

    // Split panel showing menu on left, cart on right
    private JSplitPane createContentPanel() {
        JPanel leftMenuContainer = createMenuContainer();
        JPanel rightCartContainer = createCartContainer();

        JSplitPane splitPane = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT, leftMenuContainer, rightCartContainer);
        splitPane.setDividerLocation(600); // Set split position
        splitPane.setResizeWeight(0.6);
        splitPane.setBorder(null);
        splitPane.setBackground(LIGHT_GRAY);

        return splitPane;
    }

    // Create the menu container
    private JPanel createMenuContainer() {
        JPanel container = new JPanel(new BorderLayout());
        container.setBackground(LIGHT_GRAY);
        container.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 10));

        // Menu title
        JPanel menuHeader = new JPanel(new FlowLayout(FlowLayout.LEFT, 0, 0));
        menuHeader.setOpaque(false);
        JLabel menuTitle = new JLabel("Today's Menu");
        menuTitle.setFont(new Font("Segoe UI", Font.BOLD, 20));
        menuTitle.setForeground(SECONDARY_COLOR);
        menuHeader.add(menuTitle);

        // Item-list panel with vertical layout
        pnlMenu = new JPanel();
        pnlMenu.setLayout(new BoxLayout(pnlMenu, BoxLayout.Y_AXIS));
        pnlMenu.setBackground(LIGHT_GRAY);

        // Scrollable menu
        JScrollPane menuScrollPane = new JScrollPane(pnlMenu);
        menuScrollPane.setBorder(null);
        menuScrollPane.setBackground(LIGHT_GRAY);
        menuScrollPane.getVerticalScrollBar().setUnitIncrement(16);

        container.add(menuHeader, BorderLayout.NORTH);
        container.add(menuScrollPane, BorderLayout.CENTER);

        displayMenu();
        return container;
    }

    // Create the RIGHT container
    private JPanel createCartContainer() {
        JPanel container = new JPanel(new BorderLayout());
        container.setBackground(LIGHT_GRAY);
        container.setBorder(BorderFactory.createEmptyBorder(20, 10, 20, 20));

        JPanel pnlCartHeader = createCartHeader();

        // Item-list panel with vertical layout
        pnlCart = new JPanel();
        pnlCart.setLayout(new BoxLayout(pnlCart, BoxLayout.Y_AXIS));
        pnlCart.setBackground(LIGHT_GRAY);

        // Scrollable cart
        JScrollPane cartScrollPane = new JScrollPane(pnlCart);
        cartScrollPane.setBorder(null);
        cartScrollPane.setBackground(LIGHT_GRAY);
        cartScrollPane.getVerticalScrollBar().setUnitIncrement(16);
        cartScrollPane.setPreferredSize(new Dimension(350, 400));

        JPanel pnlCheckout = createCheckoutPanel(); // Buttons and total

        // Add header, cart list, and checkout section
        container.add(pnlCartHeader, BorderLayout.NORTH);
        container.add(cartScrollPane, BorderLayout.CENTER);
        container.add(pnlCheckout, BorderLayout.SOUTH);

        // Initial empty view
        updateCart();

        return container;
    }

    // Create cart header (title and item count)
    private JPanel createCartHeader() {
        JPanel pnlCartHeader = new JPanel(new BorderLayout());
        pnlCartHeader.setOpaque(false);
        pnlCartHeader.setBorder(BorderFactory.createEmptyBorder(0, 0, 15, 0));

        JLabel lblCartTitle = new JLabel("Your Order");
        lblCartTitle.setFont(new Font("Segoe UI", Font.BOLD, 20));
        lblCartTitle.setForeground(SECONDARY_COLOR);

        lblItemCount = new JLabel("0 items");
        lblItemCount.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        lblItemCount.setForeground(new Color(127, 140, 141));

        pnlCartHeader.add(lblCartTitle, BorderLayout.WEST);
        pnlCartHeader.add(lblItemCount, BorderLayout.EAST);

        return pnlCartHeader;
    }

    // Panel for checkout buttons and total label
    private JPanel createCheckoutPanel() {
        JPanel pnlCheckout = new JPanel();
        pnlCheckout.setLayout(new BoxLayout(pnlCheckout, BoxLayout.Y_AXIS));
        pnlCheckout.setBackground(CARD_BACKGROUND);
        pnlCheckout.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(220, 221, 225), 1),
                BorderFactory.createEmptyBorder(20, 20, 20, 20)
        ));

        // Buttons
        JPanel pnlButton = new JPanel(new GridLayout(1, 4, 8, 0));
        pnlButton.setOpaque(false);

        // Create buttons for checkout, logout, schedule, and view history
        JButton btnCheckout = createStyledButton("Checkout", SUCCESS_COLOR);
        JButton btnLogout = createStyledButton("Logout", DANGER_COLOR);
        JButton btnSchedule = createStyledButton("Set Pickup", WARNING_COLOR);
        JButton btnHistory = createStyledButton("View History", SECONDARY_COLOR);

        // Event Handling
        btnCheckout.addActionListener(e -> handleCheckout());
        btnLogout.addActionListener(e -> logout());
        btnSchedule.addActionListener(e -> {
            scheduledTime = JOptionPane.showInputDialog(this, "Enter your preferred pickup time (e.g. 13:30):",
                    "Schedule Order", JOptionPane.PLAIN_MESSAGE);
        });
        btnHistory.addActionListener(e -> viewHistory());

        // Add buttons to panel
        pnlButton.add(btnCheckout);
        pnlButton.add(btnLogout);
        pnlButton.add(btnSchedule);
        pnlButton.add(btnHistory);

        JPanel pnlButtonWrapper = new JPanel(new FlowLayout(FlowLayout.CENTER, 0, 5));
        pnlButtonWrapper.setOpaque(false);
        pnlButtonWrapper.add(pnlButton);

        // Total label below buttons
        JPanel pnlTotal = new JPanel(new FlowLayout(FlowLayout.CENTER));
        pnlTotal.setOpaque(false);

        lblTotal = new JLabel("Total: R0.00");
        lblTotal.setFont(new Font("Segoe UI", Font.BOLD, 16));
        lblTotal.setForeground(SUCCESS_COLOR);
        pnlTotal.add(lblTotal);

        pnlCheckout.add(pnlButtonWrapper);
        pnlCheckout.add(Box.createRigidArea(new Dimension(0, 10)));
        pnlCheckout.add(pnlTotal);

        return pnlCheckout;
    }

    // Create a styled button
    private JButton createStyledButton(String text, Color backgroundColor) {
        JButton button = new JButton(text);
        button.setPreferredSize(new Dimension(150, 55)); // Set size
        button.setFont(new Font("Segoe UI", Font.BOLD, 14));
        button.setForeground(Color.WHITE);
        button.setBackground(backgroundColor);
        button.setFocusPainted(false);
        button.setCursor(new Cursor(Cursor.HAND_CURSOR));

        // Change color on hover
        Color hoverColor = backgroundColor.darker();
        button.addMouseListener(new java.awt.event.MouseAdapter() {
            @Override
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                button.setBackground(hoverColor);
            }
            @Override
            public void mouseExited(java.awt.event.MouseEvent evt) {
                button.setBackground(backgroundColor);
            }
        });
        return button;
    }

    // Button used to remove items from cart
    private JButton createRemoveButton() {
        JButton button = new JButton("×");
        button.setPreferredSize(new Dimension(50, 40));
        button.setFont(new Font("Segoe UI", Font.BOLD, 18));
        button.setBackground(DANGER_COLOR);
        button.setForeground(Color.WHITE);
        button.setFocusPainted(false);
        button.setCursor(new Cursor(Cursor.HAND_CURSOR));

        // Hover color effect
        Color hoverColor = DANGER_COLOR.darker();
        button.addMouseListener(new java.awt.event.MouseAdapter() {
            @Override
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                button.setBackground(hoverColor);
            }
            @Override
            public void mouseExited(java.awt.event.MouseEvent evt) {
                button.setBackground(DANGER_COLOR);
            }
        });
        return button;
    }

    // Status bar
    private JPanel createStatusBar() {
        JPanel pnlStatusBar = new JPanel(new BorderLayout());
        pnlStatusBar.setBackground(SECONDARY_COLOR);
        pnlStatusBar.setBorder(BorderFactory.createEmptyBorder(10, 20, 10, 20));

        JLabel lblContact = new JLabel("📧 " + studentInfo.getEmail() + " | 📞 " + studentInfo.getPhone());
        lblContact.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        lblContact.setForeground(Color.WHITE);

        JLabel lblTime = new JLabel("🕐 " + java.time.LocalTime.now().toString().substring(0, 5));
        lblTime.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        lblTime.setForeground(new Color(189, 195, 199));

        pnlStatusBar.add(lblContact, BorderLayout.WEST);
        pnlStatusBar.add(lblTime, BorderLayout.EAST);

        return pnlStatusBar;
    }

    // Image for a menu item
    private ImageIcon getImageForItem(String itemName) {
        ImageIcon actualImage = loadImageFromFile(itemName);
        if (actualImage != null) {
            return actualImage;
        }
        return createPlaceholderImage(itemName);
    }

    // Image from image folder
    private ImageIcon loadImageFromFile(String itemName) {
        String fileName = itemName.toLowerCase().replace(" ", "_") + ".jpg";
        try {
            // Check image folder in resources
            URL resourceUrl = getClass().getResource("/images/" + fileName);
            if (resourceUrl != null) {
                BufferedImage img = ImageIO.read(resourceUrl);
                return new ImageIcon(resizeImage(img, 80, 80));
            }
            // Check local folder next to the app
            File imageFile = new File("images/" + fileName);
            if (imageFile.exists()) {
                BufferedImage img = ImageIO.read(imageFile);
                return new ImageIcon(resizeImage(img, 80, 80));
            }
        } catch (IOException e) {
            System.out.println("Could not load image for: " + itemName);
        }
        return null;
    }

    // Resize image
    private BufferedImage resizeImage(BufferedImage originalImage, int width, int height) {
        BufferedImage resizedImage = new BufferedImage(width, height, BufferedImage.TYPE_INT_RGB);
        Graphics2D g2d = resizedImage.createGraphics();
        g2d.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BILINEAR);
        g2d.setRenderingHint(RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_QUALITY);
        g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g2d.drawImage(originalImage, 0, 0, width, height, null);
        g2d.dispose();
        return resizedImage;
    }

    // Create placeholder image if no image is found
    private ImageIcon createPlaceholderImage(String itemName) {
        int width = 80, height = 80;
        BufferedImage image = new BufferedImage(width, height, BufferedImage.TYPE_INT_RGB);
        Graphics2D g2d = image.createGraphics();
        g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

        // Gradient background
        GradientPaint gradient = new GradientPaint(0, 0, PRIMARY_COLOR.brighter(), width, height, PRIMARY_COLOR);
        g2d.setPaint(gradient);
        g2d.fillRoundRect(0, 0, width, height, 15, 15);

        // Emoji on placeholder
        String emoji = getFoodEmoji(itemName);
        g2d.setColor(Color.WHITE);
        g2d.setFont(new Font("Segoe UI Emoji", Font.PLAIN, 24));
        FontMetrics fm = g2d.getFontMetrics();
        int x = (width - fm.stringWidth(emoji)) / 2;
        int y = (height + fm.getAscent()) / 2 - 10;
        g2d.drawString(emoji, x, y);

        // Item name small text
        g2d.setFont(new Font("Segoe UI", Font.BOLD, 8));
        fm = g2d.getFontMetrics();
        String[] words = itemName.split(" ");
        y = height - 15;
        for (String word : words) {
            x = (width - fm.stringWidth(word)) / 2;
            g2d.drawString(word, x, y);
            y += fm.getHeight();
        }

        g2d.dispose();
        return new ImageIcon(image);
    }

    // Return emoji based on food name
    private String getFoodEmoji(String foodName) {
        String name = foodName.toLowerCase();
        if (name.contains("burger")) return "🍔";
        if (name.contains("pizza")) return "🍕";
        if (name.contains("salad")) return "🥗";
        if (name.contains("fries")) return "🍟";
        if (name.contains("soda") || name.contains("drink")) return "🥤";
        if (name.contains("coffee")) return "☕";
        if (name.contains("sandwich")) return "🥪";
        if (name.contains("pasta")) return "🍝";
        return "🍽️";
    }

    // Initialize menu items list
    private void initializeMenu() {
        menuItems.add(new MenuItem("Burger", 65.00, "Classic beef burger with fresh lettuce and tomato"));
        menuItems.add(new MenuItem("Pizza Slice", 30, "Delicious cheese pizza slice"));
        menuItems.add(new MenuItem("Salad", 35, "Fresh garden salad with mixed vegetables"));
        menuItems.add(new MenuItem("French Fries", 25, "Crispy golden fries, perfectly seasoned"));
        menuItems.add(new MenuItem("Soda", 18, "Refreshing fountain drink, any size"));
        menuItems.add(new MenuItem("Coffee", 30, "Freshly brewed premium coffee"));
        menuItems.add(new MenuItem("Sandwich", 20, "Turkey and cheese sandwich on fresh bread"));
        menuItems.add(new MenuItem("Pasta", 40, "Homemade pasta with rich marinara sauce"));
    }

    // Display all menu items in the panel
    private void displayMenu() {
        if (pnlMenu == null) return; // safety during construction
        pnlMenu.removeAll();
        for (MenuItem item : menuItems) {
            JPanel pnlItem = createMenuItemCard(item);
            pnlMenu.add(pnlItem);
            pnlMenu.add(Box.createRigidArea(new Dimension(0, 15))); // Space between items
        }
        pnlMenu.revalidate();
        pnlMenu.repaint();
    }

    // Create menu item with image, info, and add button
    private JPanel createMenuItemCard(MenuItem item) {
        JPanel pnlItem = new JPanel(new BorderLayout());
        pnlItem.setBackground(CARD_BACKGROUND);
        pnlItem.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(220, 221, 225), 1),
                BorderFactory.createEmptyBorder(15, 15, 15, 15)
        ));
        pnlItem.setPreferredSize(new Dimension(550, 110));

        // Left image panel
        JPanel pnlImage = new JPanel(new FlowLayout(FlowLayout.CENTER, 0, 0));
        pnlImage.setOpaque(false);
        pnlImage.setPreferredSize(new Dimension(100, 110));
        ImageIcon foodIcon = getImageForItem(item.getName());
        JLabel lblImage = new JLabel(foodIcon);
        lblImage.setBorder(BorderFactory.createLineBorder(new Color(220, 221, 225), 1));
        pnlImage.add(lblImage);

        // Middle info panel
        JPanel pnlInfo = new JPanel(new BorderLayout());
        pnlInfo.setOpaque(false);
        pnlInfo.setBorder(BorderFactory.createEmptyBorder(5, 15, 5, 15));
        JLabel lblName = new JLabel(item.getName());
        lblName.setFont(new Font("Segoe UI", Font.BOLD, 16));
        lblName.setForeground(SECONDARY_COLOR);
        JLabel lblDescription = new JLabel("<html>" + item.getDescription() + "</html>");
        lblDescription.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        lblDescription.setForeground(new Color(127, 140, 141));
        JLabel lblPrice = new JLabel("R" + String.format("%.2f", item.getPrice()));
        lblPrice.setFont(new Font("Segoe UI", Font.BOLD, 14));
        lblPrice.setForeground(SUCCESS_COLOR);
        pnlInfo.add(lblName, BorderLayout.NORTH);
        pnlInfo.add(lblDescription, BorderLayout.CENTER);
        pnlInfo.add(lblPrice, BorderLayout.SOUTH);

        // Right button panel
        JPanel pnlButton = new JPanel(new FlowLayout(FlowLayout.CENTER, 0, 0));
        pnlButton.setOpaque(false);
        JButton addButton = createStyledButton("+ Add", PRIMARY_COLOR);
        addButton.addActionListener(e -> addToCart(item)); // Add item to cart
        pnlButton.add(addButton);

        pnlItem.add(pnlImage, BorderLayout.WEST);
        pnlItem.add(pnlInfo, BorderLayout.CENTER);
        pnlItem.add(pnlButton, BorderLayout.EAST);

        return pnlItem;
    }

    // Add selected item to cart
    private void addToCart(MenuItem item) {
        cart.add(item);
        updateCart();
    }

    // Refresh cart panel and update total/discount
    private void updateCart() {
        if (pnlCart == null) return; // safety during construction
        pnlCart.removeAll();
        total = 0.0;

        // If cart empty show message
        if (cart.isEmpty()) {
            JPanel pnlEmpty = new JPanel(new FlowLayout(FlowLayout.CENTER));
            pnlEmpty.setOpaque(false);
            pnlEmpty.setBorder(BorderFactory.createEmptyBorder(50, 20, 50, 20));
            JLabel lblEmpty = new JLabel("<html><center>🛒<br>Your cart is empty<br><small>Add items from the menu</small></center></html>");
            lblEmpty.setFont(new Font("Segoe UI", Font.PLAIN, 14));
            lblEmpty.setForeground(new Color(127, 140, 141));
            lblEmpty.setHorizontalAlignment(SwingConstants.CENTER);
            pnlEmpty.add(lblEmpty);
            pnlCart.add(pnlEmpty);
        } else {
            // Show each cart item and add up total
            for (MenuItem item : cart) {
                JPanel pnlItem = createCartItemCard(item);
                pnlCart.add(pnlItem);
                pnlCart.add(Box.createRigidArea(new Dimension(0, 10)));
                total += item.getPrice();
            }
        }

        // Apply discount based on total
        double discount = 0.0;
        if (total >= 200) {
            discount = total * 0.15;
        } else if (total >= 100) {
            discount = total * 0.10;
        }
        if (discount > 0) {
            total -= discount;
            lblTotal.setText("Total (with discount): R" + String.format("%.2f", total));
        } else {
            lblTotal.setText("Total: R" + String.format("%.2f", total));
        }

        // Update items count label
        lblItemCount.setText(cart.size() + " item" + (cart.size() != 1 ? "s" : ""));

        pnlCart.revalidate();
        pnlCart.repaint();
    }

    // Create cart item card with image, info, and remove button
    private JPanel createCartItemCard(MenuItem item) {
        JPanel pnlItem = new JPanel(new BorderLayout());
        pnlItem.setBackground(CARD_BACKGROUND);
        pnlItem.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(220, 221, 225), 1),
                BorderFactory.createEmptyBorder(10, 10, 10, 10)
        ));
        pnlItem.setPreferredSize(new Dimension(320, 70));

        // Small image on left
        JPanel pnlImage = new JPanel(new FlowLayout(FlowLayout.CENTER, 0, 0));
        pnlImage.setOpaque(false);
        pnlImage.setPreferredSize(new Dimension(60, 70));
        ImageIcon foodIcon = getImageForItem(item.getName());
        Image img = foodIcon.getImage();
        Image scaledImg = img.getScaledInstance(40, 40, Image.SCALE_SMOOTH);
        JLabel lblImage = new JLabel(new ImageIcon(scaledImg));
        pnlImage.add(lblImage);

        // Item name and price
        JPanel pnlInfo = new JPanel(new BorderLayout());
        pnlInfo.setOpaque(false);
        pnlInfo.setBorder(BorderFactory.createEmptyBorder(0, 10, 0, 10));
        JLabel lblName = new JLabel(item.getName());
        lblName.setFont(new Font("Segoe UI", Font.BOLD, 13));
        lblName.setForeground(SECONDARY_COLOR);
        JLabel lblPrice = new JLabel("R" + String.format("%.2f", item.getPrice()));
        lblPrice.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        lblPrice.setForeground(SUCCESS_COLOR);
        pnlInfo.add(lblName, BorderLayout.NORTH);
        pnlInfo.add(lblPrice, BorderLayout.SOUTH);

        // Remove button on right
        JButton btnRemove = createRemoveButton();
        btnRemove.addActionListener(e -> {
            cart.remove(item);
            updateCart();
        });

        pnlItem.add(pnlImage, BorderLayout.WEST);
        pnlItem.add(pnlInfo, BorderLayout.CENTER);
        pnlItem.add(btnRemove, BorderLayout.EAST);

        return pnlItem;
    }

    // Checkout logic
    private void handleCheckout() {
        if (cart.isEmpty()) {
            JOptionPane.showMessageDialog(
                    this,
                    "🛒 Your cart is empty!\nPlease add some items before checkout.",
                    "Empty Cart",
                    JOptionPane.INFORMATION_MESSAGE
            );
        } else {
            // Confirmation message
            String message = String.format(
                    "🎉 Thank you for your order, %s!\n\n"
                            + "📧 Order confirmation sent to: %s\n"
                            + "💰 Total Amount: R%.2f\n"
                            + "📦 Items Ordered: %d\n\n"
                            + (scheduledTime.isEmpty() ? "Your order will be ready in 10-15 minutes!"
                            : "Scheduled Pickup Time: " + scheduledTime),
                    //studentInfo.getName(),
                    studentInfo.getEmail(),
                    total,
                    cart.size()
            );

            // Show confirmation and save to history
            JOptionPane.showMessageDialog(this, message, "Order Confirmed! 🎉", JOptionPane.INFORMATION_MESSAGE);
            orderHistory.add(message);
            clearCart();
        }
    }

    // Show order history
    private void viewHistory() {
        if (orderHistory.isEmpty()) {
            JOptionPane.showMessageDialog(this, "No orders yet!", "Order History", JOptionPane.INFORMATION_MESSAGE);
        } else {
            String historyText = String.join("\n\n---\n\n", orderHistory);
            JTextArea txtHistory = new JTextArea(historyText);
            txtHistory.setEditable(false);
            JScrollPane scrollPane = new JScrollPane(txtHistory);
            scrollPane.setPreferredSize(new Dimension(450, 320));
            JOptionPane.showMessageDialog(this, scrollPane, "Order History", JOptionPane.INFORMATION_MESSAGE);
        }
    }

    // Clear cart after checkout
    private void clearCart() {
        cart.clear();
        scheduledTime = "";
        updateCart();
    }

    // Logout and go back to login page
    private void logout() {
        int choice = JOptionPane.showConfirmDialog(
                this,
                "🚪 Are you sure you want to logout?\nAny items in your cart will be lost.",
                "Logout Confirmation",
                JOptionPane.YES_NO_OPTION,
                JOptionPane.QUESTION_MESSAGE
        );

        if (choice == JOptionPane.YES_OPTION) {
            this.dispose();
            SwingUtilities.invokeLater(() -> new LoginPage().setVisible(true));
        }
    }

    // Class for menu item
    private static class MenuItem {
        private final String name;
        private final double price;
        private final String description;

        public MenuItem(String name, double price, String description) {
            this.name = name;
            this.price = price;
            this.description = description;
        }
        public String getName() { return name; }
        public double getPrice() { return price; }
        public String getDescription() { return description; }
    }

    // Main method for Project.
    // Opens LoginPage by default.
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new LoginPage().setVisible(true));
    }

    private static class LoginPage {

        public LoginPage() {
        }

        private void setVisible(boolean b) {
            throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
        }
    }
}
