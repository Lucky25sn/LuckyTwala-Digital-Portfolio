package za.ac.cput.project;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

/**
 * Registration page for new users Clean, modern design for user registration
 */
public class RegisterPage extends JFrame {

    private JTextField studentNumberField;
    private JTextField nameField;
    private JTextField emailField;
    private JTextField phoneField;
    private JPasswordField passwordField;
    private JPasswordField confirmPasswordField;
    private JButton registerButton;
    private JButton clearButton;
    private JButton backToLoginButton;

    private final Color BLUE = new Color(70, 130, 180);
    private final Color LIGHT_BLUE = new Color(173, 216, 230);
    private final Color LIGHT_GRAY = new Color(245, 245, 245);
    private final Color GREEN = new Color(60, 179, 113);

    public RegisterPage() {
        setupWindow();
        createComponents();
        arrangeComponents();
        addEventHandlers();
    }

    private void setupWindow() {
        setTitle("Campus Cafeteria - Register");
        setSize(650, 800);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setResizable(false);
        getContentPane().setBackground(LIGHT_GRAY);
    }

    private void createComponents() {
        studentNumberField = createTextField();
        nameField = createTextField();
        emailField = createTextField();
        phoneField = createTextField();
        passwordField = createPasswordField();
        confirmPasswordField = createPasswordField();

        registerButton = createButton("REGISTER", GREEN);
        clearButton = createButton("CLEAR", Color.GRAY);
        backToLoginButton = createButton("BACK TO LOGIN", BLUE);
    }

    private JTextField createTextField() {
        JTextField field = new JTextField(20);
        field.setPreferredSize(new Dimension(300, 40));
        field.setMaximumSize(new Dimension(300, 40));
        field.setFont(new Font("Arial", Font.PLAIN, 14));
        field.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(Color.LIGHT_GRAY, 1),
                BorderFactory.createEmptyBorder(5, 10, 5, 10)
        ));
        field.addFocusListener(new FocusAdapter() {
            public void focusGained(FocusEvent e) {
                field.setBorder(BorderFactory.createCompoundBorder(
                        BorderFactory.createLineBorder(BLUE, 2),
                        BorderFactory.createEmptyBorder(4, 9, 4, 9)
                ));
            }

            public void focusLost(FocusEvent e) {
                field.setBorder(BorderFactory.createCompoundBorder(
                        BorderFactory.createLineBorder(Color.LIGHT_GRAY, 1),
                        BorderFactory.createEmptyBorder(5, 10, 5, 10)
                ));
            }
        });
        return field;
    }

    private JPasswordField createPasswordField() {
        JPasswordField field = new JPasswordField(20);
        field.setPreferredSize(new Dimension(300, 40));
        field.setMaximumSize(new Dimension(300, 40));
        field.setFont(new Font("Arial", Font.PLAIN, 14));
        field.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(Color.LIGHT_GRAY, 1),
                BorderFactory.createEmptyBorder(5, 10, 5, 10)
        ));
        field.addFocusListener(new FocusAdapter() {
            public void focusGained(FocusEvent e) {
                field.setBorder(BorderFactory.createCompoundBorder(
                        BorderFactory.createLineBorder(BLUE, 2),
                        BorderFactory.createEmptyBorder(4, 9, 4, 9)
                ));
            }

            public void focusLost(FocusEvent e) {
                field.setBorder(BorderFactory.createCompoundBorder(
                        BorderFactory.createLineBorder(Color.LIGHT_GRAY, 1),
                        BorderFactory.createEmptyBorder(5, 10, 5, 10)
                ));
            }
        });
        return field;
    }

    private JButton createButton(String text, Color color) {
        JButton button = new JButton(text);
        button.setPreferredSize(new Dimension(180, 45));
        button.setBackground(color);
        button.setForeground(Color.WHITE);
        button.setFont(new Font("Arial", Font.BOLD, 16));
        button.setFocusPainted(false);
        button.setBorderPainted(false);
        button.setOpaque(true);
        button.setCursor(new Cursor(Cursor.HAND_CURSOR));

        button.addMouseListener(new MouseAdapter() {
            public void mouseEntered(MouseEvent evt) {
                button.setBackground(color.brighter());
            }

            public void mouseExited(MouseEvent evt) {
                button.setBackground(color);
            }
        });
        return button;
    }

    private void arrangeComponents() {
        setLayout(new BorderLayout());
        JPanel mainPanel = new JPanel();
        mainPanel.setLayout(new BoxLayout(mainPanel, BoxLayout.Y_AXIS));
        mainPanel.setBorder(BorderFactory.createEmptyBorder(30, 50, 30, 50));
        mainPanel.setBackground(LIGHT_GRAY);

        mainPanel.add(createHeader());
        mainPanel.add(Box.createVerticalStrut(25));
        mainPanel.add(createForm());
        mainPanel.add(Box.createVerticalStrut(25));
        mainPanel.add(createButtonPanel());   // now vertical stacked
        mainPanel.add(Box.createVerticalStrut(20));
        mainPanel.add(createBackToLoginSection());

        add(mainPanel, BorderLayout.CENTER);
    }

    private JPanel createHeader() {
        JPanel headerPanel = new JPanel();
        headerPanel.setLayout(new BoxLayout(headerPanel, BoxLayout.Y_AXIS));
        headerPanel.setBackground(LIGHT_GRAY);

        JLabel titleLabel = new JLabel("Campus Cafeteria");
        titleLabel.setFont(new Font("Arial", Font.BOLD, 32));
        titleLabel.setForeground(BLUE);
        titleLabel.setAlignmentX(Component.CENTER_ALIGNMENT);

        JLabel subtitleLabel = new JLabel("Create New Account");
        subtitleLabel.setFont(new Font("Arial", Font.PLAIN, 16));
        subtitleLabel.setForeground(Color.GRAY);
        subtitleLabel.setAlignmentX(Component.CENTER_ALIGNMENT);

        headerPanel.add(titleLabel);
        headerPanel.add(Box.createVerticalStrut(5));
        headerPanel.add(subtitleLabel);

        return headerPanel;
    }

    private JPanel createForm() {
        JPanel formPanel = new JPanel();
        formPanel.setLayout(new BoxLayout(formPanel, BoxLayout.Y_AXIS));
        formPanel.setBackground(LIGHT_GRAY);

        JLabel welcomeLabel = new JLabel("Please fill in all details to register");
        welcomeLabel.setFont(new Font("Arial", Font.PLAIN, 14));
        welcomeLabel.setForeground(Color.DARK_GRAY);
        welcomeLabel.setAlignmentX(Component.CENTER_ALIGNMENT);

        formPanel.add(welcomeLabel);
        formPanel.add(Box.createVerticalStrut(20));
        formPanel.add(createLabelFieldPair("Student Number:", studentNumberField));
        formPanel.add(Box.createVerticalStrut(12));
        formPanel.add(createLabelFieldPair("Full Name:", nameField));
        formPanel.add(Box.createVerticalStrut(12));
        formPanel.add(createLabelFieldPair("Email Address:", emailField));
        formPanel.add(Box.createVerticalStrut(12));
        formPanel.add(createLabelFieldPair("Phone Number:", phoneField));
        formPanel.add(Box.createVerticalStrut(12));
        formPanel.add(createLabelFieldPair("Password:", passwordField));
        formPanel.add(Box.createVerticalStrut(12));
        formPanel.add(createLabelFieldPair("Confirm Password:", confirmPasswordField));

        return formPanel;
    }

    private JPanel createLabelFieldPair(String labelText, JComponent field) {
        JPanel panel = new JPanel();
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
        panel.setBackground(LIGHT_GRAY);

        JLabel label = new JLabel(labelText);
        label.setFont(new Font("Arial", Font.BOLD, 14));
        label.setAlignmentX(Component.CENTER_ALIGNMENT);

        field.setAlignmentX(Component.CENTER_ALIGNMENT);

        panel.add(label);
        panel.add(Box.createVerticalStrut(5));
        panel.add(field);

        return panel;
    }

    /**
     * * FIXED BUTTON PANEL — now vertical stack **
     */
    private JPanel createButtonPanel() {
        JPanel buttonPanel = new JPanel();
        buttonPanel.setLayout(new BoxLayout(buttonPanel, BoxLayout.Y_AXIS));
        buttonPanel.setBackground(LIGHT_GRAY);

        registerButton.setAlignmentX(Component.CENTER_ALIGNMENT);
        clearButton.setAlignmentX(Component.CENTER_ALIGNMENT);

        buttonPanel.add(registerButton);
        buttonPanel.add(Box.createVerticalStrut(15));
        buttonPanel.add(clearButton);

        return buttonPanel;
    }

    private JPanel createBackToLoginSection() {
        JPanel loginPanel = new JPanel();
        loginPanel.setLayout(new BoxLayout(loginPanel, BoxLayout.Y_AXIS));
        loginPanel.setBackground(LIGHT_GRAY);

        JSeparator separator = new JSeparator();
        separator.setMaximumSize(new Dimension(300, 1));
        separator.setAlignmentX(Component.CENTER_ALIGNMENT);

        JLabel loginLabel = new JLabel("Already have an account?");
        loginLabel.setFont(new Font("Arial", Font.PLAIN, 14));
        loginLabel.setForeground(Color.DARK_GRAY);
        loginLabel.setAlignmentX(Component.CENTER_ALIGNMENT);

        backToLoginButton.setAlignmentX(Component.CENTER_ALIGNMENT);

        loginPanel.add(separator);
        loginPanel.add(Box.createVerticalStrut(15));
        loginPanel.add(loginLabel);
        loginPanel.add(Box.createVerticalStrut(10));
        loginPanel.add(backToLoginButton);

        return loginPanel;
    }

    private void addEventHandlers() {
        registerButton.addActionListener(e -> {
            if (validateAllFields()) {
                performRegistration();
            }
        });

        clearButton.addActionListener(e -> clearAllFields());
        backToLoginButton.addActionListener(e -> backToLogin());
    }

    private boolean validateAllFields() {
        if (studentNumberField.getText().trim().isEmpty()) {
            showError("Please enter your student number");
            return false;
        }
        if (passwordField.getPassword().length < 4) {
            showError("Password must be at least 4 characters");
            return false;
        }
        if (!new String(passwordField.getPassword())
                .equals(new String(confirmPasswordField.getPassword()))) {
            showError("Passwords do not match");
            return false;
        }
        return true;
    }

    private void performRegistration() {
if (studentNumberField.getText().trim().isEmpty()
            || nameField.getText().trim().isEmpty()
            || emailField.getText().trim().isEmpty()
            || phoneField.getText().trim().isEmpty()
            || passwordField.getPassword().length < 4) {
        JOptionPane.showMessageDialog(this, "Please fill in all fields and use a password of at least 4 characters.");
        return;
    }

    String studentNumber = studentNumberField.getText().trim();
    String name = nameField.getText().trim();
    String email = emailField.getText().trim();
    String phone = phoneField.getText().trim();
    String password = new String(passwordField.getPassword());

    // Create and register student
    StudentInfo newStudent = new StudentInfo(studentNumber, name, email, phone, password);
    StudentInfo.registerStudent(newStudent);

    JOptionPane.showMessageDialog(this, "Registration successful!");
    this.dispose();
    SwingUtilities.invokeLater(() -> new LoginPage().setVisible(true));
}

    private void clearAllFields() {
        studentNumberField.setText("");
        nameField.setText("");
        emailField.setText("");
        phoneField.setText("");
        passwordField.setText("");
        confirmPasswordField.setText("");
        studentNumberField.requestFocus();
    }

    private void backToLogin() {
        this.setVisible(false);
        SwingUtilities.invokeLater(() -> new LoginPage().setVisible(true));
        this.dispose();
    }

    private void showError(String message) {
        JOptionPane.showMessageDialog(this, message, "Error", JOptionPane.ERROR_MESSAGE);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new RegisterPage().setVisible(true));
    }
}
