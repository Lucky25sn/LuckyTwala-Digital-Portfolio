package za.ac.cput.project;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

/**
 * Login page for existing users Clean, modern design for user authentication
 */
public class LoginPage extends JFrame {

    private JTextField studentNumberField;
    private JPasswordField passwordField;
    private JButton loginButton;
    private JButton clearButton;
    private JButton registerButton;

    // Simple color scheme
    private final Color BLUE = new Color(70, 130, 180);
    private final Color LIGHT_GRAY = new Color(245, 245, 245);
    private final Color GREEN = new Color(60, 179, 113);

    public LoginPage() {
        setupWindow();
        createComponents();
        arrangeComponents();
        addEventHandlers();
    }

    private void setupWindow() {
        setTitle("Campus Cafeteria - Login");
        setSize(550, 700);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setResizable(false);
        getContentPane().setBackground(LIGHT_GRAY);
    }

    private void createComponents() {
        studentNumberField = createTextField();
        passwordField = createPasswordField();

        // uniform button size and styling
        loginButton = createButton("LOGIN", BLUE);
        clearButton = createButton("CLEAR", Color.GRAY);
        registerButton = createButton("REGISTER", GREEN);
    }

    private JTextField createTextField() {
        JTextField field = new JTextField(20);
        field.setPreferredSize(new Dimension(300, 40));
        field.setMaximumSize(new Dimension(300, 40));
        field.setFont(new Font("Arial", Font.PLAIN, 14));
        field.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(Color.LIGHT_GRAY, 1),
                BorderFactory.createEmptyBorder(5, 10, 5, 10)
        ));

        field.addFocusListener(new FocusAdapter() {
            public void focusGained(FocusEvent e) {
                field.setBorder(BorderFactory.createCompoundBorder(
                        BorderFactory.createLineBorder(BLUE, 2),
                        BorderFactory.createEmptyBorder(4, 9, 4, 9)
                ));
            }

            public void focusLost(FocusEvent e) {
                field.setBorder(BorderFactory.createCompoundBorder(
                        BorderFactory.createLineBorder(Color.LIGHT_GRAY, 1),
                        BorderFactory.createEmptyBorder(5, 10, 5, 10)
                ));
            }
        });

        return field;
    }

    private JPasswordField createPasswordField() {
        JPasswordField field = new JPasswordField(20);
        field.setPreferredSize(new Dimension(300, 40));
        field.setMaximumSize(new Dimension(300, 40));
        field.setFont(new Font("Arial", Font.PLAIN, 14));
        field.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(Color.LIGHT_GRAY, 1),
                BorderFactory.createEmptyBorder(5, 10, 5, 10)
        ));

        field.addFocusListener(new FocusAdapter() {
            public void focusGained(FocusEvent e) {
                field.setBorder(BorderFactory.createCompoundBorder(
                        BorderFactory.createLineBorder(BLUE, 2),
                        BorderFactory.createEmptyBorder(4, 9, 4, 9)
                ));
            }

            public void focusLost(FocusEvent e) {
                field.setBorder(BorderFactory.createCompoundBorder(
                        BorderFactory.createLineBorder(Color.LIGHT_GRAY, 1),
                        BorderFactory.createEmptyBorder(5, 10, 5, 10)
                ));
            }
        });

        return field;
    }

    /**
     * Modernized button factory *
     */
    private JButton createButton(String text, Color color) {
        JButton button = new JButton(text);
        button.setPreferredSize(new Dimension(180, 45)); // bigger and uniform
        button.setBackground(color);
        button.setForeground(Color.WHITE);
        button.setFont(new Font("Arial", Font.BOLD, 16));
        button.setFocusPainted(false);
        button.setBorderPainted(false);
        button.setOpaque(true);
        button.setCursor(new Cursor(Cursor.HAND_CURSOR));

        // Hover effect
        button.addMouseListener(new MouseAdapter() {
            public void mouseEntered(MouseEvent evt) {
                button.setBackground(color.brighter());
            }

            public void mouseExited(MouseEvent evt) {
                button.setBackground(color);
            }
        });

        return button;
    }

    private void arrangeComponents() {
        setLayout(new BorderLayout());

        JPanel mainPanel = new JPanel();
        mainPanel.setLayout(new BoxLayout(mainPanel, BoxLayout.Y_AXIS));
        mainPanel.setBorder(BorderFactory.createEmptyBorder(40, 50, 40, 50));
        mainPanel.setBackground(LIGHT_GRAY);

        mainPanel.add(createHeader());
        mainPanel.add(Box.createVerticalStrut(30));
        mainPanel.add(createForm());
        mainPanel.add(Box.createVerticalStrut(30));
        mainPanel.add(createButtonPanel());
        mainPanel.add(Box.createVerticalStrut(20));
        mainPanel.add(createRegisterSection());

        add(mainPanel, BorderLayout.CENTER);
    }

    private JPanel createHeader() {
        JPanel headerPanel = new JPanel();
        headerPanel.setLayout(new BoxLayout(headerPanel, BoxLayout.Y_AXIS));
        headerPanel.setBackground(LIGHT_GRAY);

        JLabel titleLabel = new JLabel("Campus Cafeteria");
        titleLabel.setFont(new Font("Arial", Font.BOLD, 32));
        titleLabel.setForeground(BLUE);
        titleLabel.setAlignmentX(Component.CENTER_ALIGNMENT);

        JLabel subtitleLabel = new JLabel("Welcome Back!");
        subtitleLabel.setFont(new Font("Arial", Font.PLAIN, 16));
        subtitleLabel.setForeground(Color.GRAY);
        subtitleLabel.setAlignmentX(Component.CENTER_ALIGNMENT);

        headerPanel.add(titleLabel);
        headerPanel.add(Box.createVerticalStrut(5));
        headerPanel.add(subtitleLabel);

        return headerPanel;
    }

    private JPanel createForm() {
        JPanel formPanel = new JPanel();
        formPanel.setLayout(new BoxLayout(formPanel, BoxLayout.Y_AXIS));
        formPanel.setBackground(LIGHT_GRAY);

        JLabel welcomeLabel = new JLabel("Please login to continue");
        welcomeLabel.setFont(new Font("Arial", Font.PLAIN, 14));
        welcomeLabel.setForeground(Color.DARK_GRAY);
        welcomeLabel.setAlignmentX(Component.CENTER_ALIGNMENT);

        formPanel.add(welcomeLabel);
        formPanel.add(Box.createVerticalStrut(25));
        formPanel.add(createLabelFieldPair("Student Number:", studentNumberField));
        formPanel.add(Box.createVerticalStrut(15));
        formPanel.add(createLabelFieldPair("Password:", passwordField));

        return formPanel;
    }

    private JPanel createLabelFieldPair(String labelText, JComponent field) {
        JPanel panel = new JPanel();
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
        panel.setBackground(LIGHT_GRAY);

        JLabel label = new JLabel(labelText);
        label.setFont(new Font("Arial", Font.BOLD, 14));
        label.setAlignmentX(Component.CENTER_ALIGNMENT);

        field.setAlignmentX(Component.CENTER_ALIGNMENT);

        panel.add(label);
        panel.add(Box.createVerticalStrut(5));
        panel.add(field);

        return panel;
    }

    /**
     * Buttons side-by-side but larger and spaced *
     */
    private JPanel createButtonPanel() {
        JPanel buttonPanel = new JPanel();
        buttonPanel.setLayout(new FlowLayout(FlowLayout.CENTER, 20, 10));
        buttonPanel.setBackground(LIGHT_GRAY);
        buttonPanel.add(loginButton);
        buttonPanel.add(clearButton);
        return buttonPanel;
    }

    private JPanel createRegisterSection() {
        JPanel registerPanel = new JPanel();
        registerPanel.setLayout(new BoxLayout(registerPanel, BoxLayout.Y_AXIS));
        registerPanel.setBackground(LIGHT_GRAY);

        JSeparator separator = new JSeparator();
        separator.setMaximumSize(new Dimension(300, 1));
        separator.setAlignmentX(Component.CENTER_ALIGNMENT);

        JLabel registerLabel = new JLabel("Don't have an account?");
        registerLabel.setFont(new Font("Arial", Font.PLAIN, 14));
        registerLabel.setForeground(Color.DARK_GRAY);
        registerLabel.setAlignmentX(Component.CENTER_ALIGNMENT);

        registerButton.setAlignmentX(Component.CENTER_ALIGNMENT);

        registerPanel.add(separator);
        registerPanel.add(Box.createVerticalStrut(15));
        registerPanel.add(registerLabel);
        registerPanel.add(Box.createVerticalStrut(10));
        registerPanel.add(registerButton);

        return registerPanel;
    }

    private void addEventHandlers() {
        loginButton.addActionListener(e -> performLogin());
        clearButton.addActionListener(e -> clearAllFields());
        registerButton.addActionListener(e -> openRegisterPage());
    }

    private void performLogin() {
String studentNumber = studentNumberField.getText().trim();
    String password = new String(passwordField.getPassword());

    if (studentNumber.isEmpty()) {
        showError("Please enter your student number");
        return;
    }
    if (password.length() < 4) {
        showError("Please enter your password (at least 4 characters)");
        return;
    }

    StudentInfo loggedInStudent = StudentInfo.loginStudent(studentNumber, password);

    if (loggedInStudent == null) {
        showError("Invalid student number or password");
        return;
    }

    JOptionPane.showMessageDialog(this, "Login successful!");
    this.dispose();
    new Project(loggedInStudent).setVisible(true);
}

    private void showError(String message) {
        JOptionPane.showMessageDialog(this, message, "Error", JOptionPane.ERROR_MESSAGE);
    }

    private void clearAllFields() {
        studentNumberField.setText("");
        passwordField.setText("");
        studentNumberField.requestFocus();
    }

    private void openRegisterPage() {
        this.setVisible(false);
        SwingUtilities.invokeLater(() -> new RegisterPage().setVisible(true));
        this.dispose();
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new LoginPage().setVisible(true));
    }
}
