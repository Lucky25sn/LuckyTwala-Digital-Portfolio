package za.ac.cput.project;

import javax.swing.*;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import javax.imageio.ImageIO;

/**
 * Campus Cafeteria Application with Uniform Buttons & Total Label Below Buttons
 */
public class Project extends JFrame {

    private StudentInfo studentInfo;
    private final List<MenuItem> menuItems = new ArrayList<>();
    private final List<MenuItem> cart = new ArrayList<>();
    private JPanel menuPanel;
    private JPanel cartPanel;
    private JLabel totalLabel;
    private JLabel welcomeLabel;
    private JLabel itemCountLabel;
    private double total = 0.0;

    private String scheduledTime = "";
    private final List<String> orderHistory = new ArrayList<>();

    // Colors
    private static final Color PRIMARY_COLOR = new Color(41, 128, 185);
    private static final Color SECONDARY_COLOR = new Color(52, 73, 94);
    private static final Color SUCCESS_COLOR = new Color(39, 174, 96);
    private static final Color DANGER_COLOR = new Color(231, 76, 60);
    private static final Color WARNING_COLOR = new Color(241, 196, 15);
    private static final Color LIGHT_GRAY = new Color(248, 249, 250);
    private static final Color CARD_BACKGROUND = Color.WHITE;

    public Project() {
        this(new StudentInfo("Unknown", "Guest User", "guest@example.com", "0000000000"));
    }

    public Project(StudentInfo studentInfo) {
        this.studentInfo = studentInfo;
        setupApplication();
        initializeMenu();
        createUserInterface();
        setLocationRelativeTo(null);
    }

    private void setupApplication() {
        setTitle("Campus Cafeteria");
        setSize(1000, 750);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());
    }

    private void createUserInterface() {
        JPanel mainPanel = new JPanel(new BorderLayout());
        mainPanel.setBackground(LIGHT_GRAY);

        mainPanel.add(createHeaderPanel(), BorderLayout.NORTH);
        mainPanel.add(createContentPanel(), BorderLayout.CENTER);
        mainPanel.add(createStatusBar(), BorderLayout.SOUTH);

        add(mainPanel);
        pack();
    }

    private JPanel createHeaderPanel() {
        JPanel headerPanel = new JPanel(new BorderLayout());
        headerPanel.setBackground(PRIMARY_COLOR);
        headerPanel.setBorder(BorderFactory.createEmptyBorder(15, 20, 15, 20));

        JPanel titlePanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 0, 0));
        titlePanel.setOpaque(false);

        JLabel titleLabel = new JLabel("Campus Cafeteria");
        titleLabel.setFont(new Font("Segoe UI", Font.BOLD, 28));
        titleLabel.setForeground(Color.WHITE);
        titlePanel.add(titleLabel);

        JPanel welcomePanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 0));
        welcomePanel.setOpaque(false);

        welcomeLabel = new JLabel("Welcome, " + studentInfo.getName());
        welcomeLabel.setFont(new Font("Segoe UI", Font.PLAIN, 16));
        welcomeLabel.setForeground(Color.WHITE);

        JLabel studentNumberLabel = new JLabel("Student ID: " + studentInfo.getStudentNumber());
        studentNumberLabel.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        studentNumberLabel.setForeground(new Color(189, 195, 199));

        welcomePanel.add(welcomeLabel);
        welcomePanel.add(studentNumberLabel);

        headerPanel.add(titlePanel, BorderLayout.WEST);
        headerPanel.add(welcomePanel, BorderLayout.EAST);

        return headerPanel;
    }

    private JSplitPane createContentPanel() {
        JPanel menuContainer = createMenuContainer();
        JPanel cartContainer = createCartContainer();

        JSplitPane splitPane = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT, menuContainer, cartContainer);
        splitPane.setDividerLocation(600);
        splitPane.setResizeWeight(0.6);
        splitPane.setBorder(null);
        splitPane.setBackground(LIGHT_GRAY);

        return splitPane;
    }

    private JPanel createMenuContainer() {
        JPanel menuContainer = new JPanel(new BorderLayout());
        menuContainer.setBackground(LIGHT_GRAY);
        menuContainer.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 10));

        JPanel menuHeader = new JPanel(new FlowLayout(FlowLayout.LEFT, 0, 0));
        menuHeader.setOpaque(false);

        JLabel menuTitle = new JLabel("Today's Menu");
        menuTitle.setFont(new Font("Segoe UI", Font.BOLD, 20));
        menuTitle.setForeground(SECONDARY_COLOR);
        menuHeader.add(menuTitle);

        menuPanel = new JPanel();
        menuPanel.setLayout(new BoxLayout(menuPanel, BoxLayout.Y_AXIS));
        menuPanel.setBackground(LIGHT_GRAY);
        displayMenu();

        JScrollPane menuScrollPane = new JScrollPane(menuPanel);
        menuScrollPane.setBorder(null);
        menuScrollPane.setBackground(LIGHT_GRAY);
        menuScrollPane.getVerticalScrollBar().setUnitIncrement(16);

        menuContainer.add(menuHeader, BorderLayout.NORTH);
        menuContainer.add(menuScrollPane, BorderLayout.CENTER);

        return menuContainer;
    }

    private JPanel createCartContainer() {
        JPanel cartContainer = new JPanel(new BorderLayout());
        cartContainer.setBackground(LIGHT_GRAY);
        cartContainer.setBorder(BorderFactory.createEmptyBorder(20, 10, 20, 20));

        JPanel cartHeader = createCartHeader();

        cartPanel = new JPanel();
        cartPanel.setLayout(new BoxLayout(cartPanel, BoxLayout.Y_AXIS));
        cartPanel.setBackground(LIGHT_GRAY);

        JScrollPane cartScrollPane = new JScrollPane(cartPanel);
        cartScrollPane.setBorder(null);
        cartScrollPane.setBackground(LIGHT_GRAY);
        cartScrollPane.getVerticalScrollBar().setUnitIncrement(16);
        cartScrollPane.setPreferredSize(new Dimension(350, 400));

        JPanel checkoutPanel = createCheckoutPanel();

        cartContainer.add(cartHeader, BorderLayout.NORTH);
        cartContainer.add(cartScrollPane, BorderLayout.CENTER);
        cartContainer.add(checkoutPanel, BorderLayout.SOUTH);

        return cartContainer;
    }

    private JPanel createCartHeader() {
        JPanel cartHeader = new JPanel(new BorderLayout());
        cartHeader.setOpaque(false);
        cartHeader.setBorder(BorderFactory.createEmptyBorder(0, 0, 15, 0));

        JLabel cartTitle = new JLabel("Your Order");
        cartTitle.setFont(new Font("Segoe UI", Font.BOLD, 20));
        cartTitle.setForeground(SECONDARY_COLOR);

        itemCountLabel = new JLabel("0 items");
        itemCountLabel.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        itemCountLabel.setForeground(new Color(127, 140, 141));

        cartHeader.add(cartTitle, BorderLayout.WEST);
        cartHeader.add(itemCountLabel, BorderLayout.EAST);

        return cartHeader;
    }

    /**
     * Buttons above, total label below
     */
    private JPanel createCheckoutPanel() {
        JPanel checkoutPanel = new JPanel();
        checkoutPanel.setLayout(new BoxLayout(checkoutPanel, BoxLayout.Y_AXIS));
        checkoutPanel.setBackground(CARD_BACKGROUND);
        checkoutPanel.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(220, 221, 225), 1),
                BorderFactory.createEmptyBorder(20, 20, 20, 20)
        ));

        // Button row
        JPanel buttonPanel = new JPanel(new GridLayout(1, 4, 8, 0));
        buttonPanel.setOpaque(false);

        JButton checkoutButton = createStyledButton("Checkout", SUCCESS_COLOR);
        JButton logoutButton = createStyledButton("Logout", DANGER_COLOR);
        JButton scheduleButton = createStyledButton("Set Pickup", WARNING_COLOR);
        JButton historyButton = createStyledButton("View History", SECONDARY_COLOR);

        checkoutButton.addActionListener(e -> handleCheckout());
        logoutButton.addActionListener(e -> logout());
        scheduleButton.addActionListener(e -> {
            scheduledTime = JOptionPane.showInputDialog(this, "Enter your preferred pickup time (e.g. 13:30):",
                    "Schedule Order", JOptionPane.PLAIN_MESSAGE);
        });
        historyButton.addActionListener(e -> viewHistory());

        buttonPanel.add(checkoutButton);
        buttonPanel.add(logoutButton);
        buttonPanel.add(scheduleButton);
        buttonPanel.add(historyButton);

        JPanel buttonWrapper = new JPanel(new FlowLayout(FlowLayout.CENTER, 0, 5));
        buttonWrapper.setOpaque(false);
        buttonWrapper.add(buttonPanel);

        // Total label BELOW the buttons
        JPanel totalPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
        totalPanel.setOpaque(false);

        totalLabel = new JLabel("Total: R0.00");
        totalLabel.setFont(new Font("Segoe UI", Font.BOLD, 16));
        totalLabel.setForeground(SUCCESS_COLOR);
        totalPanel.add(totalLabel);

        checkoutPanel.add(buttonWrapper);
        checkoutPanel.add(Box.createRigidArea(new Dimension(0, 10)));
        checkoutPanel.add(totalPanel);

        return checkoutPanel;
    }

    // --- BUTTON HELPERS ---
    private JButton createStyledButton(String text, Color backgroundColor) {
        JButton button = new JButton(text);
        button.setPreferredSize(new Dimension(150, 55)); // increased width/height
        button.setFont(new Font("Segoe UI", Font.BOLD, 14));
        button.setForeground(Color.WHITE);
        button.setBackground(backgroundColor);
        button.setFocusPainted(false);
        button.setCursor(new Cursor(Cursor.HAND_CURSOR));

        Color hoverColor = backgroundColor.darker();
        button.addMouseListener(new java.awt.event.MouseAdapter() {
            @Override
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                button.setBackground(hoverColor);
            }

            @Override
            public void mouseExited(java.awt.event.MouseEvent evt) {
                button.setBackground(backgroundColor);
            }
        });
        return button;
    }

    private JButton createRemoveButton() {
        JButton button = new JButton("×");
        button.setPreferredSize(new Dimension(50, 40));
        button.setFont(new Font("Segoe UI", Font.BOLD, 18));
        button.setBackground(DANGER_COLOR);
        button.setForeground(Color.WHITE);
        button.setFocusPainted(false);
        button.setCursor(new Cursor(Cursor.HAND_CURSOR));

        Color hoverColor = DANGER_COLOR.darker();
        button.addMouseListener(new java.awt.event.MouseAdapter() {
            @Override
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                button.setBackground(hoverColor);
            }

            @Override
            public void mouseExited(java.awt.event.MouseEvent evt) {
                button.setBackground(DANGER_COLOR);
            }
        });
        return button;
    }

    private JPanel createStatusBar() {
        JPanel statusBar = new JPanel(new BorderLayout());
        statusBar.setBackground(SECONDARY_COLOR);
        statusBar.setBorder(BorderFactory.createEmptyBorder(10, 20, 10, 20));

        JLabel contactLabel = new JLabel("📧 " + studentInfo.getEmail() + " | 📞 " + studentInfo.getPhone());
        contactLabel.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        contactLabel.setForeground(Color.WHITE);

        JLabel timeLabel = new JLabel("🕐 " + java.time.LocalTime.now().toString().substring(0, 5));
        timeLabel.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        timeLabel.setForeground(new Color(189, 195, 199));

        statusBar.add(contactLabel, BorderLayout.WEST);
        statusBar.add(timeLabel, BorderLayout.EAST);

        return statusBar;
    }

    // --- IMAGE HANDLING ---
    private ImageIcon getImageForItem(String itemName) {
        ImageIcon actualImage = loadImageFromFile(itemName);
        if (actualImage != null) {
            return actualImage;
        }
        return createPlaceholderImage(itemName);
    }

    private ImageIcon loadImageFromFile(String itemName) {
        String fileName = itemName.toLowerCase().replace(" ", "_") + ".jpg";
        try {
            URL resourceUrl = getClass().getResource("/images/" + fileName);
            if (resourceUrl != null) {
                BufferedImage img = ImageIO.read(resourceUrl);
                return new ImageIcon(resizeImage(img, 80, 80));
            }
            File imageFile = new File("images/" + fileName);
            if (imageFile.exists()) {
                BufferedImage img = ImageIO.read(imageFile);
                return new ImageIcon(resizeImage(img, 80, 80));
            }
        } catch (IOException e) {
            System.out.println("Could not load image for: " + itemName);
        }
        return null;
    }

    private BufferedImage resizeImage(BufferedImage originalImage, int width, int height) {
        BufferedImage resizedImage = new BufferedImage(width, height, BufferedImage.TYPE_INT_RGB);
        Graphics2D g2d = resizedImage.createGraphics();
        g2d.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BILINEAR);
        g2d.setRenderingHint(RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_QUALITY);
        g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g2d.drawImage(originalImage, 0, 0, width, height, null);
        g2d.dispose();
        return resizedImage;
    }

    private ImageIcon createPlaceholderImage(String itemName) {
        int width = 80, height = 80;
        BufferedImage image = new BufferedImage(width, height, BufferedImage.TYPE_INT_RGB);
        Graphics2D g2d = image.createGraphics();
        g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

        GradientPaint gradient = new GradientPaint(0, 0, PRIMARY_COLOR.brighter(), width, height, PRIMARY_COLOR);
        g2d.setPaint(gradient);
        g2d.fillRoundRect(0, 0, width, height, 15, 15);

        String emoji = getFoodEmoji(itemName);
        g2d.setColor(Color.WHITE);
        g2d.setFont(new Font("Segoe UI Emoji", Font.PLAIN, 24));
        FontMetrics fm = g2d.getFontMetrics();
        int x = (width - fm.stringWidth(emoji)) / 2;
        int y = (height + fm.getAscent()) / 2 - 10;
        g2d.drawString(emoji, x, y);

        g2d.setFont(new Font("Segoe UI", Font.BOLD, 8));
        fm = g2d.getFontMetrics();
        String[] words = itemName.split(" ");
        y = height - 15;
        for (String word : words) {
            x = (width - fm.stringWidth(word)) / 2;
            g2d.drawString(word, x, y);
            y += fm.getHeight();
        }

        g2d.dispose();
        return new ImageIcon(image);
    }

    private String getFoodEmoji(String foodName) {
        String name = foodName.toLowerCase();
        if (name.contains("burger")) {
            return "🍔";
        }
        if (name.contains("pizza")) {
            return "🍕";
        }
        if (name.contains("salad")) {
            return "🥗";
        }
        if (name.contains("fries")) {
            return "🍟";
        }
        if (name.contains("soda") || name.contains("drink")) {
            return "🥤";
        }
        if (name.contains("coffee")) {
            return "☕";
        }
        if (name.contains("sandwich")) {
            return "🥪";
        }
        if (name.contains("pasta")) {
            return "🍝";
        }
        return "🍽️";
    }

    // --- MENU / CART LOGIC ---
    private void initializeMenu() {
        menuItems.add(new MenuItem("Burger", 65.00, "Classic beef burger with fresh lettuce and tomato"));
        menuItems.add(new MenuItem("Pizza Slice", 30, "Delicious cheese pizza slice"));
        menuItems.add(new MenuItem("Salad", 35, "Fresh garden salad with mixed vegetables"));
        menuItems.add(new MenuItem("French Fries", 25, "Crispy golden fries, perfectly seasoned"));
        menuItems.add(new MenuItem("Soda", 18, "Refreshing fountain drink, any size"));
        menuItems.add(new MenuItem("Coffee", 30, "Freshly brewed premium coffee"));
        menuItems.add(new MenuItem("Sandwich", 20, "Turkey and cheese sandwich on fresh bread"));
        menuItems.add(new MenuItem("Pasta", 40, "Homemade pasta with rich marinara sauce"));
    }

    private void displayMenu() {
        menuPanel.removeAll();
        for (MenuItem item : menuItems) {
            JPanel itemCard = createMenuItemCard(item);
            menuPanel.add(itemCard);
            menuPanel.add(Box.createRigidArea(new Dimension(0, 15)));
        }
        menuPanel.revalidate();
        menuPanel.repaint();
    }

    private JPanel createMenuItemCard(MenuItem item) {
        JPanel itemCard = new JPanel(new BorderLayout());
        itemCard.setBackground(CARD_BACKGROUND);
        itemCard.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(220, 221, 225), 1),
                BorderFactory.createEmptyBorder(15, 15, 15, 15)
        ));
        itemCard.setPreferredSize(new Dimension(550, 110));

        JPanel imagePanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 0, 0));
        imagePanel.setOpaque(false);
        imagePanel.setPreferredSize(new Dimension(100, 110));

        ImageIcon foodIcon = getImageForItem(item.getName());
        JLabel imageLabel = new JLabel(foodIcon);
        imageLabel.setBorder(BorderFactory.createLineBorder(new Color(220, 221, 225), 1));
        imagePanel.add(imageLabel);

        JPanel infoPanel = new JPanel(new BorderLayout());
        infoPanel.setOpaque(false);
        infoPanel.setBorder(BorderFactory.createEmptyBorder(5, 15, 5, 15));

        JLabel nameLabel = new JLabel(item.getName());
        nameLabel.setFont(new Font("Segoe UI", Font.BOLD, 16));
        nameLabel.setForeground(SECONDARY_COLOR);

        JLabel descriptionLabel = new JLabel("<html>" + item.getDescription() + "</html>");
        descriptionLabel.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        descriptionLabel.setForeground(new Color(127, 140, 141));

        JLabel priceLabel = new JLabel("R" + String.format("%.2f", item.getPrice()));
        priceLabel.setFont(new Font("Segoe UI", Font.BOLD, 14));
        priceLabel.setForeground(SUCCESS_COLOR);

        infoPanel.add(nameLabel, BorderLayout.NORTH);
        infoPanel.add(descriptionLabel, BorderLayout.CENTER);
        infoPanel.add(priceLabel, BorderLayout.SOUTH);

        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 0, 0));
        buttonPanel.setOpaque(false);

        JButton addButton = createStyledButton("+ Add", PRIMARY_COLOR);
        addButton.addActionListener(e -> addToCart(item));

        buttonPanel.add(addButton);

        itemCard.add(imagePanel, BorderLayout.WEST);
        itemCard.add(infoPanel, BorderLayout.CENTER);
        itemCard.add(buttonPanel, BorderLayout.EAST);

        return itemCard;
    }

    private void addToCart(MenuItem item) {
        cart.add(item);
        updateCart();
    }

    private void updateCart() {
        cartPanel.removeAll();
        total = 0.0;

        if (cart.isEmpty()) {
            JPanel emptyPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
            emptyPanel.setOpaque(false);
            emptyPanel.setBorder(BorderFactory.createEmptyBorder(50, 20, 50, 20));
            JLabel emptyLabel = new JLabel("<html><center>🛒<br>Your cart is empty<br><small>Add items from the menu</small></center></html>");
            emptyLabel.setFont(new Font("Segoe UI", Font.PLAIN, 14));
            emptyLabel.setForeground(new Color(127, 140, 141));
            emptyLabel.setHorizontalAlignment(SwingConstants.CENTER);
            emptyPanel.add(emptyLabel);
            cartPanel.add(emptyPanel);
        } else {
            for (MenuItem item : cart) {
                JPanel itemCard = createCartItemCard(item);
                cartPanel.add(itemCard);
                cartPanel.add(Box.createRigidArea(new Dimension(0, 10)));
                total += item.getPrice();
            }
        }

        // Discount logic
        double discount = 0.0;
        if (total >= 200) {
            discount = total * 0.15;
        } else if (total >= 100) {
            discount = total * 0.10;
        }
        if (discount > 0) {
            total -= discount;
            totalLabel.setText("Total (with discount): R" + String.format("%.2f", total));
        } else {
            totalLabel.setText("Total: R" + String.format("%.2f", total));
        }

        itemCountLabel.setText(cart.size() + " item" + (cart.size() != 1 ? "s" : ""));

        cartPanel.revalidate();
        cartPanel.repaint();
    }

    private JPanel createCartItemCard(MenuItem item) {
        JPanel itemCard = new JPanel(new BorderLayout());
        itemCard.setBackground(CARD_BACKGROUND);
        itemCard.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(220, 221, 225), 1),
                BorderFactory.createEmptyBorder(10, 10, 10, 10)
        ));
        itemCard.setPreferredSize(new Dimension(320, 70));

        JPanel imagePanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 0, 0));
        imagePanel.setOpaque(false);
        imagePanel.setPreferredSize(new Dimension(60, 70));

        ImageIcon foodIcon = getImageForItem(item.getName());
        Image img = foodIcon.getImage();
        Image scaledImg = img.getScaledInstance(40, 40, Image.SCALE_SMOOTH);
        JLabel imageLabel = new JLabel(new ImageIcon(scaledImg));
        imagePanel.add(imageLabel);

        JPanel infoPanel = new JPanel(new BorderLayout());
        infoPanel.setOpaque(false);
        infoPanel.setBorder(BorderFactory.createEmptyBorder(0, 10, 0, 10));

        JLabel nameLabel = new JLabel(item.getName());
        nameLabel.setFont(new Font("Segoe UI", Font.BOLD, 13));
        nameLabel.setForeground(SECONDARY_COLOR);

        JLabel priceLabel = new JLabel("R" + String.format("%.2f", item.getPrice()));
        priceLabel.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        priceLabel.setForeground(SUCCESS_COLOR);

        infoPanel.add(nameLabel, BorderLayout.NORTH);
        infoPanel.add(priceLabel, BorderLayout.SOUTH);

        JButton removeButton = createRemoveButton();
        removeButton.addActionListener(e -> {
            cart.remove(item);
            updateCart();
        });

        itemCard.add(imagePanel, BorderLayout.WEST);
        itemCard.add(infoPanel, BorderLayout.CENTER);
        itemCard.add(removeButton, BorderLayout.EAST);

        return itemCard;
    }

    private void handleCheckout() {
        if (cart.isEmpty()) {
            JOptionPane.showMessageDialog(
                    this,
                    "🛒 Your cart is empty!\nPlease add some items before checkout.",
                    "Empty Cart",
                    JOptionPane.INFORMATION_MESSAGE
            );
        } else {
            String message = String.format(
                    "🎉 Thank you for your order, %s!\n\n"
                    + "📧 Order confirmation sent to: %s\n"
                    + "💰 Total Amount: R%.2f\n"
                    + "📦 Items Ordered: %d\n\n"
                    + (scheduledTime.isEmpty() ? "Your order will be ready in 10-15 minutes!"
                    : "Scheduled Pickup Time: " + scheduledTime),
                    studentInfo.getName(),
                    studentInfo.getEmail(),
                    total,
                    cart.size()
            );

            JOptionPane.showMessageDialog(this, message, "Order Confirmed! 🎉", JOptionPane.INFORMATION_MESSAGE);
            orderHistory.add(message);
            clearCart();
        }
    }

    private void viewHistory() {
        if (orderHistory.isEmpty()) {
            JOptionPane.showMessageDialog(this, "No orders yet!", "Order History", JOptionPane.INFORMATION_MESSAGE);
        } else {
            String historyText = String.join("\n\n---\n\n", orderHistory);
            JTextArea textArea = new JTextArea(historyText);
            textArea.setEditable(false);
            JScrollPane scrollPane = new JScrollPane(textArea);
            scrollPane.setPreferredSize(new Dimension(450, 320));
            JOptionPane.showMessageDialog(this, scrollPane, "Order History", JOptionPane.INFORMATION_MESSAGE);
        }
    }

    private void clearCart() {
        cart.clear();
        scheduledTime = "";
        updateCart();
    }

    private void logout() {
        int choice = JOptionPane.showConfirmDialog(
                this,
                "🚪 Are you sure you want to logout?\nAny items in your cart will be lost.",
                "Logout Confirmation",
                JOptionPane.YES_NO_OPTION,
                JOptionPane.QUESTION_MESSAGE
        );

        if (choice == JOptionPane.YES_OPTION) {
            this.dispose();
            SwingUtilities.invokeLater(() -> new LoginPage().setVisible(true));
        }
    }

    private static class MenuItem {

        private final String name;
        private final double price;
        private final String description;

        public MenuItem(String name, double price, String description) {
            this.name = name;
            this.price = price;
            this.description = description;
        }

        public String getName() {
            return name;
        }

        public double getPrice() {
            return price;
        }

        public String getDescription() {
            return description;
        }
    }

    public static void main(String[] args) {
        new LoginPage().setVisible(true);
    }
}
