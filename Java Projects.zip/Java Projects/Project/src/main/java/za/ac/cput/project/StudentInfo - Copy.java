package za.ac.cput.project;

import java.util.ArrayList;
import java.util.List;

/**
 * StudentInfo class to hold student information
 * Used to pass student data between different components of the application
 */
public class StudentInfo {
    private String studentNumber;
    private String name;
    private String email;
    private String phone;
    private String password; // add password field if you want login validation

    // Static list of all registered students (no HashMap)
    private static final List<StudentInfo> registeredStudents = new ArrayList<>();

    // Constructor
    public StudentInfo(String studentNumber, String name, String email, String phone) {
        this.studentNumber = studentNumber;
        this.name = name;
        this.email = email;
        this.phone = phone;
    }

    // Optional constructor with password
    public StudentInfo(String studentNumber, String name, String email, String phone, String password) {
        this(studentNumber, name, email, phone);
        this.password = password;
    }

    // Getters and Setters
    public String getStudentNumber() { return studentNumber; }
    public String getName() { return name; }
    public String getEmail() { return email; }
    public String getPhone() { return phone; }
    public String getPassword() { return password; }

    public void setStudentNumber(String studentNumber) { this.studentNumber = studentNumber; }
    public void setName(String name) { this.name = name; }
    public void setEmail(String email) { this.email = email; }
    public void setPhone(String phone) { this.phone = phone; }
    public void setPassword(String password) { this.password = password; }

    // --- Static methods for register/login ---
    public static void registerStudent(StudentInfo student) {
        registeredStudents.add(student);
    }

    public static StudentInfo loginStudent(String studentNumber, String password) {
        for (StudentInfo s : registeredStudents) {
            if (s.getStudentNumber().equals(studentNumber) &&
                s.getPassword() != null &&
                s.getPassword().equals(password)) {
                return s; // found the matching student
            }
        }
        return null; // not found or wrong password
    }

    public static List<StudentInfo> getRegisteredStudents() {
        return new ArrayList<>(registeredStudents);
    }

    @Override
    public String toString() {
        return "StudentInfo{" +
                "studentNumber='" + studentNumber + '\'' +
                ", name='" + name + '\'' +
                ", email='" + email + '\'' +
                ", phone='" + phone + '\'' +
                '}';
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null || getClass() != obj.getClass()) return false;

        StudentInfo that = (StudentInfo) obj;
        return studentNumber != null ? studentNumber.equals(that.studentNumber) : that.studentNumber == null;
    }
}
