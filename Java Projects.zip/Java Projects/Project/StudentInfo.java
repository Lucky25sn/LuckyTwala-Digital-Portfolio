package za.ac.cput.project;

import java.util.ArrayList;
import java.util.List;


 //Class to store the student's info
 //Also stores info for registration and login.
 
public class StudentInfo {
    //Store student data
    private String studentNumber; // Student number 
    private String name;          // Full name
    private String email;         // Email address 
    private String phone;         // Phone number 
    private String password;      // Password for login and registration

    // Array list that stores all registered students
    private static final List<StudentInfo> registeredStudents = new ArrayList<>();

    //Constructors
    public StudentInfo(String studentNumber, String name, String email, String phone) {
        this.studentNumber = studentNumber;
        this.name = name;
        this.email = email;
        this.phone = phone;
    }

    
    //Constructor with password — used for registration.
     
    public StudentInfo(String studentNumber, String name, String email, String phone, String password) {
        // Calls the other constructor
        this(studentNumber, name, email, phone);
        this.password = password;
    }

    //Getters and Setters 
    public String getStudentNumber() { return studentNumber; }
    public String getName() { return name; }
    public String getEmail() { return email; }
    public String getPhone() { return phone; }
    public String getPassword() { return password; }

    public void setStudentNumber(String studentNumber) { this.studentNumber = studentNumber; }
    public void setName(String name) { this.name = name; }
    public void setEmail(String email) { this.email = email; }
    public void setPhone(String phone) { this.phone = phone; }
    public void setPassword(String password) { this.password = password; }

    //Methods to manage registered students
    //Registers a new student by adding them to the array list.
    public static void registerStudent(StudentInfo student) {
        registeredStudents.add(student);
    }
    
    //Validates login by checking student number and password 
    //return StudentInfo if login is succesfull; null if it fails.
   
    public static StudentInfo loginStudent(String studentNumber, String password) {
        for (StudentInfo s : registeredStudents) {
            // Compare student number and password 
            if (s.getStudentNumber().equals(studentNumber) &&
                s.getPassword() != null &&
                s.getPassword().equals(password)) {
                return s; // Found matching student → login successful
            }
        }
        return null; // Not found or password mismatch → login fails
    }


    //Returns a copy of all registered students
    public static List<StudentInfo> getRegisteredStudents() {
        return new ArrayList<>(registeredStudents);
    }

    @Override
    public String toString() {
        // Displays student info as text
        return "StudentInfo{" +
                "studentNumber='" + studentNumber + '\'' +
                ", name='" + name + '\'' +
                ", email='" + email + '\'' +
                ", phone='" + phone + '\'' +
                '}';
    }

    @Override
    public boolean equals(Object obj) {
        // Checks for match based on studentNumber 
        if (this == obj) return true;
        if (obj == null || getClass() != obj.getClass()) return false;

        StudentInfo that = (StudentInfo) obj;
        return studentNumber != null ? studentNumber.equals(that.studentNumber) : that.studentNumber == null;
    }
}
